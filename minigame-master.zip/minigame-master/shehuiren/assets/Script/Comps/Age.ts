import System from "../Data/System";
import { INFO } from "../Data/Info";
import Comfire from "./Comfire";
import { LANG } from "../Utils/Lang";
import { CONFIG } from "../Data/Config";

/*******************************************
 *  时间变化一年弹窗
 *  @since 2018.09.14
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Age extends cc.Component {

    private static instance : Age;

    @property(cc.Node)
    wapper :cc.Node = null;

    @property(cc.Label)
    age: cc.Label = null;

    @property(cc.Node)
    close_n :cc.Node = null;

    sys : System;

    static getInstance(){
        return Age.instance;
    }

    start () {
        cc.game.addPersistRootNode(this.node);
        Age.instance = this;
        this.node.zIndex = 300;
        this.close_n.active = false;
    }

    show(age, sys){
        this.sys = sys;
        this.close_n.active = true;
        this.age.string = age.toString() + '岁';
        this.wapper.runAction(cc.fadeIn(0.5));
    }

    close(){
        let that = this;
        this.close_n.active = false;
        this.wapper.runAction(cc.fadeOut(0.5));
        this.scheduleOnce(function(){
            if(INFO.month>=0){//触发一个随机事件
                let evt = that.sys.getRandomEvent();
                Comfire.getInstance().show(LANG.L0007 , evt.desc , LANG.format(CONFIG.eventurl , evt.pic) , that.sys.onEventYes.bind(that.sys) , that.sys.onEventNo.bind(that.sys) , evt);
            }
        }, 0.5)

    }
}