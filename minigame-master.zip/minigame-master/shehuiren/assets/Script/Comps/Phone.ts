import { LANG } from "../Utils/Lang";
import { CONFIG } from "../Data/Config";

/*******************************************
 *  电话界面
 *  @since 2018.09.05
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Phone extends cc.Component {

    private static instance : Phone;

    @property(cc.Node)
    avatar_sp : cc.Node = null;
    
    @property(cc.Label)
    name_l  : cc.Label = null;

    @property(cc.Node)
    desc_l : cc.Node = null;

    @property(cc.Node)
    content : cc.Node = null;

    // LIFE-CYCLE CALLBACKS:

    start () {
        cc.game.addPersistRootNode(this.node);
        Phone.instance = this;
        this.node.zIndex = 500;
        this.content.active = false;
    }

    _click_cb ;
    show(name , desc , avatar  , cb){
        if(typeof wx != 'undefined'){
            if(this.content.active == false){
                wx.vibrateLong(function(res){
                    
                })
            }
        }

        this.content.active = true;
        if(name != '你' && name!='')
            this.name_l.string = name;
        if(name == '你'){
            this.desc_l.color = new cc.color(81 , 86, 106 , 255);
        }else{
            this.desc_l.color = new cc.color(246 , 246, 246 , 255)
        }
        this.desc_l.getComponent(cc.Label).string = desc;
        
        let that = this;
        cc.loader.load(LANG.format(CONFIG.headurl , avatar) , function(err , texture){
            var frame=new cc.SpriteFrame(texture);
            that.avatar_sp.getComponent(cc.Sprite).spriteFrame = frame;
        })

        this._click_cb = cb;

    }

    continue(){
        if(this._click_cb){
            this._click_cb();
        }
    }
    
    close(){
        this.content.active = false;
    }

    static getInstance(){
        return Phone.instance;
    }

}
