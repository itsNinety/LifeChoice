import { LANG } from "../Utils/Lang";
import { CONFIG } from "../Data/Config";
import { INFO } from "../Data/Info";

/*******************************************
 *  通讯录头像
 *  @since 2018.09.11
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class PeopleItem extends cc.Component {

    @property(cc.Label)
    name_l: cc.Label = null;

    @property(cc.Node)
    avatar: cc.Node = null;

    @property(cc.Label)
    sign_l: cc.Label = null;

    @property(cc.Node)
    msg_n: cc.Node = null;

    _npcid = 0;

    initView(data , msg_n){
        this.name_l.string = data.name;
        this.sign_l.string = data.dialogue;
        //
        let that = this;
        cc.loader.load(LANG.format(CONFIG.head2url , data.icon) , function (err, texture) {
            var frame=new cc.SpriteFrame(texture);
            that.avatar.getComponent(cc.Sprite).spriteFrame=frame;
        });

        this._npcid = data.id;
        //
        if(msg_n > 0){
            this.msg_n.getChildByName('label').getComponent(cc.Label).string = msg_n+'';
        }else{
            this.msg_n.active =false;
        }
    }

    onClick(evt){
        INFO.chat = this._npcid;
        cc.director.loadScene('Chat');
    }
}
