import { INFO } from "../Data/Info";

const {ccclass, property} = cc._decorator;

@ccclass
export default class MainSex extends cc.Component {
 
    @property(cc.Node)
    namebg_b : cc.Node = null;

    @property(cc.Node)
    namebg_g : cc.Node = null;

    @property(cc.Node)
    monthbg_b : cc.Node = null;

    @property(cc.Node)
    monthbg_g : cc.Node = null;

    start () {
        if(INFO.sex == 0){
            this.namebg_b.active = this.monthbg_b.active = false;
        }else{
            this.namebg_g.active  = this.monthbg_g.active = false;
        }
    }

}
