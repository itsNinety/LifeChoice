/*******************************************
 *  让数字实现滚动效果刷新
 *  需要绑定在label组件上
 *  @since 2018.08.25
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class RollNumberLabel extends cc.Component {

    @property
    step : number = 5;

    _isrunning :boolean = false;
    _next = 0;

    start () {

    }

    set number(val){
        if(this._isrunning){
            this.unscheduleAllCallbacks();
            this.getComponent(cc.Label).string = this._next+'';
        }

        let that = this;
        this._next = val;
        let old = parseInt(this.getComponent(cc.Label).string);
        let _p = (val - old)/10;
        let _tmp = old ; 
        let tick = 0;
        this._isrunning = true;
        this.schedule(function(){
            _tmp = Math.floor(old + _p*tick++);
            if(tick == 10){
                _tmp = val;
                that._isrunning = false;
            }
            this.getComponent(cc.Label).string = _tmp;
        } , 0.02 , 10 );
    }
}
