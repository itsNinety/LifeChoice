/*******************************************
 *  背景框
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class AlphaBg extends cc.Component {

    private static instance : AlphaBg;


    static getInstance(){
        return AlphaBg.instance;
    }

    start () {
        cc.game.addPersistRootNode(this.node);
        AlphaBg.instance = this;
        this.node.active = false;
        this.node.zIndex = 100;
    }

    show(){
        this.node.active = true;
    }

    hide(){
        this.node.active = false;
    }

    onBgClick(evt){
        evt.stopPropagation();
        evt.stopPropagationImmediate();
    }
}
