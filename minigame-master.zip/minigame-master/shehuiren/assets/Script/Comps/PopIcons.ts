import { CONFIG } from "../Data/Config";
import AppIcon from "../Prefab/AppIcon";
import MainScene from "../Scene/MainScene";

/*******************************************
 *  圖標彈出框
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class PopIcons extends cc.Component {

    @property(cc.Node)
    bg : cc.Node = null;

    @property(cc.Node)
    content : cc.Node = null;

    @property(cc.Node)
    closeBtn  : cc.Node = null;

    @property(cc.Prefab)
    icon_fab : cc.Prefab = null;

    poptime  : number = 0.3

    main : MainScene;

    start () {
        this.initIcon();
        //this.node.active = false;
    }

    //初始化图标按钮
    initIcon(){
        let icons = CONFIG.icons;
        this.content.removeAllChildren(true);
        for(let i= 15 ; i < icons.length; i++){
            let ico = cc.instantiate(this.icon_fab);
            ico.getComponent(AppIcon).initView(icons[i]);
            ico.on('appclick' , this.onIconClick.bind(this))
            this.content.addChild(ico);
        }
    }

    onIconClick(evt , res){
        this.main.onIconClick(evt , res);
    }

    onBgClick(evt){
        evt.stopPropagation();
        evt.stopPropagationImmediate();
    }

    popUp(){
        console.log('开始弹出')
        this.node.active = true;
        this.content.scale = 0.1;
        this.bg.opacity = 0;
        this.closeBtn.opacity = 0;
        
        
        this.bg.runAction(cc.fadeIn(this.poptime));
        let sc = cc.scaleTo(this.poptime , 1 ,1);
        this.content.runAction(sc);
        this.closeBtn.runAction(cc.fadeIn(this.poptime));
    }

    popDown(){

    }

    show(){

    }

    close(){
        this.node.active=false;
    }

    // update (dt) {}
}
