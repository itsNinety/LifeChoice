
/*******************************************
 *  弹出框
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Alert extends cc.Component {

    private static instance : Alert;

    @property(cc.Node)
    wapper :cc.Node = null;

    @property(cc.Label)
    content_l :cc.Label = null;

    @property(cc.Label)
    attr_l :cc.Label = null;

    @property(cc.Node)
    ok_b :cc.Node = null;

    @property(cc.Node)
    yes_b :cc.Node = null;

    @property(cc.Node)
    no_b :cc.Node = null;

    callback ;

    static getInstance(){
        return Alert.instance;
    }

    bgClick(evt){
        evt.stopPropagation()
        evt.stopPropagationImmediate();
    }

    start() {
        cc.game.addPersistRootNode(this.node);
        Alert.instance = this;
        this.node.zIndex = 500;
    }

    show( c : string , f : Function = null , attr : string = null , flag = true){
        if(c != null)
        this.content_l.string = c;
        if(attr != null)
        this.attr_l.string = attr;
        this.wapper.active = true;
        this.node.active   = true;
        this.node.zIndex   = 950;
        this.callback      = f;
        this.no_b.active   = false;
        this.ok_b.active   = true;
        this.yes_b.active  = false;
        if(flag){
            this.content_l.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            this.attr_l.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        }
        else{
            this.content_l.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
            this.attr_l.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        }
    }

    show2(c : string , f: Function = null , attr : string = null , flag = true){
        if(c != null)
        this.content_l.string = c;
        if(attr != null)
        this.attr_l.string = attr;
        this.wapper.active = true;
        this.node.active   = true;
        this.node.zIndex   = 950;
        this.callback      = f;
        this.yes_b.active  = true;
        this.no_b.active   = true;
        this.ok_b.active   = false;
        if(flag){
            this.content_l.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
            this.attr_l.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        }
        else{
            this.content_l.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
            this.attr_l.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        }
    }

    hide(){
        this.wapper.active    = false;
        this.node.active      = false;
        this.attr_l.string    = '';
        this.content_l.string = '';
    }
    
    close(){
        if(this.callback){
            this.callback();
        }
        this.hide();
    }
}