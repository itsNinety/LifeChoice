import { INFO } from "../Data/Info";
import Npc from "../Npc/Npc";
import { API } from "../Utils/APITool";
import MsgItem from "../Prefab/MsgItem";
import MsgSysItem from "../Prefab/MsgSysItem";

/*******************************************
 *  聊天界面
 *  @since 2018.08.27
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Chat extends cc.Component {

    @property(cc.Label)
    name_l : cc.Label = null;

    @property(cc.Node)
    content_n : cc.Node = null;

    @property(cc.Prefab)
    left_msg_fab : cc.Prefab = null;

    @property(cc.Prefab)
    right_msg_fab : cc.Prefab = null;

    @property(cc.Prefab)
    sys_msg_fab :cc.Prefab = null;

    @property(cc.ScrollView)
    scroll_view : cc.ScrollView = null;

    @property(cc.Button)
    cbtn : cc.Button = null;

    npc:Npc;
    last_id : number = 0;

    num : number = 0;
    start () {
        this.npc = INFO.npcs[INFO.chat];
        if(this.npc){
            this.initHistory();
            this.npc.new_msg = 0;
        }
    }

    //重建历史聊天信息
    initHistory(){
        this.name_l.string = this.npc.info.name;
        let list = this.npc.msgs;
        for(let i = 0 ; i < list.length ; i++){
            let id = list[i];
            this.addMsgItem(id);
            if(i == list.length-1){
                this.last_id = list[i];
            }
        }
    }


    addMsgItem(id){
        let width = this.content_n.width;
        let d = API.getAPINode('juqing' , 'id' , id);
        if(d && d.type == 2){
            //添加消息
            let item : cc.Node;
            switch(d.name){
                case "你":
                    //添加右侧消息
                    item = cc.instantiate(this.right_msg_fab);
                    item.getComponent(MsgItem).initView(d , 'RIGHT');
                    item.x = width - 490;
                    break;
                case "system":
                    //添加系统消息
                    item = cc.instantiate(this.sys_msg_fab)
                    item.getComponent(MsgSysItem).initView(d);
                    item.x = width/2;
                    break;
                default:
                    //添加左侧消息
                    item = cc.instantiate(this.left_msg_fab);
                    item.getComponent(MsgItem).initView(d);
                    item.x = 20;
                    break;
            }
            this.content_n.addChild(item);
        }else{
            console.log('出了点问题' ,d);
        }
    }

    continue(evt){
        if(this.last_id!=0){
            //上一条数据
            let d =  API.getAPINode('juqing' , 'id' , this.last_id);
            if(d.finish == 'tbc'){
                if(this.num > 2){
                    INFO.npcs[INFO.chat].order++;
                    this.cbtn.enabled = false;
                }
                return;
            }
            //
            this.last_id++;
            this.npc.msgs.push(this.last_id);
            this.addMsgItem(this.last_id);
            this.num++;
        }
    }

    back(evt){
        cc.director.loadScene('ContactsScene')
    }

    // update (dt) {}
}
