/*******************************************
 *  泡泡按钮
 *  @since 2018.08.25
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class BubbleBtn extends cc.Component {


    start () {
        this.node.on(cc.Node.EventType.TOUCH_START , this.onTouchStart.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_END , this.onTouchEnd.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_CANCEL , this.onTouchEnd.bind(this));
    }

    onTouchStart(evt){
        this.node.stopAllActions();
        let sx = cc.scaleTo(0.2 , 0.8 , 0.8);
        this.node.runAction(sx);    
    }

    onTouchEnd(evt){
        this.node.stopAllActions();
        let sb = cc.scaleTo(0.1 , 1.2 , 1.2);
        let ss = cc.scaleTo(0.1 , 1, 1)
        this.node.runAction(cc.sequence(sb,ss));
    }
}
