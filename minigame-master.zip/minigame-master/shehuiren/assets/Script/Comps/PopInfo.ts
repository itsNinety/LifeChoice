import { INFO } from "../Data/Info";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  弹出个人信息
 *  @since 2018.08.27
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class PopInfo extends cc.Component {

    @property(cc.Label)
    name_l : cc.Label = null;

    @property(cc.Label)
    status_l : cc.Label = null;

    @property(cc.Sprite)
    status_s : cc.Sprite = null;

    @property([cc.SpriteFrame])
    status_sf = [];

    @property(cc.Label)
    desc_l : cc.Label = null;

    @property(cc.Node)
    vedio_b : cc.Node = null;

    @property(cc.Node)
    alpha_bg :cc.Node = null;

    start () {
        this.name_l.string = INFO.name + ' ' + INFO.age;
    }

    //展示
    show(){
        this.node.active = true;
        this.alpha_bg.active = true;
        if(INFO.status == 0){//干劲满满
            this.status_l.string = '干劲满满';
            this.status_s.spriteFrame = this.status_sf[0];
            this.desc_l.string = LANG.L2016;
            this.vedio_b.active = false;
        }
        else if(INFO.status == 1){//拖延症
            this.status_l.string = '拖延症';
            this.status_s.spriteFrame = this.status_sf[1];
            this.desc_l.string = LANG.L2017;
            this.vedio_b.active = true;
        }
    }

    //打一年鸡血点击
    onVedioClick(){

    }

    //永久干劲满满点击
    onYongjiuClick(){
        cc.director.loadScene('InviteScene');
    }

    //音乐开关
    onMusicClick(){

    }

    //主页开关
    onHomeClick(){
        this.node.active = false;
        this.alpha_bg.active = false;
        cc.director.loadScene('StartScene');
    }

    //关闭按钮
    onCloseClick(){
        this.node.active = false;
        this.alpha_bg.active = false;
    }

}
