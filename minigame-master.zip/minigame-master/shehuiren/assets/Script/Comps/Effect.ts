
/*******************************************
 *  动作效果-单例
 *  @since 2018.09.12
 *  @author lyc
 * 
 *******************************************/

export default class Effect {
    private static instance : Effect;
    public static getInstance():Effect{
        if(!Effect.instance) {
            Effect.instance = new Effect();
        }
        return Effect.instance;
    }

    public rotate: cc.Action = null;  //半周旋转
    public flick: cc.Action  = null;  //闪烁
    public shake: cc.Action  = null;  //数字抖动

    public constructor(){
        this.rotate  = cc.rotateBy(0.25,180);

        let f1 = cc.fadeIn(0.2);
        let f2 = cc.fadeOut(0.2);
        this.flick = cc.sequence(f1, f2);
        
        let t  = 0.03;                  //时间
        let s  = 2;                     //跨度
        let m1 = cc.moveTo(t, s, s);
        let m2 = cc.moveTo(t, -s, 0);
        let m3 = cc.moveTo(t, s, -s);
        let m4 = cc.moveTo(t, 0, s);
        let m5 = cc.moveTo(t, -s, -s);
        let m6 = cc.moveTo(t, s, 0);
        let m7 = cc.moveTo(t, -s, s);
        let m8 = cc.moveTo(t, 0, -s);
        let m9 = cc.moveTo(t, s, s);
        let m0 = cc.moveTo(t, 0, 0);
        this.shake = cc.sequence(m1, m2, m3, m4, m5, m6, m7, m8, m9, m0);
    }
}
export const EFF = Effect.getInstance();