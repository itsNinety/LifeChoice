import AlphaBg from "./AlphaBg";

/*******************************************
 *  事件确认框
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Comfire extends cc.Component {

    private static instance : Comfire;

    @property(cc.Label)
    title_l : cc.Label = null;

    @property(cc.Node)
    img_n :cc.Node = null;

    @property(cc.Label)
    content_l : cc.Label = null;

    @property(cc.Node)
    content :cc.Node = null;

    @property(cc.Node)
    bbtn : cc.Node = null;

    @property(cc.Node)
    rbtn : cc.Node = null;

    @property(cc.Node)
    gbtn : cc.Node = null;

    @property(cc.Node)
    atts : cc.Node = null;

    _yes_handler;
    _no_handler;
    _user_data;

    static getInstance(){
        return Comfire.instance;
    }

    start () {
        cc.game.addPersistRootNode(this.node);
        Comfire.instance = this;
        this.node.zIndex = 300;
        this.gbtn.active = false;
        this.bbtn.active = this.rbtn.active = false;

    }
    _last_img;
    show(title  , desc , img , yesHandler , noHandler , userdata){
        this.atts.active = false;
        let that = this;
        this.content.active = true;
        AlphaBg.getInstance().show();
        this.title_l.string = title;
        this.content_l.string = desc;

        this.bbtn.active = this.rbtn.active = true;
        this.gbtn.active = false;
        
        this._yes_handler = yesHandler;
        this._no_handler  = noHandler;
        this._user_data   = userdata;
        
        if(this._last_img != img){
            this.img_n.active = false;
            cc.loader.load( img,function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.img_n.getComponent(cc.Sprite).spriteFrame=frame;
                that.img_n.active = true;
                that._last_img = img;
            });
        }
    }

    show2(title , desc , img , yesHandler , userdata){
        this.atts.active = false;
        let that = this;
        this.content.active = true;
        AlphaBg.getInstance().show();
        this.title_l.string = title;
        this.content_l.string = desc;

        this.bbtn.active = this.rbtn.active = false;
        this.gbtn.active = true;
        
        this._yes_handler = yesHandler;
        this._user_data = userdata;

        if(this._last_img != img){
            this.img_n.active = false;
            cc.loader.load( img,function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.img_n.getComponent(cc.Sprite).spriteFrame=frame;
                that.img_n.active = true;
                that._last_img = img;
            });
        }
    }

    showDaily(title , desc , img , yesHandler , userdata){
        this.atts.active = true;
        let that = this;
        this.content.active = true;
        AlphaBg.getInstance().show();
        this.title_l.string = title;
        this.content_l.string = desc[0];
        cc.find("costbg/costlabel",this.atts).getComponent(cc.Label).string = desc[1];
        cc.find("attbg/attlabel",this.atts).getComponent(cc.Label).string = desc[2];

        this.bbtn.active = this.rbtn.active = false;
        this.gbtn.active = true;
        
        this._yes_handler = yesHandler;
        this._user_data = userdata;

        if(this._last_img != img){
            this.img_n.active = false;
            cc.loader.load( img,function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.img_n.getComponent(cc.Sprite).spriteFrame=frame;
                that.img_n.active = true;
                that._last_img = img;
            });
        }
    }


    close(){
        this.content.active = false;
        AlphaBg.getInstance().hide();
    }

    onYesClick(){
        if(this._yes_handler){
            if(this._user_data)
                this._yes_handler(this._user_data)
            else
                this._yes_handler()
        }
    }

    onNoClick(){
        if(this._no_handler){
            this._no_handler(this._user_data)
        }
    }
}
