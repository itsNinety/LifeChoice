import AlphaBg from "./AlphaBg";
import { INFO } from "../Data/Info";

/*******************************************
 *  机遇事件确认框
 *  @since 2018.09.05
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class ComfireOppo extends cc.Component {

    private static instance : ComfireOppo;

    @property(cc.Node)
    wapper :cc.Node = null;

    @property(cc.ProgressBar)
    love: cc.ProgressBar = null;
    @property(cc.Label)
    loveNum: cc.Label = null;
    @property(cc.ProgressBar)
    career: cc.ProgressBar = null;
    @property(cc.Label)
    careerNum: cc.Label = null;

    @property(cc.Label)
    desc_l : cc.Label = null;

    @property(cc.Label)
    choose1 : cc.Label = null;
    @property(cc.Label)
    choose2 : cc.Label = null;    
    @property(cc.Label)
    choose3 : cc.Label = null;
    @property(cc.Label)
    choose4 : cc.Label = null;

    _c1_handler;
    _c2_handler;
    _c3_handler;
    _c4_handler;
    _user_data;

    static getInstance(){
        return ComfireOppo.instance;
    }

    start () {
        cc.game.addPersistRootNode(this.node);
        ComfireOppo.instance = this;
        this.node.zIndex = 300;
    }

    show(oppo ,c1Handler , c2Handler , c3Handler , c4Handler , userdata){
        this.wapper.active = true;
        AlphaBg.getInstance().show();
        this.desc_l.string    = oppo.desc;
        this.love.progress    = INFO.love/20;
        this.loveNum.string   = INFO.love.toString();
        this.career.progress  = INFO.career/20;
        this.careerNum.string = INFO.career.toString()

        this.choose1.string = oppo.choose1.split('_')[0];
        this.choose2.string = oppo.choose2.split('_')[0];
        this.choose3.string = oppo.choose3.split('_')[0];
        this.choose4.string = oppo.choose4.split('_')[0];

        this._c1_handler = c1Handler;
        this._c2_handler = c2Handler;
        this._c3_handler = c3Handler;
        this._c4_handler = c4Handler;
        this._user_data  = userdata;
    }

    close(){
        this.wapper.active = false;
        AlphaBg.getInstance().hide();
    }

    onC1Click(){
        if(this._c1_handler){
            if(this._user_data)
                this._c1_handler(this._user_data)
            else
                this._c1_handler()
        }
    }

    onC2Click(){
        if(this._c2_handler){
            if(this._user_data)
                this._c2_handler(this._user_data)
            else
                this._c2_handler()
        }
    }

    onC3Click(){
        if(this._c3_handler){
            if(this._user_data)
                this._c3_handler(this._user_data)
            else
                this._c3_handler()
        }
    }

    onC4Click(){
        if(this._c4_handler){
            if(this._user_data)
                this._c4_handler(this._user_data)
            else
                this._c4_handler()
        }
    }

}
