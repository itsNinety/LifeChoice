import AlphaBg from "./AlphaBg";
import { LANG } from "../Utils/Lang";
import { CONFIG } from "../Data/Config";

/*******************************************
 *  对话框
 *  @since 2018.09.05
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Dialog extends cc.Component {

    private static instance : Dialog;

    @property(cc.Node)
    avatar_sp : cc.Node = null;

    @property(cc.Node)
    bg_sp : cc.Node = null;

    @property(cc.Label)
    name_l : cc.Label = null;

    @property(cc.Node)
    name_bg : cc.Node = null;

    @property(cc.Label)
    desc_l : cc.Label = null;

    @property(cc.Node)
    continue_b : cc.Node = null;

    @property(cc.Node)
    yes_b : cc.Node = null;

    @property(cc.Node)
    no_b : cc.Node = null;

    @property(cc.Label)
    yes_l : cc.Label = null;

    @property(cc.Label)
    no_l : cc.Label = null;

    @property(cc.Node)
    content : cc.Node = null;

    start () {
        cc.game.addPersistRootNode(this.node);
        Dialog.instance = this;
        this.node.zIndex = 400;
        this.content.active = false;
    }

    _con_handler;
    showDialog(name , desc , bg , avatar , continueHandler){
        AlphaBg.getInstance().show();
        this.content.active = true;
        this.yes_b.active = this.no_b.active = false;
        this.continue_b.active= true;
        this.name_l.string = name;
        if(name != ''){
            this.name_bg.active = true;
        }else{
            this.name_bg.active = false;
        }
        this.desc_l.string = desc;
        this.showbg(bg);
        this.showavatar(avatar);
        
        this._con_handler = continueHandler;
    }

    _last_bg = '';
    showbg(bg){
        let that = this;
        if(bg != this._last_bg){
            that.bg_sp.active =false;
            cc.loader.load( LANG.format(CONFIG.bgurl , bg),function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.bg_sp.getComponent(cc.Sprite).spriteFrame=frame;
                that.bg_sp.active =true;
            });
            this._last_bg = bg;
        }
    }

    _last_avatar = '';
    showavatar(avatar){
        let that = this;
        if(avatar == ''){
            that.avatar_sp.active = false;
        }else{
            that.avatar_sp.active = true;
            if(avatar != this._last_avatar){
                that.avatar_sp.active =false;
                cc.loader.load( LANG.format(CONFIG.avatarurl , avatar),function (err, texture) {
                    var frame=new cc.SpriteFrame(texture);
                    that.avatar_sp.getComponent(cc.Sprite).spriteFrame=frame;
                    that.avatar_sp.active = true;
                });
                this._last_avatar = avatar;
            }
        }
    }

    _yes_handler;
    _no_handler;
    showQuestion(desc , bg , avatar ,yes , no, yesHandler , noHandler){
        this.desc_l.string = desc;
        this.showbg(bg);
        this.showavatar(avatar);
        this.yes_l.string = yes;
        this.no_l.string = no;
        this._yes_handler = yesHandler;
        this._no_handler = noHandler;
        this.yes_b.active = this.no_b.active = true;
        this.continue_b.active=false;
    }


    onContinueClick(){
        if(this._con_handler){
            this._con_handler();
        }
    }

    onYesClick(){
        if(this._yes_handler){
            this._yes_handler();
        }
    }

    onNoClick(){
        if(this._no_handler){
            this._no_handler();
        }
    }

    close(){
        AlphaBg.getInstance().hide();
        this.content.active = false;
    }

    static getInstance(){
        return Dialog.instance;
    }
}
