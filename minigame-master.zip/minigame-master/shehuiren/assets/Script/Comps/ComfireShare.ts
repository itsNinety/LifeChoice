import AlphaBg from "./AlphaBg";
import { LANG } from "../Utils/Lang";
import { INFO } from "../Data/Info";

/*******************************************
 *  好友事件分享确认框
 *  @since 2018.09.05
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class ComfireShare extends cc.Component {

    private static instance : ComfireShare;
    @property(cc.Node)
    wapper :cc.Node = null;

    @property(cc.Label)
    title_l : cc.Label = null;

    @property(cc.Node)
    img_n :cc.Node = null;

    @property(cc.Label)
    content_l : cc.Label = null;

    @property(cc.Node)
    gbtn : cc.Node = null;

    @property(cc.Node)
    rbtn : cc.Node = null;

    @property(cc.Node)
    atts : cc.Node = null;

    _yes_handler;
    _no_handler;
    _user_data;

    static getInstance(){
        return ComfireShare.instance;
    }

    start () {
        cc.game.addPersistRootNode(this.node);
        ComfireShare.instance = this;
        this.node.zIndex = 300;
        this.gbtn.active = false;
        this.rbtn.active = false;
    }

    _last_img;
    show(title , desc , img , yesHandler, noHandler , userdata){
        let that = this;
        this.wapper.active = true;
        this.atts.active = true;
        AlphaBg.getInstance().show();
        this.title_l.string = title;
        this.content_l.string = desc[0];
        cc.find("costbg/costlabel",this.atts).getComponent(cc.Label).string = desc[1];
        cc.find("attbg/attlabel",this.atts).getComponent(cc.Label).string = desc[2];

        this.gbtn.active = this.rbtn.active = true;
        
        this._yes_handler = yesHandler;
        this._no_handler  = noHandler;
        this._user_data   = userdata;

        if(this._last_img != img){
            this.img_n.active = false;
            cc.loader.load( img,function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.img_n.getComponent(cc.Sprite).spriteFrame=frame;
                that.img_n.active = true;
                that._last_img = img;
            });
        }
    }

    close(){
        this.wapper.active = false;
        AlphaBg.getInstance().hide();
    }

    onNoClick(){
        if(this._no_handler){
            this._no_handler(this._user_data)
        }
    }

    onShareClick(){
        if(this._yes_handler){
            if(this._user_data)
                this._yes_handler(this._user_data)
            else
                this._yes_handler()
        }
        if(typeof(wx) == 'undefined') return;
        //拉起分享, 双倍奖励
        cc.loader.loadRes("",function(err,data){
            let index_img = Math.floor(Math.random()*4);
            let index_share = Math.floor(Math.random()*3);
            wx.shareAppMessage({
                title: LANG.shareCopywriting[index_share],
                imageUrl: LANG.format(LANG.shareUrl, index_img),
                query: 'Uid='+INFO.user_id,
                success(res){
                    console.log("转发成功, 双倍奖励!");
                    console.log('分享回执：', res);
                    //双倍奖励？处理数值
                    let a = this._user_data;
                    INFO.lefttime += a.time_cost;
                    INFO.ability  += 2*a.ability;
                    INFO.exp      += 2*a.exp;
                    INFO.social   += 2*a.social;
                    INFO.happy    += 2*a.happy;
                    INFO.health   += 2*a.health;
                    INFO.morality += 2*a.morality;
                    INFO.money    += 2*a.money;
                },
                fail(res){
                    console.log("转发失败!!!");
                } 
            })
        });
    }
}
