import { API } from "../Utils/APITool";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  待办事项图标，预制节点
 *  @since 2018.08.28
 *  @author qll
 * 
 *******************************************/
const {ccclass, property} = cc._decorator;

@ccclass
export default class BacklogList extends cc.Component {

    
    @property(cc.Label)
    fieldName_l: cc.Label = null;

    @property(cc.Label)
    costTime_l: cc.Label = null;

    @property(cc.Sprite)
    icon : cc.Sprite = null;

    @property(cc.Node)
    removebtn: cc.Node = null;

    @property(cc.Node)
    finishicon: cc.Node = null;


    id:string;

    start () {

    }

    initView(data){
        this.removebtn.active = true;
        this.finishicon.active = false;
        this.id = data.id;
        let daily = API.getAPI('daily_event');
        this.fieldName_l.string = data.name;
        this.costTime_l.string = -daily[data.id-1].time_cost + LANG.L11015 + (-daily[data.id-1].time_cost)/10+ LANG.L11016;
        let that = this ;
        cc.loader.loadRes('Icons/'+data.icon, function(err,res){
            var frame=new cc.SpriteFrame(res);
            that.icon.getComponent(cc.Sprite).spriteFrame=frame;
        })
    }

    initView2(data){
        this.removebtn.active = false;
        this.finishicon.active = true;
        this.id = data.id;
        let daily = API.getAPI('daily_event');
        this.fieldName_l.string = data.name;
        //其实不应该称这个label为costTime
        this.costTime_l.string = this.getwords(data.id);
        let that = this ;
        cc.loader.loadRes('Icons/'+data.icon ,function(err,res){
            var frame=new cc.SpriteFrame(res);
            that.icon.getComponent(cc.Sprite).spriteFrame=frame;
        })
    }

    initView3(data){
        let daily = API.getAPI('daily_event');
        this.removebtn.active = false;
        this.finishicon.active = false;
        this.costTime_l.string = -daily[data.id-1].time_cost + LANG.L11015 +(-daily[data.id-1].time_cost)/10 + LANG.L11016;
        this.id = data.id;
        this.fieldName_l.string = data.name;
        let that = this ;
        cc.loader.loadRes('Icons/'+data.icon ,  function(err,res){
            var frame=new cc.SpriteFrame(res);
            that.icon.getComponent(cc.Sprite).spriteFrame=frame;
        })
    }

    //奖励的语言
    getwords(id){
        let event = API.getAPINode('daily_event' , 'id' , id)
        switch(id){
            case 1:
                return LANG.format(LANG.L11000 , event.money , event.ability , event.exp , event.happy)
                break;
            case 2:
                return LANG.format(LANG.L11001 , event.money , event.ability , event.exp , event.happy);
                break;
            case 3 : 
                return LANG.format(LANG.L11002 , event.money ,  event.exp , event.social , event.happy , event.health , event.morality);
                break;
            case 4 : 
                return LANG.format(LANG.L11003 , event.money ,   event.exp , event.social , event.happy );
                break;
            case 5 : 
                return LANG.format(LANG.L11004 , event.money ,   event.exp , event.happy);
                break;
            case 6 : 
                return LANG.format(LANG.L11005 , event.money ,  event.ability , event.exp , event.social , event.happy , event.health);
                break;
            case 7 : 
                return LANG.format(LANG.L11006 , event.money ,   event.ability , event.exp , event.happy , event.health);
                break;
            case 8 : 
                return LANG.format(LANG.L11007 , event.happy ,  event.health);
                break;
            case 9 : 
                return LANG.format(LANG.L11008 , event.money ,   event.ability ,event.exp, event.happy , event.health);
                break;
            case 10 : 
                return LANG.format(LANG.L11009 , event.money ,   event.exp , event.social , event.happy , event.health);
                break;
            case 11 : 
                return LANG.format(LANG.L11010 , event.money ,  event.ability , event.happy , event.health);
                break;
            case 12 : 
                return LANG.format(LANG.L11011 , event.money ,   event.happy , event.health , event.morality);
                break;
            default:
                break;
        }
    }

    onClick(evt){
        this.node.emit('backlogremoveclick',this.id,this.id)
    }
}
