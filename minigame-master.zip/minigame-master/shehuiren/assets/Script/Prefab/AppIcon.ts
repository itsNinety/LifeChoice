/*******************************************
 *  开始界面图标
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class AppIcon extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    @property(cc.Sprite)
    icon : cc.Sprite = null;

    @property(cc.Node)
    red_p : cc.Node = null;

    clickData :string;
    id : string;


    start () {

    }

    initView(data){
        this.label.string = data.name;
        this.id = data.id;
        this.clickData = data.click;
        let that = this ;
        cc.loader.loadRes('Icons/'+data.icon ,cc.SpriteFrame ,  function(err,res){
            that.icon.spriteFrame = res;
        })
    }

    onClick(evt){
        this.node.emit('appclick', this.id , this.clickData);
        this.node.emit('toaddclick',this.id,this.id)
    }

    red(){
        this.red_p.active = true;
    }

    unred(){
        this.red_p.active = false;
    }

    // update (dt) {}
}
