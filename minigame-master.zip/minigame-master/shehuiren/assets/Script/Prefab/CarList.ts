import { LANG } from "../Utils/Lang";
import { CONFIG } from "../Data/Config";

/*******************************************
 *  车行列表预制节点
 *  @since 2018.08.25
 *  @author qll
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class CarList extends cc.Component {

    @property(cc.Node)
    skew:cc.Node = null;
  
    @property(cc.Node)
    saleBtn: cc.Node = null;

    @property(cc.Node)
    buyBtn: cc.Node = null;

    @property(cc.Sprite) //商品（房或车的图）
    goods_s: cc.Sprite = null;

    @property(cc.Label) //车辆种类
    carKind: cc.Label = null;

    @property(cc.Label) //车辆价格
    carPrice: cc.Label = null;

    @property(cc.Label) //每月车辆维护
    carMaintenance: cc.Label = null;

    clickData :string ;
    id:string;
    carprice;
    start () {

    }

    initView(data,carOwn){
        if(carOwn == -1){
            this.skew.active    = false;
            this.saleBtn.active = false;
            this.buyBtn.active  = true;
        }else{
            this.saleBtn.active = true;
            this.buyBtn.active  = false;
        }
        let that = this;
        // cc.loader.loadRes('Icons/'+data.icon ,cc.SpriteFrame ,  function(err,res){
        //     that.goods_s.spriteFrame = res;
        // })
        cc.loader.load( LANG.format(CONFIG.carurl , data.pic),function (err, texture) {
            var frame=new cc.SpriteFrame(texture);
            that.goods_s.getComponent(cc.Sprite).spriteFrame=frame;
        });
        this.carKind.string = data.car;
        this.carPrice.string = LANG.L7002+data.buy_price;
        this.carprice = data.buy_price;
        this.id = data.id;
        this.carMaintenance.string = LANG.L7000+data.month_cost+LANG.L7001;
    }

    onClick(evt){
        if(this.saleBtn.active ==true){
            this.clickData = 'sale_'+this.carprice+'_'+this.id;
        }else{
            this.clickData = 'buy_'+this.carprice+'_'+this.id;
        }
        this.node.emit('carclick',1,this.clickData);
    }

}
