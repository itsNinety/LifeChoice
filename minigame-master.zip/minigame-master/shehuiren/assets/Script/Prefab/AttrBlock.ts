import RollNumberLabel from "../Comps/RollNumberLabel";
import { EFF } from "../Comps/Effect";

/*******************************************
 *  属性预制对象
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class AttrBlock extends cc.Component {

    @property(cc.Label)
    name_l: cc.Label = null;

    @property(cc.Label)
    num_l : cc.Label = null;

    @property(cc.Sprite)
    twinkle: cc.Sprite = null;

    @property([cc.SpriteFrame])
    twinkle_sf = [];

    id;
    eng;

    initView(data){
        this.name_l.string = data.name;
        this.num_l.string = data.num;
    }

    fresh(data){
        this.twinkle.node.stopAllActions();
        this.num_l.node.stopAllActions();
        let a = parseInt(this.num_l.string) - data;
        if(a != 0){
            this.num_l.string = data;
            let n = a > 0 ? 1 : 0;
            this.twinkle.spriteFrame = this.twinkle_sf[n];
            if(this.twinkle != null)
                this.twinkle.node.runAction(EFF.flick.clone());        
            this.num_l.node.runAction(EFF.shake.clone());   
        }

        this.num_l.getComponent(RollNumberLabel).number = data;
    }
}
