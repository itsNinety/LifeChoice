import Alert from "../Comps/Alert";
import { LANG } from "../Utils/Lang";

const {ccclass, property} = cc._decorator;

@ccclass
export default class PostGradTime extends cc.Component {

    @property(cc.Label)
    field_l: cc.Label = null;
    @property(cc.Label)
    field_t_l: cc.Label = null;

    order: number = 0;
    initTime: number = 0;

    callback ;

    start(){
        this.field_t_l.string = this.initTime.toString();
    }

    arr_field = ['本专业课程', '校内外实践', '兴趣与特长', '情感与交友', '放松与休闲','锻炼与健康'];


    initView(num , cb){
        this.order = num;
        this.field_l.string = this.arr_field[num];
        this.callback = cb;
    }

    onIncrease(){
        let flag = this.callback( -5);
        if(flag){
            this.initTime += 5;
            this.field_t_l.string = this.initTime.toString();
        }
    }

    onDecrease(){
        if(this.initTime <= 0 ){
            Alert.getInstance().show(LANG.L5000);
            return;
        }
        let flag = this.callback( 5);
        if(flag){
            this.initTime -= 5;
            this.field_t_l.string = this.initTime.toString();
        }
    }
}