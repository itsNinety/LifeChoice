import RankingScene from "../Scene/RankingScene";

/*******************************************
 *  排行榜btn，layout布局，捕获事件
 *  @since 2018.08.29
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Details extends cc.Component {
    rks : RankingScene
    
    id : number = 0;
    init(n){
        this.id = n;
    }
    onClick(){
        console.log('details info of ', this.id);
        if(typeof(wx) == 'undefined') return;
        var row = {};
        row.id = this.id;//自然数, -1表示滑动d非0, -10表示需展示玩家自身详细信息
        row.d = 0;
        wx.postMessage({
            message: row,
        })
        this.rks.close.active = true;
    }
}
