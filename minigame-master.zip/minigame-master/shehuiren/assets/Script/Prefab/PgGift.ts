/*******************************************
 *  礼包界面图标
 *  @since 2018.08.24
 *  @author qll
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class PgGift extends cc.Component {
    @property(cc.Label)
    label: cc.Label = null;

    @property(cc.Sprite)
    gift_icon : cc.Sprite = null;

    clickData :string;
    id : string;

    start () {

    }

    initView(data){
        this.label.string = data.name;
        this.id = data.id;
        this.clickData = data.click;
        let that = this ;
        cc.loader.loadRes('Icons/'+'gift',cc.SpriteFrame ,  function(err,res){
            that.gift_icon.spriteFrame = res;
        })
    }

    onClick(evt){
        this.node.emit('giftclick', this.id , this.clickData);
    }

}
