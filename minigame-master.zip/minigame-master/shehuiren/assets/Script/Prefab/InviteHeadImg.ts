
/*******************************************
 *  显示邀请好友头像的预置
 *  @since 2018.09.04
 *  @author lyc
 * 
 *******************************************/
const {ccclass, property} = cc._decorator;

@ccclass
export default class InviteHeadImg extends cc.Component {

    public id = 0;
    @property(cc.Sprite)
    headImg: cc.Sprite = null;

    initView(id, url = null){
        this.id = id;
        if(url != null){
            this.createImage(this.headImg, url);
        }
    }
        
    createImage(sprite,url){
        if(typeof(wx) == 'undefined') return;
        let image = wx.createImage();
        image.onload = function () {
            let texture = new cc.Texture2D();
            texture.initWithElement(image);
            texture.handleLoadedTexture();
            sprite.spriteFrame = new cc.SpriteFrame(texture);
        };
        image.src = url;
        image.width = 75;
        image.height = 75;
    }

}
