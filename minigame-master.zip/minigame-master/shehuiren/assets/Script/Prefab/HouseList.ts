import { LANG } from "../Utils/Lang";
import { HDATA } from "../Data/HouseData";
import { CONFIG } from "../Data/Config";

/*******************************************
 *  房产列表预制节点
 *  @since 2018.08.25
 *  @author qll
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class HouseList extends cc.Component {

    @property(cc.Node)
    skew:cc.Node = null;
  
    @property(cc.Node)
    saleBtn: cc.Node = null;

    @property(cc.Node)
    buyBtn: cc.Node = null;

    @property(cc.Sprite) //商品（房或车的图）
    goods_s: cc.Sprite = null;

    @property(cc.Label) //房产种类
    houseKind: cc.Label = null;

    @property(cc.Label) //房产现价格
    housePrice: cc.Label = null;

    @property(cc.Label) //房屋基准价格
    standardPrice: cc.Label = null;

    clickData :string ;
    id:string;
    houseprice;
    start () {

    }

    initView(data,houseOwn){
        if(houseOwn == -1){
            this.skew.active = false;
            this.saleBtn.active = false;
            this.buyBtn.active = true;
        }else{
            this.saleBtn.active = true;
            this.buyBtn.active = false;
        }
        let that = this;
        cc.loader.load( LANG.format(CONFIG.houseurl , data.id),function (err, texture) {
            var frame=new cc.SpriteFrame(texture);
            that.goods_s.getComponent(cc.Sprite).spriteFrame=frame;
        });
        this.houseKind.string = data.house;
        this.standardPrice.string = LANG.L7002+data.basic_price;
        let interIndex = Math.round(HDATA.getCurr_hindex()*100)/100;
        this.housePrice.string = LANG.L7002+Math.floor(data.basic_price * interIndex)
        this.houseprice = Math.floor(data.basic_price * interIndex);
        this.id = data.id;
        //this.showPrice()
    }

    
    onClick(evt){
        if(this.saleBtn.active ==true){
            this.clickData = 'sale_'+this.houseprice+'_'+this.id;
        }else{
            this.clickData = 'buy_'+this.houseprice+'_'+this.id;
        }
        this.node.emit('houseclick',1,this.clickData);
    }

}
