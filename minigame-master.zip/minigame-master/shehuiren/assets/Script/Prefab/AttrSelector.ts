import { INFO } from "../Data/Info";
import { API } from "../Utils/APITool";

/*******************************************
 *  属性选择渲染器，生成性格背景界面
 *  @since 2018.08.23
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class AttrSelector extends cc.Component {
    //标题
    @property(cc.Label)
    title: cc.Label = null;
    //每种属性获得的加成
    @property(cc.Label)
    change: cc.Label = null;
    //4种选择的sprite
    @property(cc.Sprite)
    attr_1: cc.Sprite = null;
    @property(cc.Sprite)
    attr_2: cc.Sprite = null;
    @property(cc.Sprite)
    attr_3: cc.Sprite = null;
    @property(cc.Sprite)
    attr_4: cc.Sprite = null;
    //两种渲染底图: 0-- , 1--attribute_selected
    @property([cc.SpriteFrame])
    attr_sf = [];
    //4种选择的名称
    @property(cc.Label)
    name_1: cc.Label = null;
    @property(cc.Label)
    name_2: cc.Label = null;
    @property(cc.Label)
    name_3: cc.Label = null;
    @property(cc.Label)
    name_4: cc.Label = null;

    order: number = 0;
    initView(num){
        this.order = num;
        this.title.string  = API.getAPI('basic_num')[4*num].set;
        this.name_1.string = API.getAPI('basic_num')[4*num].name;
        this.name_2.string = API.getAPI('basic_num')[4*num+1].name;
        this.name_3.string = API.getAPI('basic_num')[4*num+2].name;
        this.name_4.string = API.getAPI('basic_num')[4*num+3].name;
        INFO.arr_selected[this.order] = 4;//默认没有选择
        this.on_1();
    }

    on_1(){
        console.log('on_1() clicked.');
        this.attr_1.spriteFrame  = this.attr_sf[1];
        this.attr_2.spriteFrame  = this.attr_sf[0];
        this.attr_3.spriteFrame  = this.attr_sf[0];
        this.attr_4.spriteFrame  = this.attr_sf[0];
        INFO.arr_selected[this.order] = 0;
        //变化
        //this.change.string = INFO.change_attr[this.order*4];
        this.showChange(API.getAPI('basic_num')[this.order*4]);
    }
    on_2(){
        console.log('on_2() clicked.')
        this.attr_1.spriteFrame  = this.attr_sf[0];
        this.attr_2.spriteFrame  = this.attr_sf[1];
        this.attr_3.spriteFrame  = this.attr_sf[0];
        this.attr_4.spriteFrame  = this.attr_sf[0];
        INFO.arr_selected[this.order] = 1;
        //变化
        //this.change.string = INFO.change_attr[this.order*4 + 1];
        this.showChange(API.getAPI('basic_num')[this.order*4 + 1]);
    }
    on_3(){
        console.log('on_3() clicked.')
        this.attr_1.spriteFrame  = this.attr_sf[0];
        this.attr_2.spriteFrame  = this.attr_sf[0];
        this.attr_3.spriteFrame  = this.attr_sf[1];
        this.attr_4.spriteFrame  = this.attr_sf[0];
        INFO.arr_selected[this.order] = 2;
        //变化
        //this.change.string = INFO.change_attr[this.order*4 + 2];
        this.showChange(API.getAPI('basic_num')[this.order*4 + 2]);
    }
    on_4(){
        console.log('on_4() clicked.')
        this.attr_1.spriteFrame  = this.attr_sf[0];
        this.attr_2.spriteFrame  = this.attr_sf[0];
        this.attr_3.spriteFrame  = this.attr_sf[0];
        this.attr_4.spriteFrame  = this.attr_sf[1];
        INFO.arr_selected[this.order] = 3;
        //变化
        //this.change.string = INFO.change_attr[this.order*4 + 3];
        this.showChange(API.getAPI('basic_num')[this.order*4 + 3]);
    }

    showChange(json){
        let str = '你的初始';
        if(json.ability != 0){
            str += '能力、经验+'+json.ability+'，';
        }
        // if(json.exp != 0){
        //     str += '经验+'+json.exp+'，';
        // }
        if(json.social != 0){
            str += '交际+'+json.social+'，';
        }
        let a = json.happy == json.health ? true : false;
        if(a && json.happy != 0){
            str += '健康、快乐+'+json.happy+'，';
        }
        else if(json.health != 0){
            str += '健康+'+json.health+'，';
        }
        else if(json.happy != 0){
            str += '快乐+'+json.happy+'，';
        }

        if(json.morality != 0){
            str += '道德+'+json.morality+'，';
        }
        if(json.money != 0){
            str += '金钱+'+json.money+'，';
        }
        if(json.career != 0){
            str += '事业指数+'+json.career+'，';
        }
        if(json.discount != 0){
            let a = Math.floor(json.discount*100);
            str += '结局分数-'+a+'%，';
        }
        this.change.string = str.substr(0, str.length - 1);
    }

    // update (dt) {}
}
