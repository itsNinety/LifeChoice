import { LANG } from "../Utils/Lang";
import { CONFIG } from "../Data/Config";
import { INFO } from "../Data/Info";

/*******************************************
 *  聊天项
 *  @since 2018.08.27
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class MsgItem extends cc.Component {

    @property
    type : string = 'LEFT';

    @property(cc.Sprite)
    avatar : cc.Sprite = null;

    @property(cc.Label)
    content_l : cc.Label = null;

    @property(cc.Sprite)
    content_bg : cc.Sprite =null;

    start () {

    }

    initView(data , type = 'LEFT'){
        
        this.content_l.node.on("size-changed", function(){
            let h = this.content_l.node.getContentSize().height;
            this.content_bg.node.height = h + 34;
            this.node.height = this.content_bg.node.height > 72 ? this.content_bg.node.height : 72;
        }, this);
        this.content_l.string = data.content;
        

        let that = this;
        if(data.avatar == 'wx'){
            cc.loader.load(INFO.headimg_url , function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.avatar.getComponent(cc.Sprite).spriteFrame=frame;
            });
        }else{
            cc.loader.load(LANG.format(CONFIG.head2url , data.avatar) , function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.avatar.getComponent(cc.Sprite).spriteFrame=frame;
            });
        }
    }

    // update (dt) {}
}
