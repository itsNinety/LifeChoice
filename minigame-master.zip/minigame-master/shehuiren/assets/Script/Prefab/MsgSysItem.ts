/*******************************************
 *  联系人界面
 *  @since 2018.08.27
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class MsgSysItem extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    @property(cc.Sprite)
    bg :cc.Sprite = null;

    initView(data){
        this.label.string = data.content;
        this.label.node.on("size-changed", function(){
            this.bg.node.width = this.label.node.width + 20;
        }, this);
    }
    // update (dt) {}
}
