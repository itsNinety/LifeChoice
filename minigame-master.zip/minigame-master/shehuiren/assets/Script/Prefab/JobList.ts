import { LANG } from "../Utils/Lang";

/*******************************************
 *  人才市场列表预制节点
 *  @since 2018.08.27
 *  @author qll
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class JobList extends cc.Component {

  
    @property(cc.Node)
    resumeDropBtn: cc.Node = null;

    @property(cc.Label) //工作种类
    jobKind_l: cc.Label = null;

    @property(cc.Label) //薪水
    salary_l: cc.Label = null;

    @property(cc.Label) //工作要求
    require_l: cc.Label = null;

    @property(cc.Label) //中介费用
    agencyfee_l: cc.Label = null;

    @property(cc.Label) //公司种类
    companyKind_l: cc.Label = null;

    exp_require: string;
    ability_require: string;
    agencyfee: string;
    clickData :string ;
    salary: string;
    id:string;

    start () {

    }


    initView(data){
        let that = this;
        // cc.loader.loadRes('Icons/'+data.icon ,cc.SpriteFrame ,  function(err,res){
        //     that.goods_s.spriteFrame = res;
        // })
        this.jobKind_l.string     = data.job;
        this.companyKind_l.string = data.company;
        this.id                   = data.id;
        this.require_l.string     = LANG.format(LANG.L6000,data.ability_require,data.exp_require);
        this.agencyfee_l.string   = LANG.format(LANG.L6001,data.cost);
        this.salary_l.string      = LANG.format(LANG.L6002,data.salary)
        this.exp_require          = data.exp_require;
        this.ability_require      = data.ability_require;
        this.agencyfee            = data.cost;
        this.salary               = data.salary;
    }

    onClick(evt){
        this.clickData = this.ability_require+'_'+this.exp_require+'_'+this.agencyfee+'_'+this.salary+'_'+this.id;
        this.node.emit('jobclick',1,this.clickData);
    }
}
