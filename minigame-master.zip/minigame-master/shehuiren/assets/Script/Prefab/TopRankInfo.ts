import TopRankingScene from "../Scene/TopRankingScene";

/*******************************************
 *  子项渲染器
 *  @since 2018.08.29
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class Item extends cc.Component {

    @property(cc.Sprite)
    num_s: cc.Sprite = null;
    @property(cc.Label)
    num_l : cc.Label = null;
    @property(cc.Sprite)
    head_s : cc.Sprite = null;
    @property(cc.Label)
    nick_l : cc.Label = null;
    @property(cc.Label)
    score_l : cc.Label = null;
    @property([cc.SpriteFrame])
    nums_sf = [];

    trs: TopRankingScene;
    id: number = 0;
    initView(n , hurl , nick , score){
        this.id = n;
        if(n == -1){
            this.num_l.node.active = false;
            this.num_s.node.active = false;
        }
        else if(n <= 2){
            this.num_l.node.active = false;
            this.num_s.node.active = true;
            this.num_s.spriteFrame = this.nums_sf[n];
        }
        else{
            this.num_l.node.active = true;
            this.num_s.node.active = false;
            this.num_l.string = n+1;
        }
        if(nick != null && nick != '' && nick != 'undefined'){
            if(nick.length > 7){
                let str = nick.substring(0, 7);
                this.nick_l.string = str + "...";
            }
            else{
                this.nick_l.string = nick;
            }
        }
        else {
            this.nick_l.string = '';
        }
        if(score != null && score != '' && score != 'undefined'){
            this.score_l.string = score;
        }
        else{
            this.score_l.string = '';
        }
        if(hurl != null && hurl != '' && hurl != 'undefined'){
            this.createImage(this.head_s,hurl); 
        }
    }
    
    createImage(sprite,url){
        if(typeof(wx) == 'undefined') return;
        let image = wx.createImage();
        image.onload = function () {
            let texture = new cc.Texture2D();
            texture.initWithElement(image);
            texture.handleLoadedTexture();
            sprite.spriteFrame = new cc.SpriteFrame(texture);
        };
        image.src = url;
    }

    onDetails(){
        console.log('onDetails() of id = ', this.id);
        this.trs.showDetails(this.id);
        this.trs.close.active = true;
    }
}