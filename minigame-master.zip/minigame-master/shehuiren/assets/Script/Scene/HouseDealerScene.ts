import { INFO } from "../Data/Info";
import { API } from "../Utils/APITool";
import HouseList from "../Prefab/HouseList";
import Alert from "../Comps/Alert";
import { HDATA } from "../Data/HouseData";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  房产界面
 *  @since 2018.08.25
 *  @author qll
 * 
 *******************************************/
const {ccclass, property} = cc._decorator;

@ccclass
export default class HouseDealerScene extends cc.Component {

    @property(cc.Prefab)
    house_fab: cc.Prefab =null;

    @property(cc.Node)
    houselistLayout: cc.Node =null;
    @property(cc.Node)
    houselistLayout2: cc.Node = null;

    @property(cc.Label)
    restmoney_l: cc.Label = null;
    @property(cc.Label)
    refresh_l: cc.Label = null;
    @property(cc.Label)
    indexTip: cc.Label = null;

    //totalPageNumber = 0; //总共的页面数
    currentPage = 1; //当面是哪一页
    flag = 0;

    start () {
        let house = API.getAPI('house')
        if(INFO.monthHouseRandom[0] == -1){
            //说明是进游戏的第一个月
            //随机出三个不一样的值,0-house.length-1
            let randomOne = Math.round(Math.random()*(house.length-1));
            let randomTwo = Math.round(Math.random()*(house.length-1));
            while(randomTwo == randomOne){
                randomTwo = Math.round(Math.random()*(house.length-1));
            }
            let randomThree = Math.round(Math.random()*(house.length-1));
            while(randomThree == randomOne || randomThree == randomTwo){
                randomThree = Math.round(Math.random()*(house.length-1));
            }
            INFO.monthHouseRandom[0] = randomOne;
            INFO.monthHouseRandom[1] = randomTwo;
            INFO.monthHouseRandom[2] = randomThree;
            this.initHouseList(this.currentPage);
        }else{
            //说明已经点击过“下个月”
            this.initHouseList(this.currentPage);
        } 
        let interIndex = Math.round(HDATA.getCurr_hindex()*100)
        this.indexTip.string = LANG.format(LANG.L8000,interIndex);
        this.refresh_l.string = LANG.format(LANG.L8001,this.currentPage)
    }

    update(){
        this.restmoney_l.string = LANG.format(LANG.L8002,Math.floor(INFO.money));
    }
    
    initHouseList(page){
        let house = API.getAPI('house')
        if(INFO.house == -1){
            //说明没有房
            this.houselistLayout.removeAllChildren();
            this.houselistLayout2.removeAllChildren();
            for(let i= 0 ; i < 3; i++){
                let house_f = cc.instantiate(this.house_fab);
                house_f.getComponent(HouseList).initView(house[INFO.monthHouseRandom[i+(page-1)*3]],INFO.house);
                house_f.on('houseclick' , this.onHouseBtnClick.bind(this));
                this.houselistLayout.addChild(house_f);
            }
        }else{
            //如果有房
            if(this.flag == 0){
                this.houselistLayout.removeAllChildren();
                let house_own = cc.instantiate(this.house_fab);
                house_own.getComponent(HouseList).initView(house[INFO.house -1],INFO.house);
                house_own.on('houseclick' , this.onHouseBtnClick.bind(this));
                this.houselistLayout.addChild(house_own);
                this.flag++;
            }

            this.houselistLayout2.removeAllChildren();
            let maxIndex = 2;
            for(let i = 0;i< maxIndex; i++){
                let house_f = cc.instantiate(this.house_fab);
                if(house[INFO.monthHouseRandom[i+(page-1)*2]].id != INFO.house){
                    house_f.getComponent(HouseList).initView(house[INFO.monthHouseRandom[i+(page-1)*2]],-1);
                    house_f.on('houseclick' , this.onHouseBtnClick.bind(this));
                    this.houselistLayout2.addChild(house_f);
                }else{
                    maxIndex++;
                }
            }
        }
      
    }

    onHouseBtnClick(evt,res){
        //预制节点的按钮点击后都会执行这个函数，在这里判断是购买还是出售
        if(INFO.purchaseHouse < 1){
            Alert.getInstance().show(LANG.L7010);
        }else{
            let houseArr = API.getAPI('house')
            let rarr = res.split('_');
            let that = this;
            if(rarr[0] == 'sale'){
                console.log("出售房")
                let realprice = Math.floor(parseInt(rarr[1]));
                Alert.getInstance().show2(LANG.format(LANG.L8003,realprice),function(){
                    //Alert.getInstance().show(LANG.format(LANG.L8004,houseArr[INFO.house -1].house,realprice),function(){
                        console.log("成功出售房子");
                        INFO.purchaseHouse -= 1; //本月可操作次数减1
                        INFO.money += realprice;
                        INFO.house = -1;
                        //that.currentPage = 1;
                        that.refresh_l.string = LANG.format(LANG.L8001,that.currentPage)
                        that.initHouseList(that.currentPage);
                    //})
                })
            }else{
                console.log("购买房")
                if(INFO.house == -1){
                    //自己没房,可以购买
                    if(INFO.money >= parseInt(rarr[1])){
                        //足够多的钱可以买
                        let realprice2 = Math.floor(parseInt(rarr[1]));
                        let a = houseArr[parseInt(rarr[2])-1];
                        Alert.getInstance().show(LANG.format(LANG.L8005, realprice2),
                        function(){
                            that.flag = 0;
                            INFO.purchaseHouse -= 1; //本月可操作次数减1
                            INFO.money -= realprice2;
                            INFO.house = parseInt(rarr[2]);
                            INFO.ability += a.ability;
                            INFO.exp += a.exp;
                            INFO.happy += a.happy;
                            //that.currentPage = 1;
                            that.refresh_l.string = LANG.format(LANG.L8001,that.currentPage)
                            that.initHouseList(that.currentPage);
                        }, LANG.format(LANG.L8008, a.ability, a.exp, a.happy))
                    }else{
                        //钱不够
                        Alert.getInstance().show(LANG.L8006);
                    }
                }else{
                    console.log("请先出售房");
                    Alert.getInstance().show(LANG.L8007);
                }
            }
        }
    }

    onLeaveBtnClick(){
        cc.director.loadScene('MainScene');
    }


    onRefreshBtnClick(){
        // if(INFO.houseRefreshTime > 0 && INFO.houseRefreshFlag == false){
        //     this.currentPage++;
        //     this.refresh_l.string = LANG.format(LANG.L8001,this.currentPage)
        //     this.initHouseList();
        //     INFO.houseRefreshTime -= 1; //可刷新次数-1
        //     INFO.houseRefreshFlag = true;
        // }else if(INFO.houseRefreshFlag == true){
        //     //不能刷新,本月可刷新次数已用完
        //     Alert.getInstance().show(LANG.L8009)
        // }else{
        //     //邀请三个及以上好友，每月即可增加一次免费刷新次数,立即邀请?
        //     Alert.getInstance().show2(LANG.L8010,function(){
        //         cc.director.loadScene('InviteScene')
        //     })
        // }
        if(INFO.friends_Invited < 3){
            //邀请三个及以上好友，每月即可增加一次免费刷新次数,立即邀请?
            Alert.getInstance().show2(LANG.L8010,function(){
                cc.director.loadScene('InviteScene')
            })
        }else if(INFO.houseRefreshTime > 0 ){
            // this.totalPageNumber++;
            this.currentPage++;
            this.refresh_l.string = LANG.format(LANG.L8001,this.currentPage)
            this.createRandom();
            this.initHouseList(this.currentPage);
            INFO.houseRefreshTime -= 1; //可刷新次数-1
        }else{
            //不能刷新,本月可刷新次数已用完
            Alert.getInstance().show(LANG.L8009)
        }
    }

    createRandom(){
        //if(INFO.house == -1){
            //没有房
            let house = API.getAPI('house')
            //随机出三个不一样的值,0-house.length-1
            let randomOne = Math.round(Math.random()*(house.length-1));
            while(house[randomOne].id == INFO.house){
                randomOne = Math.round(Math.random()*(house.length-1));
            }
            let randomTwo = Math.round(Math.random()*(house.length-1));
            while(randomTwo == randomOne || house[randomTwo].id == INFO.house){
                randomTwo = Math.round(Math.random()*(house.length-1));
            }
            let randomThree = Math.round(Math.random()*(house.length-1));
            while(randomThree == randomOne || randomThree == randomTwo || house[randomThree].id == INFO.house){
                randomThree = Math.round(Math.random()*(house.length-1));
            }
            INFO.monthHouseRandom[0+(this.currentPage-1)*3] = randomOne;
            INFO.monthHouseRandom[1+(this.currentPage-1)*3] = randomTwo;
            INFO.monthHouseRandom[2+(this.currentPage-1)*3] = randomThree;
        // }else{
        //     let house = API.getAPI('house')
        //     //随机出两个不一样的值,0-house.length-1
        //     let randomOne = Math.round(Math.random()*(house.length-1));
        //     while(house[randomOne].id == INFO.house){
        //         randomOne = Math.round(Math.random()*(house.length-1));
        //     }
        //     let randomTwo = Math.round(Math.random()*(house.length-1));
        //     while(randomTwo == randomOne || house[randomTwo].id == INFO.house){
        //         randomTwo = Math.round(Math.random()*(house.length-1));
        //     }
        //     INFO.monthHouseRandom[0+(this.currentPage-1)*2] = randomOne;
        //     INFO.monthHouseRandom[1+(this.currentPage-1)*2] = randomTwo;
        // }
    }

}
