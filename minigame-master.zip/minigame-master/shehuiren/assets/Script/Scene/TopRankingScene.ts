import { INFO } from "../Data/Info";
import { HTTP } from "../Utils/Http";
import TopRankInfo from "../Prefab/TopRankInfo";

/*******************************************
 *  最强玩家排行界面
 *  @since 2018.09.10
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class TopRankingScene extends cc.Component {
    
    @property(cc.Prefab)
    topRank: cc.Prefab = null;
    //画布滑动捕捉
    @property(cc.Node)
    slideNode :cc.Node = null;
    //画布滑动捕捉
    @property(cc.Node)
    close :cc.Node = null;
    //定位点击悬挂点，layout
    @property(cc.Node)
    n: cc.Node = null;
    @property(cc.Sprite)
    details: cc.Sprite = null;
    @property(cc.Sprite)
    boy: cc.Sprite = null;
    @property(cc.Label)
    detailsNick : cc.Label = null;
    @property(cc.Label)
    info : cc.Label = null;

    json;

    start(){
        let that = this;
        // 取到最强玩家排行
        new Promise((resolve,reject)=>{
            let par = {};
            par.user_id = INFO.user_id;
            HTTP.httpPost(INFO.url_getTop, par, function(data){
                if(parseInt(data) != -1){
                    that.json = JSON.parse(data);
                    console.log('取总排行返回: ', that.json);
                    resolve();
                }
            })
        }).then(function(value){
            let len = that.json.data.top100.length;
            for(let i = 0; i < len; i++){
                let a = that.json.data.top100[i];
                let item = cc.instantiate(that.topRank);
                item.getComponent(TopRankInfo).initView(i, a.avatar, a.nick, a.top_score);
                item.getComponent(TopRankInfo).trs = that;
                that.n.addChild(item);
            }
            let a = that.json.data.user_data;
            let item = cc.instantiate(that.topRank);
            item.getComponent(TopRankInfo).initView(-1, a.avatar, a.nick, a.top_score);
            item.getComponent(TopRankInfo).trs = that;
            that.node.addChild(item);
            item.setPosition(-235, -300);
            that.slideNode.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
                let delta = event.touch.getDelta();
                let d = Math.round(delta.y);
                if(d != 0){
                    console.log('distance = ', d);
                    let h = (len - 5 >= 0) ? len - 5 : 0;
                    if(that.n.y >= 240 - d && that.n.y <= 240 + 108*h - d){
                        that.n.y += d;
                    }
                }
            });
        })
    }
  
    showDetails(id){
        let item;
        if(id == -1){
            item = this.json.data.user_data;
        }
        else {
            item = this.json.data.top100[id];
        }
        //console.log('showDetails() of id = ', id);
        //console.log('item = ', item);
        if(parseInt(item.sex) == 0){
            this.boy.node.active = false;
        }
        if(item.nick.length > 7){
            let str = item.nick.substring(0, 7);
            this.detailsNick.string = str + "...";
        }
        else{
            this.detailsNick.string = item.nick;
        }
        this.info.string = this.getDetails(item);
        this.details.node.active = true;
    }
    
    getDetails(info){
        let json;
        if(info.info != null && info.info != '' && info.info != undefined){
            json = JSON.parse(info.info);
            //console.log('json = ', json);
            let detailsInfo = "钱包: " + json.wallet
            + "\n年龄: " + json.age
            + "\n职位: " + json.position.substr(0, json.position.length-4)
            + "\n         " + json.position.substr(json.position.length-4, json.position.length-1)
            + "\n伴侣: " + json.lover
            + "\n车:    " + json.car
            + "\n房:    " + json.house;
            //console.log('detailsInfo = ', detailsInfo);
            return detailsInfo;
        }
        else return '';
    }

    //点击关闭详情
    closeDetails(){
        console.log('closeDetails().')
        this.details.node.active = false;
        this.close.active = false;
        this.boy.node.active = true;
    }

    onLeave(){
        console.log('onLeave()');
        cc.director.loadScene('FinishScene');
    }

}