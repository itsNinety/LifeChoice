import { CONFIG } from "../Data/Config";
import { NET } from "../Utils/Net";
import { API } from "../Utils/APITool";
import { HTTP } from "../Utils/Http";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  闪屏界面 负责加载
 *  @since 2018.08.22
 *  @author zen
 *  
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class SplashScene extends cc.Component {

    @property(cc.Label)
    pro_l : cc.Label = null;

    private _total_load  = 0;
    private _current_load = 0;

    start () {
        this.pro_l.string = LANG.L0010;
        this.loadVer();
    }

    private loadVer(){
        let that = this;
        HTTP.httpGets(CONFIG.verurl , function(res){
            if(res == -1) return;
            res = JSON.parse(res);
            CONFIG.assetVer = res.assetv;
            that.loadData();
        } ,function(res){

        })
    }

    public loadData(){
        let urls = CONFIG.getDataUrl();
        this._total_load = urls.length;
        NET.load(urls , this.dataLoaded.bind(this) , this.allLoaded.bind(this)  , this.loadError.bind(this) );
    }

    private dataLoaded(res){
        //逐条添加基础数据
        let arr = res.split(CONFIG.separator);
        for(let i = 0 ; i < arr.length;i++){
            if(arr[i].length > 1){
                API.add_json(arr[i]);
            }
        }
        //进度
        this._current_load++;
        
        this.pro_l.string = Math.floor(this._current_load *100 / this._total_load) + '%';

    }

    private allLoaded(){
        //使用方法
        console.log(API.getAPI('basic_num'))
        cc.director.loadScene('StartScene')
    }
    private loadError(res){

    }

}
