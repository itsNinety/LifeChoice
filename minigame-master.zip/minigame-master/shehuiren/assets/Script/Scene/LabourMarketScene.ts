import { INFO } from "../Data/Info";
import { API } from "../Utils/APITool";
import JobList from "../Prefab/JobList";
import Alert from "../Comps/Alert";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  人才市场界面
 *  @since 2018.08.27
 *  @author qll
 * 
 *******************************************/


const {ccclass, property} = cc._decorator;

@ccclass
export default class LabourMarketScenes extends cc.Component {

    @property(cc.Prefab)
    job_fab: cc.Prefab =null;

    @property(cc.Node)
    joblistLayout: cc.Node =null;

    @property(cc.Label)
    restmoney_l: cc.Label = null;

    @property(cc.Label)
    exp_ability_l: cc.Label = null;

    @property(cc.Label)
    refresh_l: cc.Label = null;

    //totalPageNumber = 0; //总共的页面数
    currentPage = 1; //当面是哪一页

    start () {
        console.log(API.getAPI('job'));
        let jobs = API.getAPI('job')
        if(INFO.monthJobRandom[0] == -1){
            //说明是进游戏的第一个月
            //随机出三个不一样的值,0-jobs.length-1
            let randomOne = Math.round(Math.random()*(jobs.length-1));
            let randomTwo = Math.round(Math.random()*(jobs.length-1));
            while(randomTwo == randomOne){
                randomTwo = Math.round(Math.random()*(jobs.length-1));
            }
            let randomThree = Math.round(Math.random()*(jobs.length-1));
            while(randomThree == randomOne || randomThree == randomTwo){
                randomThree = Math.round(Math.random()*(jobs.length-1));
            }
            INFO.monthJobRandom[0] = randomOne;
            INFO.monthJobRandom[1] = randomTwo;
            INFO.monthJobRandom[2] = randomThree;
            this.initJobList(this.currentPage);
        }else{
            //说明已经点击过“下个月”
            this.initJobList(this.currentPage);
        }
        this.refresh_l.string = LANG.format(LANG.L6003,this.currentPage)
    }

    update(){
        this.restmoney_l.string = LANG.format(LANG.L6004,Math.floor(INFO.money))
        this.exp_ability_l.string = LANG.format(LANG.L6005,INFO.exp,INFO.ability)
    }

    initJobList(page){
        //初始job ID = 1
        let jobs = API.getAPI('job')
        this.joblistLayout.removeAllChildren();
        for(let i= 0; i < 3; i++){
            let job_f = cc.instantiate(this.job_fab);
            job_f.getComponent(JobList).initView(jobs[INFO.monthJobRandom[i+(page-1)*3]]);
            job_f.on('jobclick' , this.onJobBtnClick.bind(this));
            this.joblistLayout.addChild(job_f);
        }
    }

    onJobBtnClick(evt,res){
        if(INFO.changeJob < 1){
            Alert.getInstance().show(LANG.L6012);
        }else{
            let jobArr = API.getAPI('job')
            let rarr = res.split('_');//能力，经验，中介费，薪水,id
            let that = this;
            if(INFO.job == parseInt(rarr[4])){
                Alert.getInstance().show(LANG.L6006);
            }else if(INFO.ability< parseInt(rarr[0]) && INFO.exp < parseInt(rarr[1])){
                Alert.getInstance().show(LANG.L6007);
            }else if(INFO.ability< parseInt(rarr[0])){
                Alert.getInstance().show(LANG.L6008);
            }else if(INFO.exp < parseInt(rarr[1])){
                Alert.getInstance().show(LANG.L6009);
            }else if(INFO.money < parseInt(rarr[2])){
                Alert.getInstance().show(LANG.L6010);
            }else{
                console.log("各项均达到要求，应聘成功");
                let a = jobArr[parseInt(rarr[4])-1];
                Alert.getInstance().show(LANG.format(LANG.L6011,rarr[2],rarr[3]),
                function(){
                    INFO.job = rarr[4]; // 职业变更
                    INFO.changeJob -= 1; //本月可操作次数减1
                    INFO.money -= parseInt(rarr[2]); //钱去掉中介费
                    INFO.salary = parseInt(rarr[3]); //每月薪水更改值
                    INFO.ability += a.ability; //能力值增加
                    INFO.exp += a.exp;  //经验值增加
                    INFO.happy += a.happy; //快乐值增加
                    INFO.social += a.social; //交际值增加
                },LANG.format(LANG.L6013,a.ability,a.exp,a.happy,a.social));
            }
        }
    }

    
    onLeaveBtnClick(){
        cc.director.loadScene('MainScene');
    }

    onRefreshBtnClick(){
        if(INFO.friends_Invited < 3){
            //邀请三个及以上好友，每月即可增加一次免费刷新次数,立即邀请?
            Alert.getInstance().show2(LANG.L8010,function(){
                cc.director.loadScene('InviteScene')
            })
        }else if(INFO.jobRefreshTime > 0 ){
            // this.totalPageNumber++;
            this.currentPage++;
            this.refresh_l.string = LANG.format(LANG.L8001,this.currentPage)
            this.createRandom();
            this.initJobList(this.currentPage);
            INFO.jobRefreshTime -= 1; //可刷新次数-1
        }else{
            //不能刷新,本月可刷新次数已用完
            Alert.getInstance().show(LANG.L8009)
        }
        
    }  

    createRandom(){
        let jobs = API.getAPI('job')
        //随机出三个不一样的值,0-jobs.length-1
        let randomOne = Math.round(Math.random()*(jobs.length-1));
        while(jobs[randomOne].id == INFO.job){
            randomOne = Math.round(Math.random()*(jobs.length-1));
        }
        let randomTwo = Math.round(Math.random()*(jobs.length-1));
        while(randomTwo == randomOne || jobs[randomTwo].id == INFO.job){
            randomTwo = Math.round(Math.random()*(jobs.length-1));
        }
        let randomThree = Math.round(Math.random()*(jobs.length-1));
        while(randomThree == randomOne || randomThree == randomTwo || jobs[randomThree].id == INFO.job){
            randomThree = Math.round(Math.random()*(jobs.length-1));
        }
        INFO.monthJobRandom[0+(this.currentPage-1)*3] = randomOne;
        INFO.monthJobRandom[1+(this.currentPage-1)*3] = randomTwo;
        INFO.monthJobRandom[2+(this.currentPage-1)*3] = randomThree;    
    }
}
