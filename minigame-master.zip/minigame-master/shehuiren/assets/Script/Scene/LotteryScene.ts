import { INFO } from "../Data/Info";
import { SYSTEM } from "../Data/System";
import { LANG } from "../Utils/Lang";
import Alert from "../Comps/Alert";

/*******************************************
 *  彩票界面
 *  @since 2018.08.24
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class LotteryScene extends cc.Component {
    @property(cc.Label)
    wallet: cc.Label = null;

    @property(cc.Label)
    result: cc.Label = null;

    @property(cc.Sprite)
    btnGray: cc.Sprite = null;

    @property(cc.Node)
    detail: cc.Node = null;

    start () {
        this.detail.active = false;
        let a = INFO.lotTimes == 1 ? false : true;
        this.btnGray.node.active = a;
        this.wallet.string = LANG.format(LANG.L4001, INFO.money);
    }

    //购买彩票, 每月只能买一次, （这里设定是每次加载场景只能买一次）
    _flag: boolean = true;
    onBuyLottery(){
        if(this._flag && INFO.lotTimes == 1){
            console.log('购买彩票');
            this.btnGray.node.active = true;
            this._flag = false;
            this.result.string = SYSTEM.buyLottery();
            this.wallet.string = LANG.format(LANG.L4001, INFO.money);
        }
        else{
            Alert.getInstance().show(LANG.L4002);
            console.log('每月只能买一次!');
        }
    }

    //提升运气, 邀请好友？
    onImproveLuck(){
        console.log('提升运气');
        cc.sys.localStorage.setItem('inviteBack', 'lottery');
        cc.director.loadScene('InviteScene');
    }

    //概率详情
    onDetail(){
        console.log('概率详情');
        this.detail.active = true;
        
        INFO.month = 0;
        cc.director.loadScene('FinishScene');
    }

    //关闭概率详情
    onClose(){
        console.log('关闭概率详情');
        this.detail.active = false;
    }

    //离开彩票界面
    onLeave(){
        console.log('离开彩票界面');
        cc.director.loadScene('MainScene');
    }

}
