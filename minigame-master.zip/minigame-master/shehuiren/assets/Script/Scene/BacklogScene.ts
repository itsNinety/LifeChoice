import { INFO } from "../Data/Info";
import BacklogList from "../Prefab/BacklogList";
import { API } from "../Utils/APITool";
import { UTILS } from "../Utils/Utils";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  待办事项界面
 *  @since 2018.08.28
 *  @author qll
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class BacklogScene extends cc.Component {
    
    public static instance : BacklogScene;

    public static getInstance():BacklogScene{
        if(!BacklogScene.instance) {
            BacklogScene.instance = new BacklogScene();
        }
        return BacklogScene.instance;
    }

    @property(cc.Prefab)
    backlog_fab : cc.Prefab = null;

    @property(cc.Label) //剩余时间提示
    resttimetip_l: cc.Label = null;

    @property(cc.Node) //无待办事项的小提示
    notodo :cc.Node = null;

    @property(cc.Node) //正在执行的待办时间的悬挂点(拖延症状态下)
    executing_content: cc.Node = null;

    @property(cc.Node)
    countdown: cc.Node = null;

    @property(cc.Label)
    countdown_l :cc.Label = null;

    @property(cc.ScrollView)
    executingScrollView: cc.ScrollView = null;


    start(){
        this.initBacklog();
        if(INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length || INFO.currentFirstEventId == -1){
        }else{
            if(UTILS.countdownFlag == false){
                UTILS.countDown();
            }
        }
    }
    
    update(){
        this.refreshAllTime();
    }

    refreshAllTime(){
        this.executing_content.height = INFO.arr_backlog.length*130;
        this.resttimetip_l.string = LANG.L11012 + INFO.lefttime +LANG.L11013;
        if(INFO.backlogRestTime % 60 == 0){
            this.countdown_l.string = LANG.L11014 +(INFO.backlogRestTime-INFO.backlogRestTime% 60)/60+':00';
        }else if(INFO.backlogRestTime % 60 < 10){
            this.countdown_l.string = LANG.L11014 + (INFO.backlogRestTime- INFO.backlogRestTime % 60)/60+':0'+INFO.backlogRestTime % 60;
        }else{
            this.countdown_l.string = LANG.L11014 + (INFO.backlogRestTime-INFO.backlogRestTime % 60)/60+':'+INFO.backlogRestTime% 60;
        }
        if(INFO.currentFirstEventId != -1){
            this.countdown.active = false;
            //说明进来的时候第一个事件正在执行
            if(INFO.backlogRestTime <=0 ){
                //第一个事件结束了，返回主界面时候要显示一下,并且更新属性
                INFO.needShowFirst = true;
                console.log("第一个结束")
                this.countdown.active = true;
                INFO.currentFirstEventId = -1;
                console.log(INFO.currentBacklogIndex)
                this.initBacklog();
                this.countdown.parent = this.executing_content.getChildByName(INFO.currentBacklogIndex.toString());
                this.countdown.setPosition(450,10);
                INFO.backlogRestTime = -API.getAPI('daily_event')[INFO.currentBacklogIndex].time_cost/10 *60;
                if(UTILS.countdownFlag == false){
                    UTILS.countDown();
                }
            }
        }else{
            this.countdown.parent = this.executing_content.getChildByName(INFO.currentBacklogIndex.toString());
            this.countdown.setPosition(450,10);
            if(INFO.backlogRestTime <= 0){
                let node = this.executing_content.getChildByName(INFO.currentBacklogIndex.toString())
                this.executing_content.removeChild(node)
                let newNode = cc.instantiate(this.backlog_fab);
                newNode.getComponent(BacklogList).initView2(INFO.arr_backlog[INFO.currentBacklogIndex]);
                this.executing_content.insertChild(newNode,INFO.currentBacklogIndex)
                //更新INFO属性
                console.log("INFO属性正常更新",INFO.currentBacklogIndex)
                let daily = API.getAPI('daily_event');
                let a = daily[INFO.arr_backlog[INFO.currentBacklogIndex].id-1];
                INFO.lefttime += a.time_cost;
                INFO.ability += a.ability;
                INFO.exp += a.exp;
                INFO.social += a.social;
                INFO.happy += a.happy;
                INFO.health += a.health;
                INFO.morality += a.morality;
                INFO.money += a.money;
                if(INFO.currentBacklogIndex < INFO.arr_backlog.length-1){
                    INFO.currentBacklogIndex++;
                    this.initBacklog();
                    INFO.backlogRestTime = -API.getAPI('daily_event')[INFO.currentBacklogIndex].time_cost/10 *60;;
                    UTILS.countDown();
                }else{
                    //执行完了
                    console.log("无需再回调")
                    INFO.currentBacklogIndex = INFO.arr_backlog.length;
                    this.initBacklog();
                    INFO.backlogRestTime = 1;
                }
            }
        }

    }

    initBacklog(){
        if(INFO.arr_backlog.length == 0){
            this.notodo.active = true;
        }else{
            this.notodo.active = false;
        }

        this.executing_content.removeAllChildren(true);
        if(INFO.currentBacklogIndex == INFO.arr_backlog.length){
            for(let i =0; i< INFO.arr_backlog.length; i++){
                let ico = cc.instantiate(this.backlog_fab);
                ico.getComponent(BacklogList).initView2(INFO.arr_backlog[i]);
                this.executing_content.addChild(ico,1,i.toString());   
            }
        }else{
            for(let i =0; i< INFO.arr_backlog.length; i++){
                if(i < INFO.currentBacklogIndex){
                    let ico = cc.instantiate(this.backlog_fab);
                    ico.getComponent(BacklogList).initView2(INFO.arr_backlog[i]);
                    this.executing_content.addChild(ico,1,i.toString());
                }else if(INFO.currentBacklogIndex == i){
                    if(INFO.currentFirstEventId == -1){
                        let ico = cc.instantiate(this.backlog_fab);
                        ico.getComponent(BacklogList).initView3(INFO.arr_backlog[i]);
                        this.executing_content.addChild(ico,1,i.toString());
                    }else{
                        let ico = cc.instantiate(this.backlog_fab);
                        ico.getComponent(BacklogList).initView(INFO.arr_backlog[i]);
                        this.executing_content.addChild(ico,1,i.toString());
                    }
                }else{
                    let ico = cc.instantiate(this.backlog_fab);
                    ico.getComponent(BacklogList).initView(INFO.arr_backlog[i]);
                    ico.on('backlogremoveclick' , this.onBacklogRemove.bind(this));
                    this.executing_content.addChild(ico,1,i.toString());
                }
            }
        }
    }

    onBacklogRemove(evt,res){
        console.log("移除"+res+"待办事项")
        INFO.arr_backlog.forEach(element => {
            console.log(element.id,res)
            if(element.id == parseInt(res)){
                for (let i = 0; i<INFO.arr_backlog.length; i++){
                    if(INFO.arr_backlog[i] == element){
                        var index = i;
                    }
                }
                let daily = API.getAPINode('daily_event' , 'id' , INFO.arr_backlog[index].id );
                INFO.arr_backlog.splice(index,1)
                //虚假时间、金钱更新
                console.log("虚假时间-",daily.time_cost)
                INFO.fakeLeftMoney -= daily.money;
                INFO.fakeLeftTime -= daily.time_cost;
            }
        });
        //INFO.arr_backlog.splice(INFO.arr_backlog.findIndex((item) => {return item.id == 10}), 1);
        //INFO.arr_backlog.splice(parseInt(res)-1,1); //INFO中的待办事项数组删掉此项
        this.initBacklog();
    }

    onLeave(){
        cc.director.loadScene('MainScene')
    }
}
