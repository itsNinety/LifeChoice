import { INFO } from "../Data/Info";
import { API } from "../Utils/APITool";
import { LANG } from "../Utils/Lang";
import { CONFIG } from "../Data/Config";
import Alert from "../Comps/Alert";
import { UTILS } from "../Utils/Utils";
import { HDATA } from "../Data/HouseData";
import { HTTP } from "../Utils/Http";

/*******************************************
 *  成绩单界面
 *  @since 2018.09.03
 *  @author qll
 * 
 *******************************************/


const {ccclass, property} = cc._decorator;

@ccclass
export default class FinishScene extends cc.Component {

    @property(cc.Node)
    hexagonalNode: cc.Node = null;

    @property(cc.Node)
    healthNode: cc.Node = null;

    @property(cc.Node)
    abilityNode: cc.Node = null;

    @property(cc.Node)
    expNode: cc.Node = null;

    @property(cc.Node)
    socialNode: cc.Node = null;

    @property(cc.Node)
    moralityNode: cc.Node = null;

    @property(cc.Node)
    happyNode: cc.Node = null;

    @property(cc.Node)
    randomNode: cc.Node = null;

    @property(cc.Label)
    money_l: cc.Label = null;

    @property(cc.Label)
    job_l: cc.Label = null;

    @property(cc.Label)
    house_l : cc.Label = null;

    @property(cc.Label)
    car_l : cc.Label = null;

    @property(cc.Label)
    lover_l : cc.Label = null;

    @property(cc.Label)
    loverdialogue_l: cc.Label = null;

    @property(cc.Label)
    health_l : cc.Label = null;

    @property(cc.Label)
    ablity_l : cc.Label = null;

    @property(cc.Label)
    exp_l : cc.Label = null;

    @property(cc.Label)
    social_l : cc.Label = null;

    @property(cc.Label)
    morality_l : cc.Label = null;

    @property(cc.Label)
    happy_l : cc.Label = null;

    @property(cc.Node)
    advertise: cc.Node = null;

    @property(cc.Node)
    qrCodeBg: cc.Node = null;

    @property(cc.Node)
    savePic: cc.Node = null;

    @property(cc.Sprite)
    carSprite: cc.Sprite = null;

    @property(cc.Sprite)
    avanta: cc.Sprite = null;

    @property(cc.Label)
    username: cc.Label = null;
        
    @property(cc.Label)
    score_l: cc.Label = null; //大佬分数

    @property(cc.Label) //大佬排名
    Rank_l: cc.Label = null;

    @property(cc.Label)
    ending: cc.Label = null;

    wallet;
    start () {
        //计算分数
        this.wallet = INFO.money + INFO.stock_money;
        this.score(INFO.health,INFO.happy,INFO.social,INFO.morality,INFO.ability,INFO.exp,this.wallet);
        //上传分数到服务器
        let that = this;
        this.upLoad(function(){
            //初始化剧情描述
            that.initEnding();
            //初始化界面
            that.initInfo();
        });

        //雷达图绘制
        this.drawRadar();
    }

    //初始化剧情描述
    initEnding(){
        let endingOne   = API.getAPINodes('game_end','type',1);
        let endingTwo   = API.getAPINodes('game_end','type',2);
        let endingThree = API.getAPINodes('game_end','type',3);
        let endingFour  = API.getAPINodes('game_end','type',4);
        //console.log(endingFour);
        // endingOne.sort(this.sortNumber); 
        // endingTwo.sort(this.sortNumber);
        // endingThree.sort(this.sortNumber);
        this.checkArr(endingOne);
        this.checkArr(endingTwo);
        this.checkArr(endingThree);
        this.checkLoveArr(endingFour);
    }

    //判断是哪个属性区间
    checkArr(arr){
        for(let i = 0; i<arr.length; i++){
            if(UTILS.judgeInterval(arr[i].attr_above,arr[i].attr_below)){
                this.ending.string += '['+arr[i].title+']:'+arr[i].desc+'\n';
                break;
            }
        }
    }

    //判断感情线结局
    checkLoveArr(arr){
        for (let i = 0; i<arr.length; i++){
            if(UTILS.checkLoveAttr(arr[i].attr_above) == true){
                this.ending.string += '['+arr[i].title+']:'+arr[i].desc+'\n';
                //socre加上
                break;
            }
        }
    }

    //伴侣分的计算
    npcScore(arr){
        for (let i = 0; i<arr.length; i++){
            if(UTILS.checkLoveAttr(arr[i].attr_above) == true){
                INFO.score += parseInt(arr[i].score);
                break;
            }
        }
    }

    createImage(sprite,url){
        if(typeof(wx) == 'undefined') return;
        let image = wx.createImage();
        image.onload = function () {
            let texture = new cc.Texture2D();
            texture.initWithElement(image);
            texture.handleLoadedTexture();
            texture.height = 66;
            texture.width = 66;
            sprite.spriteFrame = new cc.SpriteFrame(texture);
        };
        image.src = url;
    }    

    //初始化界面上相关信息
    initInfo(){
        //初始化其它
        let that = this;
        this.score_l.string = Math.floor(INFO.score).toString();
        //this.Rank_l.string = this.getCount().toString();
        this.getCount();
        this.username.string = INFO.name.toString();
        this.createImage(that.avanta,INFO.headimg_url);
        this.advertise.active = false;
        this.qrCodeBg.active = false;
        this.money_l.string = Math.floor(INFO.money).toString();
        this.job_l.string = API.getAPI('job')[INFO.job - 1].company +'\n'+ API.getAPI('job')[INFO.job - 1].job;
        if(INFO.house == -1){
            this.house_l.string = LANG.L12002;
        }else{
            this.house_l.string = API.getAPI('house')[INFO.house -1].house;
        }
        if(INFO.car == -1){
            this.car_l.string = LANG.L12001;
        }else{
            this.car_l.string = API.getAPI('car')[INFO.car - 1].car;
            cc.loader.load(LANG.format(CONFIG.carurl , API.getAPI('car')[INFO.car -1].pic),function (err, texture) {
                var frame=new cc.SpriteFrame(texture);
                that.carSprite.spriteFrame=frame;
            });
        }
        if(INFO.lover == -1){
            this.lover_l.string = LANG.L12003;
        }else{
            let lover = API.getAPINode('npc','id',INFO.lover);
            this.lover_l.string = lover.name + ' ' +lover.title;
            this.loverdialogue_l.string = lover.dialogue;
        }
        this.health_l.string   = INFO.health.toString();
        this.ablity_l.string   = INFO.ability.toString();
        this.exp_l.string      = INFO.exp.toString();
        this.social_l.string   = INFO.social.toString();
        this.morality_l.string = INFO.morality.toString();
        this.happy_l.string    = INFO.happy.toString();
        //this.friendRank_l
    }

    //分数计算公式
    score(health,happy,social,morality,ability,exp,wallet){
        INFO.score = health*10 + happy*10 + social*10 + morality*15 + ability*2 + exp*2;
        if(wallet < 2100000000){
            INFO.score += INFO.money/10000;
        }else{
            INFO.score += 2100000000/10000 + (wallet-2100000000)/1000000;
        }
        INFO.score += INFO.salary/10;
        if(INFO.car != -1){
            let car = API.getAPI('car')[INFO.car-1];
            INFO.score += car.month_cost / 2;
        }
        if(INFO.house != -1){
            let house = API.getAPI('house')[INFO.house-1];
            INFO.score += house.basic_price * HDATA.getCurr_hindex() / 10000;
        }
        //伴侣分
        let endingFour = API.getAPINodes('game_end','type',4);
        this.npcScore(endingFour);

        if(INFO.isPostgraduate == true){
            //是研究生
            INFO.score *= 1.005;
        }
        INFO.score = Math.floor(INFO.score);
    }

    //绘制雷达图
    drawRadar(){
        this.healthLine(INFO.health / 9999);
        this.ablityLine(INFO.ability/ 9999);
        this.expLine(INFO.exp/ 9999);
        this.socialLine(INFO.social / 9999);
        this.moralityLine(INFO.morality/ 9999);
        this.happyLine(INFO.happy/ 9999);
        this.randomNode.parent = this.hexagonalNode;
        let graphics = this.randomNode.getComponent(cc.Graphics);
        graphics.moveTo(this.healthNode.x,this.healthNode.y);
        graphics.lineTo(this.abilityNode.x,this.abilityNode.y);
        graphics.lineTo(this.expNode.x,this.expNode.y);
        graphics.lineTo(this.socialNode.x,this.socialNode.y);
        graphics.lineTo(this.moralityNode.x,this.moralityNode.y);
        graphics.lineTo(this.happyNode.x,this.happyNode.y);
        graphics.lineTo(this.healthNode.x,this.healthNode.y);
        let fillColor = new cc.Color(73,70,96,35);
        let strokeColor = new cc.Color(120,120,188)
        graphics.fillColor = fillColor;
        graphics.strokeColor = strokeColor;
        graphics.stroke();
        graphics.fill();
    }

    healthLine(scale){
        this.healthNode.x = 0;
        this.healthNode.y = 94 * scale;
    }

    ablityLine(scale){
        //y= (-47/81)*x
        this.abilityNode.x = -81 * scale;
        this.abilityNode.y = 47 * scale;
    }

    expLine(scale){
        this.expNode.x = -81 * scale;
        this.expNode.y = -47 * scale;
    }

    socialLine(scale){
        this.socialNode.x = 0;
        this.socialNode.y = -94 * scale;
    }

    moralityLine(scale){
        this.moralityNode.x = 81 * scale;
        this.moralityNode.y = -47 * scale;
    }

    happyLine(scale){
        this.happyNode.x = 81 * scale;
        this.happyNode.y = 47 * scale;
    }

    imgSrc :string = '';
    onSavePicClicked(){
        let that = this;
        this.modify()
        //this.screenShoot();
    }

    modify(){
        let that = this;
        this.advertise.active = true;
        this.qrCodeBg.active = true;
        this.savePic.active = false;
        this.scheduleOnce(function(){
            that.screenShoot();
        },0.2)
        
    }

    screenShoot(){
        if(!(cc.sys.platform === cc.sys.WECHAT_GAME)) return;
        let that = this;
        //先截屏
        var canvas = cc.game.canvas;
        // var width  = cc.winSize.width;
        // var height  = cc.winSize.height;
        // var widthone = 1000;
        // var heightone = 2200;
        canvas.toTempFilePath({
            x: 0,
            y: 0,
            // width: width,
            // height: height,
            // destWidth: widthone,
            // destHeight: heightone,
            success (res) {
                //.可以保存该截屏图片
                console.log(res)
                // wx.shareAppMessage({
                //     imageUrl: res.tempFilePath
                // })
                that.imgSrc = res.tempFilePath;
                //console.log("imgSrc:",that.imgSrc)
                that.savePhoto();
            }
        });
    }

    savePhoto(){
        //再保存
        var self = this;
        let that = this;
        console.log("SavePhotoimgSrc:",that.imgSrc)
        if(!(cc.sys.platform === cc.sys.WECHAT_GAME)) return;
        wx.getSetting({
            success(res) {
                if (!res.authSetting['scope.writePhotosAlbum']) { //未授权
                    wx.authorize({
                        scope:'scope.writePhotosAlbum',
                        success() {
                            console.log('授权成功')
                            //wx.downloadFile({
                                //url: that.imgSrc,
                                //success:function (res1) {
                                    //console.log(res1);
                                    wx.saveImageToPhotosAlbum({
                                        filePath: that.imgSrc,
                                        success:function (data) {
                                            console.log(data);
                                            self.showTipsUI();
                                        },
                                        fail:function (err) {
                                            console.log(err);
                                        }
                                    });
                                //}
                            //});
                        },
                        fail() {
                            console.log("授权失败");
                            wx.showModal({
                                title: '提示',
                                content: '点击确定，保存图片到相册。',
                                success:function(res){
                                    if (res.confirm){
                                        wx.openSetting({
                                            success(res){
                                                console.log("重新获得保存图片授权状态");
                                                if (res.authSetting["scope.writePhotosAlbum"]){ //如果用户重新同意了授权登录
                                                    //wx.downloadFile({
                                                        //url: that.imgSrc,
                                                       // success:function (res1) {
                                                            //console.log(res1);
                                                            wx.saveImageToPhotosAlbum({
                                                                filePath: that.imgSrc,
                                                                success:function (data) {
                                                                    console.log(data);
                                                                    self.showTipsUI();
                                                                },
                                                                fail:function (err) {
                                                                    console.log(err);
                                                                }
                                                            });
                                                       // }
                                                    //});
                                                }
                                            },
                                            fail(){
                                                console.log("重新获得保存图片授权状态失败");
                                            }
                                        }) 
                                    }
                                }
                            })
                        }
                    });
                }else{ //已授权
                    //无需下载了
                    // wx.downloadFile({
                        // url: that.imgSrc,
                        // success:function (res1) {
                        //     console.log("success",res1);
                            wx.saveImageToPhotosAlbum({
                                // filePath: res1.tempFilePath,
                                filePath: that.imgSrc,
                                success:function (data) {
                                    console.log(data,"图片保存成功");
                                    self.showTipsUI();
                                },
                                fail:function (err) {
                                    console.log(err);
                                }
                            });
                        }
                        // fail:function(){
                        //     console.log("download fail")
                        // }
                    // });
                //}
            }
        });
    }

    showTipsUI(){
        let self = this;
        console.log("showTipsUI")
        Alert.getInstance().show(LANG.L12000,function(){
            self.savePic.active   = true;
            self.advertise.active = false;
            self.qrCodeBg.active  = false;
        })
    }


    totalRank(){
        cc.director.loadScene('TopRankingScene');
    }

    friendRank(){
        cc.director.loadScene('RankingScene');
    }

    //测试准备工作
    upLoad(cb){
        let job   = API.getAPI('job')[INFO.job -1];
        let house = API.getAPI('house')[INFO.house -1];
        let car   = API.getAPI('car')[INFO.car -1];
        let lover = API.getAPINode('npc','id',INFO.lover);
        let json, jobdata, cardata, housedata, loverdata;
        jobdata   = job.company + job.job;
        cardata   = (INFO.car == -1) ? LANG.L12001: car.car;
        housedata = (INFO.house == -1) ? LANG.L12002 : house.house;
        loverdata = (INFO.lover == -1) ? LANG.L12003 : (lover.name + ' ' +lover.title);
        json      = {"wallet":INFO.money,"age":INFO.age,"position":jobdata,"lover":loverdata,"car":cardata,"house":housedata};
        //console.log('Math.floor(INFO.score) = ', Math.floor(INFO.score));
        this._upToServer(Math.floor(INFO.score), json);
        this._upToWXServer(Math.floor(INFO.score), INFO.open_id, INFO.name, INFO.headimg_url, INFO.sex, json);
        cb();
    }
    
    /**
     * 测试排行榜
     */
    //上传到服务器
    _upToServer(num, info){
        let par = {};
        par.user_id = INFO.user_id;
        par.open_id = INFO.open_id;
        par.score = num;
        par.info = JSON.stringify(info);
        //console.log('par = ', par);
        HTTP.httpPost(INFO.url_upload, par, function(data){
            if(parseInt(data) != -1){
                console.log('上传服务器返回: ', JSON.parse(data));
                //cb();url_getTop
            }
        })
    }
    //托管到微信服务器
    _upToWXServer(score , open_id , nick_name , headimg_url , gender , info){
        let that = this;
        if(typeof(wx) != 'undefined'){
            let value = {"score" : score, "open_id":open_id, 
            "nick_name":nick_name, "headimg_url":headimg_url, 
            "gender":gender, "info":info};
            //, "nick_name":INFO.nick_name, "heading_url":INFO.headimg_url
            wx.setUserCloudStorage({
                KVDataList: [{'key':'a' , 'value':JSON.stringify(value)}],
                success: function(res) {
                    console.log('成功上传到微信服务器:' , res);
                    //让子域更新当前用户的得分，因为主域无法得到getUserCloadStorage;
                },
                fail : function(res){
                    console.log('上传到微信服务器失败:' , res);
                },
                complete : function(res){
                    console.log('完成上传到微信服务器:' , res);
                }
            });
        }
    }

    getCount(){
        let that = this;
        new Promise((resolve,reject)=>{
            let par = {};
            par.score = 1;
            HTTP.httpPost(INFO.url_getScore, par, function(data){
                if(parseInt(data) != -1){
                    var json = JSON.parse(data);
                    //console.log('获取总排名返回: ', json);
                    console.log('名次json.count = ',(parseInt(json.count) + 1));//top排行名次
                    that.Rank_l.string = (parseInt(json.count) + 1).toString();    
                    resolve();
                } 
            })
        }).then(function(value){
            //do something
        })
    }

}
