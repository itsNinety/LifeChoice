import { INFO } from "../Data/Info";
import Details from "../Prefab/Details";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  排行榜界面
 *  @since 2018.08.28
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class RankingScene extends cc.Component {
    //画布
    @property(cc.Sprite)
    rankCanvas :cc.Sprite = null;
    //画布滑动捕捉
    @property(cc.Node)
    slideNode :cc.Node = null;
    //画布滑动捕捉
    @property(cc.Node)
    close :cc.Node = null;
    //定位点击悬挂点，layout
    @property(cc.Node)
    n: cc.Node = null;
    //btn_pb
    @property(cc.Prefab)
    details: cc.Prefab = null;
    
    onLoad(){
        console.log('排行榜界面');
        for(let i = 0; i < 100; i++){
            let item = cc.instantiate(this.details);
            item.getComponent(Details).init(i);
            item.getComponent(Details).rks = this;
            this.n.addChild(item);
        }
        let item = cc.instantiate(this.details);
        item.getComponent(Details).init(-10);
        item.getComponent(Details).rks = this;
        this.node.addChild(item);
        item.setPosition(240, -316);
        
        //this.upLoad();

        if(typeof(wx) == 'undefined') return;
        //微信开启群分享, 要在页面进来的最开始就执行，放在 onLaunch 或者 onLoad 生命周期函数里, 
        //如果没有设置 wx.showShareMenu, 是没有任何 shareTickets 返回的。
        wx.updateShareMenu({
            withShareTicket: true,
        })
        //子域显示排行榜
        wx.getOpenDataContext().postMessage({
            message: 'rank',
        })
    }

    tex : cc.Texture2D
    start(){
        this.tex = new cc.Texture2D();
        let that = this;
        this.slideNode.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            let delta = event.touch.getDelta();
            let d = Math.round(delta.y);
            if(typeof(wx) != 'undefined'){
                if(d != 0){
                    //console.log('distance = ', d);
                    if(that.n.y >= 286 - d && that.n.y <= 1360 - d){
                        var row = {};
                        row.id = -1;
                        row.d = d;
                        wx.postMessage({
                            message: row,
                        })
                        that.n.y += d;
                    }
                }
            }
        });
    }

    onGroupShare(){
        console.log('onGroupRankingClick().');
        if(typeof(wx) == 'undefined') return;
        let index_img = Math.floor(Math.random()*4);
        let index_share = Math.floor(Math.random()*3);
        cc.loader.loadRes("",function(err,data){
            wx.shareAppMessage({
                title: LANG.shareCopywriting[index_share],
                imageUrl: LANG.format(LANG.shareUrl, index_img),
                query: 'Uid='+INFO.user_id,
                success(res){
                    console.log("转发成功");
                    if(res.shareTickets == null || res.shareTickets == undefined || res.shareTickets == ""){ //没有群信息，说明分享的是个人
                        console.log("res.shareTickets is null");
                        
                    }else{ //有群信息
                        console.log("res.shareTickets is not null");
                        console.log("res = " + res.shareTickets);
                        if(res.shareTickets.length > 0){ 
                        }
                    }
                },
                fail(res){
                    console.log("转发失败");
                } 
            })
        });
        wx.postMessage({
            message: 'group',
        })
    }
    //点击关闭详情
    closeAlert(){
        if(typeof(wx) == 'undefined') return;
        wx.postMessage({
            message: 'close',
        })
        this.close.active = false;
    }

    onLeave(){
        console.log('onLeave()');
        if(INFO.month <= 0){
            cc.director.loadScene('FinishScene');
        }
        else{
            cc.director.loadScene('StartScene');
        }
    }

    // 刷新开放数据域的纹理
    _updateSubDomainCanvas () {
        if (!this.tex) {
            console.log('!this.tex');
            return;
        }
        if(typeof(wx) == 'undefined') return;
        var openDataContext =  wx.getOpenDataContext();
        var sharedCanvas = openDataContext.canvas;
        this.tex.initWithElement(sharedCanvas);
        this.tex.handleLoadedTexture();
        this.rankCanvas.spriteFrame = new cc.SpriteFrame(this.tex);
    };

    update () {
        this._updateSubDomainCanvas();
    }

}