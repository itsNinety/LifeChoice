import { CONFIG } from "../Data/Config";
import { INFO } from "../Data/Info";
import { HTTP } from "../Utils/Http";
import Alert from "../Comps/Alert";
import { LANG } from "../Utils/Lang";

/*******************************************
 *  开始界面 负责加载
 *  @since 2018.08.22
 *  @author zen
 *  
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class StartScene extends cc.Component {
    

    @property(cc.Node)
    phoneNode : cc.Node = null;

    @property(cc.Node)
    coverphone: cc.Node = null;

    @property(cc.Node)
    restartNode :cc.Node = null;

    @property(cc.Node)
    moreGameBtn: cc.Node = null;

    @property(cc.Node)
    friendRankBtn: cc.Node = null;

    public invite = 0;//邀请我的好友的user_id

    public start () {
        let that = this;
        this.coverphone.runAction(cc.repeatForever(cc.sequence(cc.moveBy(0.5,cc.p(0,30)),cc.moveBy(0.5,cc.p(0,-30)))))
        this.phoneNode.on(cc.Node.EventType.TOUCH_START,that.onStart,this)
        this.restartNode.active = false;
        this.moreGameBtn.x = -170;
        this.friendRankBtn.x = 170;
        //使用方法
        let info = cc.sys.localStorage.getItem('saveData');
        if(info){
            //继续游戏
            this.restartNode.active = true;
            this.moreGameBtn.x = -188;
            this.friendRankBtn.x = 0;
            this.phoneNode.off(cc.Node.EventType.TOUCH_START,that.onStart,this)
            this.phoneNode.on(cc.Node.EventType.TOUCH_START,that.onContinue,this)
        }

        //动画管理
        this.getComponent(cc.Animation).on('finished', function(){
            that.getComponent(cc.Animation).play('viewmove')
        }, this);



        if(CC_WECHATGAME){
            //监听玩家是否退出了游戏
            wx.onHide(function(){
                INFO.saveDataToLocal();
            })
        }
        
        if(typeof(wx) == 'undefined') return;
        //开启右上角的分享
        wx.showShareMenu();
        //监听右上角的分享调用
        cc.loader.loadRes("texture/share",function(err,data){
            // let index_img = Math.floor(Math.random()*3);
            // let index_share = Math.floor(Math.random()*3);
            wx.onShareAppMessage(function(res){
                return {
                    title: LANG.shareCopywriting[Math.floor(Math.random()*3)],
                    imageUrl:LANG.format(LANG.shareUrl, Math.floor(Math.random()*3)),
                    query: 'Uid='+INFO.user_id,
                    success(res){
                        console.log("右上角转发成功!!!");
                    },
                    fail(res){
                        console.log("右上角转发失败!!!");
                    } 
                }
            })
        });
        var LaunchOption  =  wx.getLaunchOptionsSync();
        if(LaunchOption.query.Uid != null){
            that.invite = LaunchOption.query.Uid;
        }
        //微信登陆，用户授权，拿到昵称、头像、性别数据
        that.wx_login().then(function(value){
            //服务器登陆，拿到open_id和历史最高分
            that.wxLogin();
        });
    }

    private onStart(){
        let info = cc.sys.localStorage.getItem('saveData');
        if(info){
            Alert.getInstance().show2(LANG.L0009 , function(){
                INFO.clearLocalData();
                cc.director.loadScene('GuideScene');
            })
        }else{
            INFO.clearLocalData()
            cc.director.loadScene('GuideScene');
        }
    }

    private onContinue(){
        let info = cc.sys.localStorage.getItem('saveData');
        info = JSON.parse(info);
        INFO.sex = info.sex;
        CONFIG.getSexData(function(){
            INFO.initDataFromLocal()
            INFO.initDelayBacklog()
            if(INFO.month <= 0){
                cc.director.loadScene('FinishScene');
            }else{
                cc.director.loadScene('MainScene');
            }
        })

    }

    public onMore(){

    }

    public onRank(){
        cc.director.loadScene('RankingScene');
    }

    //微信登陆
    wx_login(){
        return new Promise((resolve,reject)=>{
            let that = this;
            if(typeof(wx) != 'undefined'){
                let windowSize = cc.winSize;
                let button = wx.createUserInfoButton({
                    type: 'text',
                    text: '',
                    style: {
                        left: 0,
                        top: 0,
                        width: windowSize.width,
                        height: windowSize.height,
                    }
                })
                button.onTap(function(res){
                    if(res.userInfo){//用户授权
                        resolve();
                        button.destroy();
                        //let json = JSON.parse(res);
                        let json = res;
                        console.log("微信返回: ", json);
                        INFO.name = json.userInfo.nickName;
                        INFO.headimg_url = json.userInfo.avatarUrl;
                        let a = parseInt(json.userInfo.gender);
                        if(a == 1) INFO.sex = 1;
                        else INFO.sex = 0;
                    }
                    else{
                        that.wx_login();
                    }
                })
            }
        })
    }

    //服务器登陆
    wxLogin(cb : Function = null){
        return new Promise((resolve,reject)=>{
            let that = this;
            if(CC_WECHATGAME){
                wx.getSetting({
                    success: function (res) {
                        var authSetting = res.authSetting
                        if (authSetting['scope.userInfo'] === true) {
                            // 用户已授权，可以直接调用相关 API
                            // console.log('已经授权');
                            that._wx_login().then((value)=>{
                                resolve();
                            });
                        } else if (authSetting['scope.userInfo'] === false){
                            // 用户已拒绝授权，再调用相关 API 或者 wx.authorize 会失败，需要引导用户到设置页面打开授权开关
                            // console.log('已经拒绝过');
                        } else {
                            // 未询问过用户授权，调用相关 API 或者 wx.authorize 会弹窗询问用户
                            // console.log('未询问过');
                            that._wx_login().then((value)=>{
                                resolve();
                            });
                        }
                    },
                    fail : function(res){
                        console.log('fail' ,res);
                    },
                    complete :function(res){
                        // console.log('complete',res);
                    }
                })
            }else{
                console.log('非微信环境'  , CC_WECHATGAME)
            }    
        });    
    }
    //服务器登陆
    _wx_login(){
        //可以优化为登录信息加密保存在本地，不用再次请求，后面优化
        //2018.07.12
        return new Promise((resolve,reject)=>{
            let that = this;
            wx.login({
                success: function (data) {
                    // console.log('jscode = ', data.code);
                    let jscode = data.code;
                    let parm = {};
                    parm.code = jscode;
                    parm.invite = that.invite;
                    parm.avatar = INFO.headimg_url;
                    parm.nick = INFO.name;
                    parm.sex = INFO.sex;
                    //console.log(parm);
                    HTTP.httpPost(INFO.url_login ,parm, function(data){
                        // console.log(data);
                        if(parseInt(data) == -1){
                            // 没有请求成功
                            // console.log("没有请求成功!");
                            return;
                        }
                        if(parseInt(data) == -10000){
                            // 没有登录成功
                            // console.log("没有登录成功!");
                            return;
                        }
                        let json = JSON.parse(data);
                        console.log("服务器返回: ", json);
                        INFO.open_id = json.open_id;
                        INFO.user_id = json.user_id;
                        INFO.top_score = json.top_score;
                        resolve();
                    })
                }
            })      
        });          
    }

}
