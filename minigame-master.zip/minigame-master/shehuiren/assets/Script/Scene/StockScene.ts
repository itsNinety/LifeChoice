import { SYSTEM } from "../Data/System";
import { LANG } from "../Utils/Lang";
import { SDATA } from "../Data/StockData";

/*******************************************
 *  股票界面
 *  @since 2018.08.24
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class StockScene extends cc.Component {
    //钱包
    @property(cc.Label)
    wallet: cc.Label = null;
    //股票金额
    @property(cc.Label)
    money: cc.Label = null;
    //上月收益
    @property(cc.Label)
    last: cc.Label = null;
    //持有收益
    @property(cc.Label)
    earnings: cc.Label = null;
    //涨跌幅度
    @property(cc.Label)
    rate: cc.Label = null;
    //本月股票指数
    @property(cc.Label)
    stockIndex: cc.Label = null;


    //卖出, 输入框
    @property(cc.Label)
    sell: cc.Label = null;
    //买入, 输入框
    @property(cc.Label)
    buy: cc.Label = null;

    @property(cc.Node)
    lineNode: cc.Node = null;

    //字体颜色
    redColor = cc.color(255,80,80);
    greenColor = cc.color(27,167,126);
    //线条颜色
    whiteColor = cc.color(255,255,255);
    hLineColor = cc.color(70,70,97);
    vLineColor = cc.color(112,120,152);

    //线段节点对象池
    node_pool_line = new cc.NodePool();

    start () {
        for (let i = 0; i < 21; i++) {
            this.node_pool_line.put(new cc.Node());
        }
        this.initLine();
        //更新money, last, earnings, rate, stockIndex和图表
        let sData = SYSTEM.getStockData();
        //console.log('sData = ', sData);
        this.wallet.string = LANG.format(LANG.L3000, sData.wallet);//非负
        this.money.string = sData.money;
        if(sData.last_earnings >= 0){
            this.last.string = '+' + sData.last_earnings;
            this.last.node.color = this.redColor;
        }
        else{
            this.last.string = sData.last_earnings;
            this.last.node.color = this.greenColor;
        }
        if(sData.earnings >= 0){
            this.earnings.string = '+' + sData.earnings;
            this.earnings.node.color = this.redColor;
        }
        else{
            this.earnings.string = sData.earnings;
            this.earnings.node.color = this.greenColor;
        }
        let r = (sData.rate*100).toString();
        if(sData.rate >= 0){
            r = r.substr(0, 4);
            this.rate.string = '+' + r + '%';
            this.rate.node.color = this.redColor;
        }
        else{
            r = r.substr(0, 5);
            this.rate.string = r + '%';
            this.rate.node.color = this.greenColor;
        }
        this.stockIndex.string = LANG.format(LANG.L3001, sData.sindex);
        
        //深拷贝并排序的数组copy，各项为year_sindex对应项与year_sindex首项的差值
        let copy = [], max = 80;
        let len = SDATA.year_sindex.length;
        if(len >= 2){
            for(let i = 0; i < len; i++) 
            copy.push(SDATA.year_sindex[i] - SDATA.year_sindex[0]);
            copy.sort(this.compare);
            let temp = Math.max(-copy[0], copy[len-1]);
            if(temp <= 40) max = 40;
            else max = (max >= temp ? max : temp);
            //console.log('max = ', max);
        }
        for(let i = 0; i < len-1; i++){
            this.drawLine(cc.v2(-253 + i*45, (sData.year_sindex[i]-sData.year_sindex[0])*80/max), 
            cc.v2(-253 + (i+1)*45, (sData.year_sindex[i+1]-sData.year_sindex[0])*80/max), 3, this.whiteColor, this.lineNode);
        }
    }

    compare(v1, v2) {
        if (v1 < v2) return -1;
        else if (v1 > v2) return 1;
        else return 0;
    }

    //初始化固定的线段
    initLine(){
        //console.log('initLine()');
        this.lineNode.removeAllChildren(true);
        this.drawLine(cc.v2(-106,170), cc.v2(-106,227), 3, this.vLineColor, this.lineNode);
        this.drawLine(cc.v2(106,170), cc.v2(106,227), 3, this.vLineColor, this.lineNode);

        this.drawLine(cc.v2(-255,80), cc.v2(255,80), 1, this.hLineColor, this.lineNode);
        this.drawLine(cc.v2(-255,40), cc.v2(255,40), 1, this.hLineColor, this.lineNode);
        this.drawLine(cc.v2(-255,0), cc.v2(255,0), 1, this.hLineColor, this.lineNode);
        this.drawLine(cc.v2(-255,-40), cc.v2(255,-40), 1, this.hLineColor, this.lineNode);
        this.drawLine(cc.v2(-255,-80), cc.v2(255,-80), 1, this.hLineColor, this.lineNode);

        this.drawLine(cc.v2(-275,-270), cc.v2(-25,-270), 3, this.whiteColor, this.lineNode);
        this.drawLine(cc.v2(25,-270), cc.v2(275,-270), 3, this.whiteColor, this.lineNode);
    }

    //画线函数
    drawLine(s: cc.Vec2, e: cc.Vec2, width: number, color: cc.Color, parent:cc.Node){
        let node = null;
        if (this.node_pool_line.size() > 0) {
            node = this.node_pool_line.get();
        } 
        else {
            node = new cc.Node();
        }
        parent.addChild(node);
        var line = node.getComponent(cc.Graphics);
        if (!line) line = node.addComponent(cc.Graphics);
        line.moveTo(s.x, s.y);
        line.lineTo(e.x, e.y);
        line.lineWidth = width;
        line.strokeColor = color;
        line.stroke();
        line.fill();
    }

    //确定卖出
    onSell(){
        console.log('卖出', parseInt(this.sell.string));
        let data = SYSTEM.sellStock(parseInt(this.sell.string));
        console.log(data);
        if(data == 0){
            console.log('超过持有股票，无法卖出');
        }
        else{
            this.wallet.string = LANG.format(LANG.L3000, data.wallet);//非负
            this.money.string = data.money;
            if(data.earnings >= 0){
                this.earnings.string = '+' + data.earnings;
                this.earnings.node.color = this.redColor;
            }
            else{
                this.earnings.string = '' + data.earnings;
                this.earnings.node.color = this.greenColor;
            }
            this.sell.string = '';
        }
    }
    //确定买入
    onBuy(){
        console.log('买入', parseInt(this.buy.string));
        let data = SYSTEM.buyStock(parseInt(this.buy.string));
        console.log(data);
        if(data == 0){
            console.log('余额不足');
        }
        else{
            this.wallet.string = LANG.format(LANG.L3000, data.wallet);//非负
            this.money.string = data.money;
            if(data.earnings >= 0){
                this.earnings.string = '+' + data.earnings;
                this.earnings.node.color = this.redColor;
            }
            else{
                this.earnings.string = '' + data.earnings;
                this.earnings.node.color = this.greenColor;
            }
            this.buy.string = '';
        }
    }
    //离开
    onLeave(){
        cc.director.loadScene('MainScene');
    }
}
