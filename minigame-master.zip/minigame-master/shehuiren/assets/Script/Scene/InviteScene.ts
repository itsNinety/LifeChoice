import { LANG } from "../Utils/Lang";
import { INFO } from "../Data/Info";
import { HTTP } from "../Utils/Http";
import InviteHeadImg from "../Prefab/InviteHeadImg";

/*******************************************
 *  好友邀请界面
 *  @since 2018.08.31
 *  @author lyc
 * 
 *******************************************/
const {ccclass, property} = cc._decorator;

@ccclass
export default class InviteScene extends cc.Component {

    @property(cc.Prefab)
    headImg: cc.Prefab = null;
    //滑动捕捉
    @property(cc.Node)
    slideLR: cc.Node = null;
    @property(cc.Node)
    layoutLR: cc.Node = null;   
    @property(cc.Node)
    slideUD: cc.Node = null;
    @property(cc.Node)
    layoutUD: cc.Node = null;

    inviteFriends = [];
    toBeInvited = [];

    start () {
        for(let i = 0; i < 10; i++){
            let item = cc.instantiate(this.headImg);
            item.getComponent(InviteHeadImg).initView(i);
            this.layoutLR.addChild(item);
            this.toBeInvited[i] = item;
        }
        let that = this;
        that.slideLR.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            let delta = event.touch.getDelta();
            let d = Math.round(delta.x);
            if(d != 0){
                if(that.layoutLR.x + d <= -250 && that.layoutLR.x + d >= -730)
                that.layoutLR.x += d;
            }
        });
        that.slideUD.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            let delta = event.touch.getDelta();
            let d = Math.round(delta.y);
            if(d != 0){
                if(that.layoutUD.y + d >= 0 && that.layoutUD.y + d <= 320)
                that.layoutUD.y += d;
            }
        });
        that._getInvite().then(function(value){
            for(let i = 0; i < that.inviteFriends.length; i++){
                that.toBeInvited[i].getComponent(InviteHeadImg).initView(i, that.inviteFriends[i]);
            }
        });
    }

    close(){
        console.log('close()');
        if(cc.sys.localStorage.getItem('inviteBack') != 'lottery'){
            cc.director.loadScene('MainScene');
        }
        else{
            cc.sys.localStorage.setItem('inviteBack', 'main');
            cc.director.loadScene('LotteryScene');
        }
    }

    share(){
        console.log('share()');
        if(typeof(wx) == 'undefined') return;
        cc.loader.loadRes("",function(err,data){
            let index_img = Math.floor(Math.random()*4);
            let index_share = Math.floor(Math.random()*3);
            wx.shareAppMessage({
                title: LANG.shareCopywriting[index_share],
                imageUrl: LANG.format(LANG.shareUrl, index_img),
                query: 'Uid='+INFO.user_id,
                success(res){
                    console.log("转发成功!!!");
                    console.log('分享回执：', res);
                    if(res.shareTickets == null || res.shareTickets == undefined || res.shareTickets == ""){ //没有群信息，说明分享的是个人
                        console.log("res.shareTickets is null");
                    }else{ //有群信息
                        console.log("res.shareTickets is not null");
                        if(res.shareTickets.length > 0){ 
                        }
                    }
                },
                fail(res){
                    console.log("转发失败!!!");
                } 
            })
        });
    }

    //获取邀请用户列表接口
    _getInvite(){
        return new Promise((resolve,reject)=>{
            let that = this;
            let par = {};
            par.user_id = INFO.user_id;
            HTTP.httpPost(INFO.url_invite, par, function(res){
                if(parseInt(res) == -1){
                    //console.log("没有请求成功!");
                    return;
                }
                if(parseInt(res) == -10000){
                    console.log("没有登录成功!");
                    return;
                }
                console.log('获取邀请用户列表接口res: ', res);
                let json = JSON.parse(res);
                // console.log('after json.parse: ', json);
                // console.log('ret = ' , json.ret);
                // console.log('data = ', json.data);
                // console.log('data.length = ', json.data.length);
                for(let i = 0; i < json.data.length; i++){
                    //console.log(i,' = ', json.data[i]);
                    that.inviteFriends[i] = json.data[i].avatar;
                }
                INFO.friends_Invited = json.data.length;
                if(INFO.friends_Invited >= 3){
                    INFO.houseRefreshTime = 1;
                    INFO.carRefreshTime   = 1;
                    INFO.jobRefreshTime   = 1;
                }
                resolve();
            })
        })
    }
}
