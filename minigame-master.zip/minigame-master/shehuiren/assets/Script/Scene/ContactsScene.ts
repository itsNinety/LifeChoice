import { CONTACTS } from "../Npc/Contacts";
import { API } from "../Utils/APITool";
import PeopleItem from "../Comps/PeopleItem";
import { INFO } from "../Data/Info";

/*******************************************
 *  联系人界面
 *  @since 2018.08.27
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class ContactsScene extends cc.Component {

    @property(cc.Prefab)
    pitem_fab : cc.Prefab = null;

    @property(cc.Node)
    content_n : cc.Node = null;

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {
        let list = CONTACTS.contact_list;
        for(let i = 0 ; i < list.length ; i++){
            let npc = list[i];
            let ninfo = API.getAPINode('npc' , 'id' , npc.id);
            let item = cc.instantiate(this.pitem_fab);
            item.getComponent(PeopleItem).initView(ninfo , npc.new_msg);
            this.content_n.addChild(item);
        }
        INFO.removeRedPot(14);
    }

    initView(){

    }

    freshView(){

    }

    back(){
        cc.director.loadScene('MainScene');
    }
}
