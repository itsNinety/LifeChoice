import Alert from "../Comps/Alert";
import { CONFIG } from "../Data/Config";
import AppIcon from "../Prefab/AppIcon";
import PopIcons from "../Comps/PopIcons";
import AttrBlock from "../Prefab/AttrBlock";
import { LANG } from "../Utils/Lang";
import { INFO } from "../Data/Info";
import { API } from "../Utils/APITool";
import { UTILS } from "../Utils/Utils";
import { SYSTEM } from "../Data/System";
import RollNumberLabel from "../Comps/RollNumberLabel";
import PopInfo from "../Comps/PopInfo";
import { EFF } from "../Comps/Effect";

/*******************************************
 *  游戏主界面
 *  @since 2018.08.23
 *  @author zen
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class MainScene extends cc.Component {

    @property(cc.Prefab)
    icon_fab : cc.Prefab = null;

    @property(cc.Prefab)
    block_fab : cc.Prefab = null;

    @property(cc.Node)
    icon_content : cc.Node = null;

    @property(cc.Node)
    icon_area : cc.Node = null;

    @property(cc.Node)
    block_content : cc.Node = null;

    @property(PopIcons)
    pop : PopIcons = null;

    @property(cc.Node)
    time_slider_area : cc.Node = null;

    @property(cc.Slider)
    time_slider :cc.Slider = null;

    @property(cc.Label)
    salary_l : cc.Label = null;

    @property(cc.Label)
    lefttime_l : cc.Label = null;

    @property(cc.Label)
    name_l : cc.Label = null;

    @property(cc.Label)
    age_l : cc.Label = null;

    @property(cc.Label)
    job_l : cc.Label = null;

    @property(cc.Label)
    lover_l  : cc.Label = null;

    @property(cc.Label)
    car_l : cc.Label = null;

    @property(cc.Label)
    house_l : cc.Label = null;

    @property(cc.Label)
    money_l : cc.Label = null;
    //钱包变化效果
    @property(cc.Sprite)
    twinkle_n : cc.Sprite = null;  
    @property([cc.SpriteFrame])
    twinkle_sf = [];

    @property(cc.Label)
    month_l : cc.Label = null;

    @property(cc.Sprite)
    status_s : cc.Sprite = null;

    @property([cc.SpriteFrame])
    status_sf = [];

    @property(PopInfo)
    popinfo : PopInfo = null;

    @property(cc.Node)
    delay: cc.Node = null;

    @property(cc.Label)
    countdown_l: cc.Label = null;
    
    //滑动时间相关
    _slider_flag = 1;
    _slider_run  = false;
    _daily_deal  = false;
    _s ;//时间条确定后本月工资

    start () {
        let daily = API.getAPINode('daily_event' , 'id' , INFO.realFirstEventId);
        if(INFO.needShowFirst == true){
            SYSTEM.dialyNormal(INFO.realFirstEventId, daily, function(){
                INFO.needShowFirst = false; //已经显示过了
            });
        }
        this.initOnce();
        this.initView();
        this.freshView();
        this.pop.main = this;
        SYSTEM.mainscene = this;
        if((INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length) && INFO.currentFirstEventId == -1){
        }else{
            if(UTILS.countdownFlag == false){
                UTILS.countDown();
            }
        }
    }

    update(){
        this.delayBacklogUpdate();
    }

    //只初始化一次
    initOnce(){
        let a = Math.floor((INFO.freetime-150)/26);
        //console.log('a/10 = ', a/10);// 0.3
        this.time_slider.progress = a/10;
        let s = API.getAPINode('job', 'id', INFO.job);//工资
        this._s = Math.floor(s.salary*(450-INFO.freetime)/220);//根据工作类型和工作时间更新工资  
    }

    //初始化界面
    initView(){
        this.initBlock();
        this.initIcon();
        this.initLabels();
        this.freshIcons();
    }

    //刷新界面
    freshView(){
        this.initLabels();
        this.freshBlock();
        this.freshMoney();
        this.freshIcons();
    }

    //刷新金钱
    freshMoney(){
        let a = parseInt(this.money_l.string) - INFO.money;
        if(a != 0){
            this.money_l.getComponent(RollNumberLabel).number = INFO.money;
            let n = a > 0 ? 1 : 0;
            this.twinkle_n.spriteFrame = this.twinkle_sf[n];
            if(this.twinkle_n != null)
                this.twinkle_n.node.runAction(EFF.flick.clone());        
            this.money_l.node.runAction(EFF.shake.clone()); 
        }
        //this.money_l.string = INFO.money;
    }

    //显示状态面板
    showStatusInfo(){
        this.popinfo.show();
    }

    //展示时间调节条
    showTimeSlider(evt){
        if(this._slider_run) return;
        this._slider_run = true;
        this.node.getChildByName("topbar").
            getChildByName("status").
            getChildByName("downbtn").
            runAction(EFF.rotate.clone());//旋转
        //图标区域整体移动
        let that = this;
        let tick = 1;
        this.schedule(function(){ 
            that.icon_area.getComponent(cc.Widget).top += 10 * that._slider_flag;
            if(++tick == 20){
                that._slider_flag *= -1;
                that._slider_run = false;
                let flag = that._slider_flag == 1 ? false : true;
                that.time_slider_area.active = flag;
            }
        }, 0.01 , 20);

        //时间条出现/消失
        if(that._slider_flag == 1){
            this.time_slider_area.active = true;
            this.time_slider_area.runAction(cc.fadeIn(0.2));
        }else{
            this.time_slider_area.runAction(cc.fadeOut(0.2));
            this.time_reset();
        }

    }

    //初始化基础文字信息
    initLabels(){
        this.name_l.string = INFO.name;
        this.age_l.string = LANG.format(LANG.L2001 , INFO.age);
        this.job_l.string = UTILS.getJobName();
        this.car_l.string = UTILS.getCarName();
        this.lover_l.string = UTILS.getLoverName();
        this.house_l.string = UTILS.getHouseName();
        this.lefttime_l.getComponent(RollNumberLabel).number = INFO.lefttime;
        this.month_l.string = LANG.format(LANG.L2002 , INFO.month);
        this.money_l.getComponent(RollNumberLabel).number = INFO.money;
        let s = API.getAPINode('job', 'id', INFO.job);//工资
        INFO.salary = Math.floor(s.salary*(450-INFO.freetime)/220);//根据工作类型和工作时间更新工资
        this.salary_l.getComponent(RollNumberLabel).number = INFO.salary+'';
    }

    //初始化上部属性块
    initBlock(){
        let atts = CONFIG.attr;
        this.block_content.removeAllChildren(true);
        for(let i = 0 ; i < 6 ; i++){
            let block = cc.instantiate(this.block_fab);
            block.getComponent(AttrBlock).initView(atts[i]);
            block.name = atts[i].eng;
            this.block_content.addChild(block);
        }
    }

    //刷新属性块
    freshBlock(){
        let atts = CONFIG.attr;
        for(let i = 0 ; i < 6 ; i++){
            let att = atts[i];
            let block = this.block_content.getChildByName(att.eng);
            block.getComponent(AttrBlock).fresh(INFO[att.eng]);
        }
    }

    //初始化图标按钮
    initIcon(){
        let icons = CONFIG.icons;
        this.icon_content.removeAllChildren(true);
        for(let i= 0 ; i < 15; i++){
            let ico = cc.instantiate(this.icon_fab);
            ico.getComponent(AppIcon).initView(icons[i]);
            ico.on('appclick' , this.onIconClick.bind(this));
            ico.name = 'icon'+icons[i].id;
            this.icon_content.addChild(ico,1);
        }
    }

    //刷新图标
    freshIcons(){
        let icons = CONFIG.icons;
        for(let i= 0 ; i < 15; i++){
            let _id = icons[i].id
            let icon = this.icon_content.getChildByName('icon'+_id);
            if(INFO.isRedPots(_id)){
                icon.getComponent(AppIcon).red();
            }else{
                icon.getComponent(AppIcon).unred();
            }
        }
    }

    //图标点击
    onIconClick(evt , res){
        let rarr = res.split('_');
        switch(rarr[0]){
            case 'event':
                //触发事件（1-12日常事件）
                if(!this._daily_deal && INFO._slider_flag == 1){
                    INFO.salary = this._s;
                    INFO.lefttime = INFO.freetime;
                    INFO._slider_flag = 0;
                }
                SYSTEM.dailyEvent(rarr[1] , this.dailyClick.bind(this));
                this._daily_deal  = true;
                break;
            case 'pop':
                //弹框
                this.pop.popUp();
                break;
            case 'jump':
                //跳转界面
                cc.director.loadScene(rarr[1])
                break;
        }
    }

    dailyClick(){
        this.freshView();
    }

    //时间条变化
    onTimeSlider(evt : cc.Event , res){
        if(this._daily_deal || INFO._slider_flag == 0){
            this.time_slider.progress = INFO.tsp;
            Alert.getInstance().show(LANG.L2015);
            return;
        }
        INFO.tsp = this.time_slider.progress;
        INFO.freetime = 150 + Math.floor(26*INFO.tsp)*10;//本月空闲时间
        this.lefttime_l.string = INFO.freetime + '';
        let s = API.getAPINode('job', 'id', INFO.job);//工资
        this._s = Math.floor(s.salary*(450-INFO.freetime)/220);//本月实际工资
        this.salary_l.string = this._s + '';
    }

    //时间重置&实际工资
    time_reset(){
        //INFO.freetime = parseInt(this.lefttime_l.string)
    }
    
    //拖延症时主界面上待办事项的刷新
    delayBacklogUpdate(){
        if(INFO.currentFirstEventId != -1){
            this.delay.active = true;
            this.delay.parent = this.icon_content.getChildByName('icon'+CONFIG.backlog[INFO.currentFirstEventId-1].fakeid.toString());
            this.delay.setPosition(0,0);
            if(INFO.backlogRestTime % 60 == 0){
                this.countdown_l.string = (INFO.backlogRestTime-INFO.backlogRestTime % 60)/60+':00';
            }else if(INFO.backlogRestTime % 60 < 10){
                this.countdown_l.string = (INFO.backlogRestTime-INFO.backlogRestTime % 60)/60+':0'+INFO.backlogRestTime % 60;
            }else{
                this.countdown_l.string = (INFO.backlogRestTime-INFO.backlogRestTime % 60)/60+':'+INFO.backlogRestTime % 60;
            }
            if(INFO.backlogRestTime <= 0){
                let that = this;
                let daily = API.getAPINode('daily_event' , 'id' , INFO.realFirstEventId);
                SYSTEM.dialyNormal(INFO.currentFirstEventId, daily, function(){
                    INFO.needShowFirst = false;
                    that.freshView();  
                });
                INFO.currentFirstEventId = -1;
                // INFO.backlogRestTime = -API.getAPI('daily_event')[INFO.currentBacklogIndex].time_cost/10 *60;
                if(INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length){
                    INFO.backlogRestTime = 1;
                }else{
                    INFO.backlogRestTime = -API.getAPI('daily_event')[INFO.currentBacklogIndex].time_cost/10 *60;
                    if(UTILS.countdownFlag == false){
                        UTILS.countDown();
                    }
                }
            }
        }else{
            if(INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length){
                //接下来没有要执行的待办事项
                this.delay.active = false;
            }else{
                this.delay.active = true;
                this.delay.parent = this.icon_content.getChildByName('icon'+INFO.arr_backlog[INFO.currentBacklogIndex].fakeid.toString());
                this.delay.setPosition(0,0);
                if(INFO.backlogRestTime % 60 == 0){
                    this.countdown_l.string = (INFO.backlogRestTime-INFO.backlogRestTime % 60)/60+':00';
                }else if(INFO.backlogRestTime % 60 < 10){
                    this.countdown_l.string = (INFO.backlogRestTime-INFO.backlogRestTime % 60)/60+':0'+INFO.backlogRestTime % 60;
                }else{
                    this.countdown_l.string = (INFO.backlogRestTime-INFO.backlogRestTime % 60)/60+':'+INFO.backlogRestTime % 60;
                }
            }
            if(INFO.backlogRestTime <= 0){
                let daily = API.getAPI('daily_event');
                let a = daily[INFO.arr_backlog[INFO.currentBacklogIndex].id-1];
                INFO.lefttime += a.time_cost;
                INFO.ability += a.ability;
                INFO.exp += a.exp;
                INFO.social += a.social;
                INFO.happy += a.happy;
                INFO.health += a.health;
                INFO.morality += a.morality;
                INFO.money += a.money;
                this.freshView();
                INFO.currentBacklogIndex++;
                if(INFO.currentBacklogIndex < INFO.arr_backlog.length){
                    // INFO.backlogRestTime = -daily[INFO.arr_backlog[INFO.currentBacklogIndex].id-1].time_cost/10*60;
                    INFO.backlogRestTime = -daily[INFO.arr_backlog[INFO.currentBacklogIndex].id-1].time_cost/10*60;
                    if(UTILS.countdownFlag == false){
                        UTILS.countDown();
                    }
                }else{
                    //在主界面执行完
                    console.log("主界面执行完")
                    INFO.currentBacklogIndex = INFO.arr_backlog.length;
                    //this.delay.active = false;
                    INFO.backlogRestTime = 1;
                }
            }
        }
    }

    //进入下个月
    nextMonth(){
        //这里判断待办事项是否全部完成
        if((INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length)&& INFO.currentFirstEventId == -1){
            //无待办事项或者已经全部执行完,成功跳转下个月
            SYSTEM.nextMonth();
            //当前界面调整
            this._daily_deal = false;
            this.freshView();
        }else{
            //待办事项未完成，请等待待办事项结束
            Alert.getInstance().show(LANG.L2023);
        } 
    }
}
