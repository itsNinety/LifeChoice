
import CarList from "../Prefab/CarList";
import { INFO } from "../Data/Info";
import { API } from "../Utils/APITool";
import Alert from "../Comps/Alert";
import { LANG } from "../Utils/Lang";


/*******************************************
 *  车行界面
 *  @since 2018.08.25
 *  @author qll
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class CarDealerScene extends cc.Component {

    @property(cc.Prefab)
    car_fab: cc.Prefab =null;

    @property(cc.Node)
    carlistLayout: cc.Node =null;
    @property(cc.Node)
    carlistLayout2: cc.Node = null;

    @property(cc.Label)
    restmoney_l: cc.Label = null;
    @property(cc.Label)
    refresh_l: cc.Label = null;

    totalPageNumber = 1; //总共的页面数
    currentPage = 1; //当面是哪一页
    flag = 0;


    start () {
        console.log(API.getAPI('car'));
        let cars = API.getAPI('car')
        if(INFO.monthCarRandom[0] == -1){
            //说明是进游戏的第一个月
            //随机出三个不一样的值,0-cars.length-1
            let randomOne = Math.round(Math.random()*(cars.length-1));
            let randomTwo = Math.round(Math.random()*(cars.length-1));
            while(randomTwo == randomOne){
                randomTwo = Math.round(Math.random()*(cars.length-1));
            }
            let randomThree = Math.round(Math.random()*(cars.length-1));
            while(randomThree == randomOne || randomThree == randomTwo){
                randomThree = Math.round(Math.random()*(cars.length-1));
            }
            INFO.monthCarRandom[0] = randomOne;
            INFO.monthCarRandom[1] = randomTwo;
            INFO.monthCarRandom[2] = randomThree;
            this.initCarList(this.currentPage);
        }else{
            //说明已经点击过“下个月”
            this.initCarList(this.currentPage);
        } 
        this.refresh_l.string = LANG.format(LANG.L7003,this.currentPage)
    }

    update(){
        this.restmoney_l.string = LANG.L7004+' '+Math.floor(INFO.money);
    }

    initCarList(page){
        let cars = API.getAPI('car')
        if(INFO.car == -1){
            //说明没有车
            this.carlistLayout.removeAllChildren();
            this.carlistLayout2.removeAllChildren();
             for(let i= 0 ; i < 3; i++){
                 let car_f = cc.instantiate(this.car_fab);
                 car_f.getComponent(CarList).initView(cars[INFO.monthCarRandom[i+(page-1)*3]],INFO.car);
                 car_f.on('carclick' , this.onCarBtnClick.bind(this));
                 this.carlistLayout.addChild(car_f);
             }
        }else{
            //如果有车
            if(this.flag == 0){
                this.carlistLayout.removeAllChildren();
                let car_own = cc.instantiate(this.car_fab);
                car_own.getComponent(CarList).initView(cars[INFO.car -1],INFO.car);
                car_own.on('carclick' , this.onCarBtnClick.bind(this));
                this.carlistLayout.addChild(car_own);
                this.flag++;
            }

            this.carlistLayout2.removeAllChildren();
            let maxIndex = 2;
            for(let i = 0;i< maxIndex; i++){
                let car_f = cc.instantiate(this.car_fab);
                if(cars[INFO.monthCarRandom[i+(page-1)*2]].id != INFO.car){
                    car_f.getComponent(CarList).initView(cars[INFO.monthCarRandom[i+(page-1)*2]],-1);
                    car_f.on('carclick' , this.onCarBtnClick.bind(this));
                    this.carlistLayout2.addChild(car_f);
                }else{
                    maxIndex++;
                }
            }
        }
      
    }

    onCarBtnClick(evt,res){
        //预制节点的按钮点击后都会执行这个函数，在这里判断是购买还是出售
        if(INFO.purchaseCar == 0){
            Alert.getInstance().show(LANG.L7010);
        }else{
            let carArr = API.getAPI('car')
            let rarr = res.split('_');
            let that = this;
            if(rarr[0] == 'sale'){
                console.log("出售车");
                Alert.getInstance().show2(LANG.format(LANG.L7005,carArr[INFO.car -1].sell_price), function(){
                    console.log("成功出售");
                    INFO.purchaseCar -= 0.5;
                    INFO.money += carArr[INFO.car -1].sell_price;
                    INFO.car = -1;
                    that.refresh_l.string = LANG.format(LANG.L8001,that.currentPage)
                    that.initCarList(that.currentPage);
                })
            }else{
                console.log("购买车");
                if(INFO.car == -1){
                    //自己没车,可以购买
                    if(INFO.money >= parseInt(rarr[1])){
                        //足够多的钱可以买
                        let a = carArr[parseInt(rarr[2])-1];
                        Alert.getInstance().show(LANG.format(LANG.L7007, rarr[1]),
                        function(){
                            that.flag = 0;
                            INFO.purchaseCar -= 0.5;
                            INFO.money -= parseInt(rarr[1]);
                            INFO.car = parseInt(rarr[2]);
                            INFO.ability += a.ability;
                            INFO.exp += a.exp;
                            INFO.happy += a.happy;
                            that.refresh_l.string = LANG.format(LANG.L8001,that.currentPage)
                            that.initCarList(that.currentPage);
                        }, LANG.format(LANG.L7012, a.ability, a.exp, a.happy));
                    }else{
                        //钱不够
                        Alert.getInstance().show(LANG.L7008);
                    }
                }else{
                    console.log("请先出售车");
                    Alert.getInstance().show(LANG.L7009);
                }
            }
        }
    }

    onLeaveBtnClick(){
        cc.director.loadScene('MainScene');
    }

    onRefreshBtnClick(){
        if(INFO.friends_Invited < 3){
            //邀请三个及以上好友，每月即可增加一次免费刷新次数,立即邀请?
            Alert.getInstance().show2(LANG.L8010,function(){
                cc.director.loadScene('InviteScene')
            })
        }else if(INFO.carRefreshTime > 0 ){
            // this.totalPageNumber++;
            this.currentPage++;
            this.refresh_l.string = LANG.format(LANG.L8001,this.currentPage)
            this.createRandom();
            this.initCarList(this.currentPage);
            INFO.carRefreshTime -= 1; //可刷新次数-1
        }else{
            //不能刷新,本月可刷新次数已用完
            Alert.getInstance().show(LANG.L8009)
        }
    }

    createRandom(){
        //if(INFO.car == -1){
            //没有车
            let cars = API.getAPI('car')
            //随机出三个不一样的值,0-cars.length-1
            let randomOne = Math.round(Math.random()*(cars.length-1));
            while(cars[randomOne].id == INFO.car){
                randomOne = Math.round(Math.random()*(cars.length-1));
            }
            let randomTwo = Math.round(Math.random()*(cars.length-1));
            while(randomTwo == randomOne || cars[randomTwo].id == INFO.car){
                randomTwo = Math.round(Math.random()*(cars.length-1));
            }
            let randomThree = Math.round(Math.random()*(cars.length-1));
            while(randomThree == randomOne || randomThree == randomTwo || cars[randomThree].id == INFO.car){
                randomThree = Math.round(Math.random()*(cars.length-1));
            }
            INFO.monthCarRandom[0+(this.currentPage-1)*3] = randomOne;
            INFO.monthCarRandom[1+(this.currentPage-1)*3] = randomTwo;
            INFO.monthCarRandom[2+(this.currentPage-1)*3] = randomThree;
        // }else{
        //     let cars = API.getAPI('car')
        //     //随机出两个不一样的值,0-cars.length-1
        //     let randomOne = Math.round(Math.random()*(cars.length-1));
        //     while(cars[randomOne].id == INFO.car){
        //         randomOne = Math.round(Math.random()*(cars.length-1));
        //     }
        //     let randomTwo = Math.round(Math.random()*(cars.length-1));
        //     while(randomTwo == randomOne || cars[randomTwo].id == INFO.car){
        //         randomTwo = Math.round(Math.random()*(cars.length-1));
        //     }
        //     INFO.monthCarRandom[0+(this.currentPage-1)*2] = randomOne;
        //     INFO.monthCarRandom[1+(this.currentPage-1)*2] = randomTwo;
        // }
    }

}
