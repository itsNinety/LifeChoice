import { INFO } from "../Data/Info";
import Alert from "../Comps/Alert";
import { LANG } from "../Utils/Lang";
import PostGradTime from "../Prefab/PostGradTime";
import AttrSelector from "../Prefab/AttrSelector";
import { API } from "../Utils/APITool";
import { CONFIG } from "../Data/Config";
import PgGift from "../Prefab/PgGift";
import Comfire from "../Comps/Comfire";

/*******************************************
 *  开始界面场景，记录一系列选择，更新信息到Info
 *  @since 2018.08.23
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class GuideScene extends cc.Component {
    @property(cc.Prefab)
    init_attr: cc.Prefab = null;
    @property(cc.Prefab)
    postgraduateTime: cc.Prefab = null;
    @property(cc.Prefab)
    giftIcon_fab:cc.Prefab = null;

    @property(cc.Node)
    h: cc.Node = null;
    @property(cc.Node)
    h0: cc.Node = null;
    //选择性别
    @property(cc.Node)
    h1: cc.Node = null;
    //选择出路
    @property(cc.Node)
    h2: cc.Node = null;
    //找工作出路
    @property(cc.Node)
    h3: cc.Node = null;
    //考研
    @property(cc.Node)
    h4_1: cc.Node = null;
    @property(cc.Node)
    h4_2: cc.Node = null;
    @property(cc.Node)
    h4_3: cc.Node = null;
    //考上，时间安排
    @property(cc.Node)
    h5: cc.Node = null;

    @property(cc.Node)
    layout_h3: cc.Node = null;
    
    //h4界面:考试界面
    @property(cc.Node)
    p_toggle3_h4: cc.Node = null;
    @property(cc.Node)
    m_toggle4_h4: cc.Node = null;
    @property(cc.Node)
    e_toggle2_h4: cc.Label = null;
    @property(cc.Node)
    p_toggle: cc.Node = null;
    @property(cc.Node)
    m_toggle: cc.Node = null;
    @property(cc.Node)
    e_toggle: cc.Node = null;

    //h5界面，研究生精力分配界面
    @property(cc.Node)
    layout_h5: cc.Node = null;
    @property(cc.Label)
    totalTime_h5: cc.Label = null;
    postGraduate_totaltime_h5:number = 100;
    @property(cc.Node)
    chooseGift_pop_h5: cc.Node = null;
    @property(cc.Node)
    giftLayout_h5: cc.Node = null;
    @property(cc.Node)
    title_h5: cc.Node = null;

    @property(cc.Label)
    paragraph1_h : cc.Label = null;
    @property(cc.Label)
    paragraph2_h : cc.Label = null;
    @property(cc.Label)
    paragraph3_h : cc.Label = null;
    @property(cc.Label)
    paragraph1_h0 : cc.Label = null;
    @property(cc.Label)
    paragraph2_h0 : cc.Label = null;
    @property(cc.Label)
    paragraph3_h0 : cc.Label = null;
    @property(cc.Label)
    paragraph1_h1 : cc.Label = null;
    @property(cc.Label)
    paragraph2_h1 : cc.Label = null;
    @property(cc.Label)
    paragraph_h2: cc.Label =  null;

    @property(cc.Node)
    click_h :cc.Node = null;
    @property(cc.Node)
    click_h0: cc.Node = null;
    @property(cc.Node)
    boy_btn: cc.Node = null;
    @property(cc.Node)
    girl_btn: cc.Node = null;

    start () {
        this.h.active    = true;
        this.h0.active   = false;
        this.h1.active   = false;
        this.h2.active   = false;
        this.h3.active   = false;
        this.h4_1.active = false;
        this.h4_2.active = false;
        this.h4_3.active = false;
        this.h5.active   = false;
        let that = this;
        this.typingAni(this.paragraph1_h,LANG.L1012,this.click_h,function(){
            that.click_h.active = true;
            that.hClickTime ++;
        })
    }

    hClickTime = 0;;
    onClick_h(){
        let that = this;
        switch(this.hClickTime){
            case 1:{
                this.typingAni(this.paragraph2_h,LANG.L1013,this.click_h,function(){
                    that.click_h.active = true;
                    that.hClickTime ++;
                })
                break;
            }
            case 2:{
                this.typingAni(this.paragraph3_h,LANG.L1014,this.click_h,function(){
                    that.click_h.active = true;
                    that.hClickTime ++;
                })
                break;
            }
            case 3:{
                this.h.active = false;
                this.h0.active = true;
                this.hClickTime = 0;
                this.typingAni(this.paragraph1_h0,LANG.L1015,this.click_h0,function(){
                    that.click_h0.active = true;
                    that.h0ClickTime ++;
                })
            }
        }

    }

    h0ClickTime = 0;
    onClick_h0(){
        let that = this;
        switch(this.h0ClickTime){
            case 1:{
                this.typingAni(this.paragraph2_h0,LANG.L1016,this.click_h0,function(){
                    that.click_h0.active = true;
                    that.h0ClickTime ++;
                })
                break;
            }
            case 2:{
                this.typingAni(this.paragraph3_h0,LANG.L1017,this.click_h0,function(){
                    that.click_h0.active = true;
                    that.h0ClickTime ++;
                })
                break;
            }
            case 3:{
                this.h0.active = false;
                this.h1.active = true;
                this.boy_btn.active = false;
                this.girl_btn.active = false;
                this.h0ClickTime = 0;
                this.typingAni(this.paragraph1_h1,LANG.L1018,this.click_h0,function(){
                    that.click_h0.active = true;
                    that.typingAni(that.paragraph2_h1,LANG.L1019,that.click_h0,function(){
                        that.boy_btn.active = true;
                        that.girl_btn.active = true;
                    })
                })
            }
        }
    }

    onBoy_h1(){
        console.log('Hello boy!');
        this.h1.active = false;
        this.h2.active = true;
        let that = this;
        this.typingAni(this.paragraph_h2,LANG.L1020,this.click_h0,function(){
            that.click_h0.active = true;
        })
        INFO.sex = 1;
        CONFIG.getSexData(function(){
            INFO.initNewData();
        })
    }
    onGirl_h1(){
        console.log('Hey girl!');
        this.h1.active = false;
        this.h2.active = true;
        let that = this;
        this.typingAni(this.paragraph_h2,LANG.L1020,this.click_h0,function(){
            that.click_h0.active = true;
        })
        INFO.sex = 0;
        CONFIG.getSexData(function(){
            INFO.initNewData();
        })
    }

    onJob_h2(){
        console.log('找工作...');
        let that = this;
        Comfire.getInstance().show2('找工作', LANG.L1000, LANG.format(CONFIG.channelurl, 'findajob'), function(){
            that.h2.active = false;
            that.h3.active = true;
            for(let i = 0; i < 4; i++){
                let attr = cc.instantiate(that.init_attr);
                attr.getComponent(AttrSelector).initView(i);
                that.layout_h3.addChild(attr);
            }
            Comfire.getInstance().close();
        }, '');
    }
    onOwn_h2(){
        console.log('自己创业...');
        Comfire.getInstance().show2('自己创业', LANG.L1001, LANG.format(CONFIG.channelurl, 'business'), function(){
            Alert.getInstance().show(LANG.L1002, function(){
                Comfire.getInstance().close();
            });
        }, '');
    }
    onPost_h2(){
        console.log('考研...');
        let that = this;
        Comfire.getInstance().show2('考研', LANG.L1003, LANG.format(CONFIG.channelurl, 'study'), function(){
            that.h2.active = false;
            that.h4_1.active = true;
            Comfire.getInstance().close();
        }, '');
    }
    onCivil_h2(){
        console.log('考公务员...');
        Comfire.getInstance().show2('考公务员', LANG.L1004, LANG.format(CONFIG.channelurl, 'gov'), function(){
            Alert.getInstance().show(LANG.L1005, function(){
                Comfire.getInstance().close();
            });
        }, '');
    }
    onAbroad_h2(){
        console.log('出国...');
        Comfire.getInstance().show2('出国', LANG.L1006, LANG.format(CONFIG.channelurl, 'goaboard'), function(){
            Alert.getInstance().show(LANG.L1007, function(){
                Comfire.getInstance().close();
            });
        }, '');
    }
    //选择完毕，开始更新到Info, INFO.arr_selected记录了选择的结果
    onSure_h3(){   
        for(let i = 0; i < 4; i++){
            switch(INFO.arr_selected[i]){
                case 0: this.updateChange(API.getAPI('basic_num')[4*i]);
                break;
                case 1: this.updateChange(API.getAPI('basic_num')[4*i + 1]);
                break;
                case 2: this.updateChange(API.getAPI('basic_num')[4*i + 2]);
                break;
                case 3: this.updateChange(API.getAPI('basic_num')[4*i + 3]);
                break;
                default:
                break;
            }
        }
        //INFO.showInfo();
        cc.director.loadScene('MainScene');
    }

    onCommit_h4(){
        //交卷
        let that = this;
        if(this.p_toggle3_h4.getComponent(cc.Toggle).isChecked == true &&
        this.m_toggle4_h4.getComponent(cc.Toggle).isChecked == true &&
        this.e_toggle2_h4.getComponent(cc.Toggle).isChecked == true){
            //考研成功，进入研究生阶段的界面h5
            Alert.getInstance().show(LANG.L1008, 
            function(){
                INFO.isPostgraduate = true; //成为一名研究生
                that.h4_3.active = false;
                that.h5.active = true;
                that.chooseGift_pop_h5.active = false;
                that.totalTime_h5.string = that.postGraduate_totaltime_h5.toString();
                for(let i = 0; i < 6; i++){
                    let field = cc.instantiate(that.postgraduateTime);
                    field.getComponent(PostGradTime).initView(i , that.timeClick.bind(that));
                    that.layout_h5.addChild(field,1,i.toString());
                } 
            }); 
        }else{
            //考研失败,跳出弹窗：你的研究生入学考试没有通过
            Alert.getInstance().show(LANG.L1009, 
            function(){
                that.h2.active = true;
                that.h4_3.active = false;
                //删除记录，以免下次考研时会记录上次答案
                for(let i = 0; i< 4; i++){
                    that.p_toggle.getComponent(cc.ToggleContainer).toggleItems[i].isChecked = false;
                    that.m_toggle.getComponent(cc.ToggleContainer).toggleItems[i].isChecked = false;
                    that.e_toggle.getComponent(cc.ToggleContainer).toggleItems[i].isChecked = false;
                }
            }); 
        }
    }

    //考研时点击下一题
    onNextQuestion(){
        if(this.h4_1.active == true){
            this.h4_1.active = false;
            this.h4_2.active = true;
        }else{
            this.h4_2.active = false;
            this.h4_3.active = true;
        }
    }

    //考研时点击上一题
    onLastQuestion(){
        if(this.h4_3.active == true){
            this.h4_2.active = true;
            this.h4_3.active = false;
        }else{
            this.h4_1.active = true;
            this.h4_2.active = false;
        }
    }

    timeClick(delta){
        console.log(delta , this.postGraduate_totaltime_h5 )
        if(this.postGraduate_totaltime_h5 == 0 && delta < 0){
            Alert.getInstance().show(LANG.L5001);
        }
        if(this.postGraduate_totaltime_h5 + delta >= 0 && this.postGraduate_totaltime_h5 + delta <= 100){
            this.postGraduate_totaltime_h5 += delta;
            this.totalTime_h5.string = this.postGraduate_totaltime_h5.toString();
            return true;
        }else{
            return false;
        }
    }

    //将选择获得的属性增益更新到Info类
    updateChange(json){
        INFO.ability  += parseInt(json.ability);
        INFO.exp      += parseInt(json.exp);
        INFO.social   += parseInt(json.social);
        INFO.charm    += parseInt(json.charm);
        INFO.happy    += parseInt(json.happy);
        INFO.health   += parseInt(json.health);
        INFO.morality += parseInt(json.morality);
        INFO.money    += parseInt(json.money);
        INFO.career   += parseInt(json.career);
        INFO.discount *= (1-parseInt(json.discount));
    }

    totalMoney=0;totalAbility=0;totalExp=0;totalSocial=0;totalHappy=0;totalHealth=0;totalMorality=0;
    str = '';
    showPostChange(json){
        for(let i =0; i<json.length; i++){        
            this.totalMoney    = this.totalMoney + INFO.arr_postFieldEnergy[i]*parseInt(json[i].money);
            this.totalAbility  = this.totalAbility + INFO.arr_postFieldEnergy[i]*parseInt(json[i].ability);
            this.totalExp      = this.totalExp + INFO.arr_postFieldEnergy[i]*parseInt(json[i].exp);
            this.totalSocial   = this.totalSocial + INFO.arr_postFieldEnergy[i]*parseInt(json[i].social);
            this.totalHappy    = this.totalHappy + INFO.arr_postFieldEnergy[i]*parseInt(json[i].happy);
            this.totalHealth   = this.totalHealth + INFO.arr_postFieldEnergy[i]*parseInt(json[i].health);
            this.totalMorality = this.totalMorality + INFO.arr_postFieldEnergy[i]*parseInt(json[i].morality);
        }
        if(this.totalMoney < 0){
            this.str += '金钱'+this.totalMoney+', ';
        }else{
            this.str += '金钱+'+this.totalMoney+', ';
        }
        this.str += '能力+'+this.totalAbility+', ';
        this.str += '经验+'+this.totalExp+', ';
        this.str += '交际+'+this.totalSocial+', ';
        this.str += '快乐+'+this.totalHappy+', ';
        this.str += '健康+'+this.totalHealth+', ';
        this.str += '道德+'+this.totalMorality;
    }

    //研究生阶段后的属性增益更新到Info类
    updatePostChange(){
        this.showPostChange(API.getAPI('graduate'));
        INFO.money    += this.totalMoney;
        INFO.ability  += this.totalAbility;
        INFO.exp      += this.totalExp;
        INFO.social   += this.totalSocial;
        INFO.happy    += this.totalHappy;
        INFO.health   += this.totalHealth;
        INFO.morality += this.totalMorality;
        INFO.month    -= 36;                  //剩余时间减36个月
        INFO.age      += 3;
    }

    onExecute_h5(){
        //初始化Info中arr_postFieldEnergy的值
        console.log("execute")
        for(let i = 0; i< 6; i++){
            INFO.arr_postFieldEnergy[i] =
            this.layout_h5.getChildByName(i.toString()).getComponent(PostGradTime).initTime;
        }
        let that = this;
        if(INFO.arr_postFieldEnergy[0] < 10){
            //留级一年，时间再减少12个月
            INFO.month -= 12;
            INFO.age += 1;
            this.updatePostChange();
            //Alert.getInstance().show(LANG.L1010,function(){
                Alert.getInstance().show(LANG.L1010, function(){
                    that.title_h5.active = false;
                    that.chooseGift_pop_h5.active = true;
                    that.initGiftIcon();
                    //console.log(API.getAPI('pg_gift'))
                }, that.str, false)
            //})
        }else{
            this.updatePostChange();
            Alert.getInstance().show(LANG.L1011, function(){
                //跳出幸运礼包
                that.title_h5.active = false;
                that.chooseGift_pop_h5.active = true;
                that.initGiftIcon();
                //console.log(API.getAPI('pg_gift'))
            }, that.str, false)
        }
    }


    //初始化礼物界面的图标
    initGiftIcon(){
        let icons = CONFIG.postGift;
        for(let i= 0 ; i < 3; i++){
            let ico = cc.instantiate(this.giftIcon_fab);
            ico.getComponent(PgGift).initView(icons[i]);
            ico.once('giftclick' , this.onGiftIconClick.bind(this));
            this.giftLayout_h5.addChild(ico);
        }
    }

    //礼物图标点击
    onGiftIconClick(evt,res){
        let rarr = res.split('_');
        console.log(res)
        switch(rarr[0]){
            case 'career':
                //事业礼包结果
                console.log("事业礼包")
                let randomCarrer = Math.floor(Math.random()*4);//0,1,2,3
                let arrCarrer = API.getAPI('pg_gift')[randomCarrer].award.split('|');
                this.gift(arrCarrer);
                break;
            case 'life':
                //生活礼包结果
                console.log("生活礼包")
                let randomLife = Math.floor(Math.random()*4)+4;//4,5,6,7
                let arrLife = API.getAPI('pg_gift')[randomLife].award.split('|');
                this.gift(arrLife);
                break;
            case 'personality':
                //个性礼包结果
                console.log("个性礼包")
                let randomPerson = Math.floor(Math.random()*4)+8;//8,9,10,11
                let arrPersonality = API.getAPI('pg_gift')[randomPerson].award.split('|');
                this.gift(arrPersonality);
                break;
        }
    }

    //此函数只在礼包onGiftIconClick里面使用过
    gift(arr){
        let str = ''
        for(let i = 0; i<arr.length; i++){
            let test = arr[i].split('#');
            switch(test[0]){
                case 'exp':{
                    str +=LANG.format(LANG.L5003,test[1])
                    INFO.exp += parseInt(test[1]);
                    break;
                }
                case 'ability':{
                    str +=LANG.format(LANG.L5004,test[1])
                    INFO.ability += parseInt(test[1]);
                    break;
                }
                case 'money':{
                    str +=LANG.format(LANG.L5005,test[1])
                    INFO.money += parseInt(test[1]);
                    break;
                }
                case 'job':{
                    str +=LANG.format(LANG.L5006,API.getAPI('job')[parseInt(test[1])-1].company,API.getAPI('job')[parseInt(test[1])-1].job);
                    INFO.job = parseInt(test[1]);
                    break;
                }
                case 'social':{
                    str +=LANG.format(LANG.L5007,test[1])
                    INFO.social += parseInt(test[1]);
                    break;
                }
                case 'career':{
                    str +=LANG.format(LANG.L5008,test[1])
                    INFO.career += parseInt(test[1]);
                    break;
                }
                case 'car':{
                    str +=LANG.format(LANG.L5009,API.getAPI('car')[parseInt(test[1])-1].car);
                    INFO.car = parseInt(test[1]);
                    break;
                }
                case 'house':{
                    str +=LANG.format(LANG.L5010,API.getAPI('house')[parseInt(test[1])-1].house);
                    INFO.house = parseInt(test[1]);
                    break;
                }
                case 'morality':{
                    str +=LANG.format(LANG.L5011,test[1])
                    INFO.morality += parseInt(test[1]);
                    break;
                }
                case 'health':{
                    str +=LANG.format(LANG.L5012,test[1])
                    INFO.health += parseInt(test[1]);
                    break;
                }
                case 'happy':{
                    str +=LANG.format(LANG.L5013,test[1])
                    INFO.happy += parseInt(test[1]);
                    break;
                }
                case 'love':{
                    str +=LANG.format(LANG.L5014,test[1])
                    INFO.love += parseInt(test[1]);
                    break;
                }
                case 'month':{
                    str +=LANG.format(LANG.L5015,test[1])
                    INFO.month += parseInt(test[1]);
                    break;
                }
                case 'stock':{
                    str += LANG.format(LANG.L5016,test[1])
                    INFO.hold += parseInt(test[1]); 
                    break;
                }
            }
        }
        console.log("礼包:",str);
        Alert.getInstance().show(null, function(){
            cc.director.loadScene("MainScene");
        }, str, false)
    }

    func;

    /********
     * 打字机效果函数
     * cb1为该行显示完毕后的回调
     * cb2为该页点击次数结束后的回调
     * clickNode是点击的那个button（全屏幕）
     *******/
    typingAni(label,text,clickNode,cb1){
        var self = this;
        var anilabel = '';
        var arr = text.split('');
        var len = arr.length;
        var step = 0;
        self.func =function(){
            anilabel += arr[step];
            label.string = anilabel;
            clickNode.active = false;
            if(++step == len){
                self.unschedule(self.func);
                cb1 && cb1();
            }
        }
        self.schedule(self.func,0.1,cc.macro.REPEAT_FOREVER,0)
    }


}
