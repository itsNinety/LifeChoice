import { INFO } from "../Data/Info";
import { API } from "./APITool";
import { LANG } from "./Lang";

/*******************************************
 *  常用工具函数类
 *  @since 2018.08.21
 *  @author zen
 * 
 *******************************************/

export class Utils extends cc.Component{
    private static instance : Utils;

    public static getInstance():Utils{
        if(!Utils.instance) {
            Utils.instance = new Utils();
        }
        return Utils.instance;
    }
    public isToday(str) {
        str = Number(str);
        if (new Date(str).toDateString() === new Date().toDateString()) {
            //今天
            return true;
        } else if (new Date(str) < new Date()){
            //之前
            return false;
        }
    }

    //获取工作名称
    public getJobName(){
        if(INFO.job == -1){
            return LANG.L0001;
        }else{
            let job = API.getAPINode('job', 'id' , INFO.job);
            return job.company +job.job;
        }
    }
    //获取车子名称
    public getCarName(){
        if(INFO.car == -1){
            return LANG.L0004;
        }else{
            let car = API.getAPINode('car', 'id' , INFO.car);
            return car.car;
        }
    }
    //获取房子名称
    public getHouseName(){
        if(INFO.house == -1){
            return LANG.L0003;
        }else{
            let house = API.getAPINode('house', 'id' , INFO.house);
            return house.house;
        }
    }
    //获取男\女朋友名称
    public getLoverName(){
        if(INFO.lover == -1){
            return LANG.L0002;
        }else{
            let lover = API.getAPINode('npc', 'id' , INFO.lover);
            return lover.name;
        }
    }

    //组织日常消耗语言
    public getDailyWords(id){
        let event = API.getAPINode('daily_event' , 'id' , id);
        switch(id){
            case 1:
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20032 , event.ability , event.exp , event.happy)]
                break;
            case 2:
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20042 , event.ability , event.exp , event.happy)];
                break;
            case 3 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20052 , event.exp , event.social , event.happy , event.health , event.morality)];
                break;
            case 4 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20062 , event.exp , event.social , event.happy ,event.health)];
                break;
            case 5 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20072 , event.exp , event.happy)];
                break;
            case 6 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20082 , event.ability , event.exp , event.social , event.happy , event.health)];
                break;
            case 7 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20092 , event.ability , event.exp , event.happy , event.health)];
                break;
            case 8 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20102 , event.happy , event.health)];
                break;
            case 9 : 
                return [event.desc , LANG.format(LANG.L2004 , -event.time_cost , event.money) , LANG.formatWithSymbol(LANG.L20112 , event.ability ,event.exp, event.happy , event.health)];
                break;
            case 10 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20122 , event.exp , event.social , event.happy , event.health)];
                break;
            case 11 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20132 , event.ability , event.happy , event.health)];
                break;
            case 12 : 
                return [event.desc , LANG.format(LANG.L2003 , -event.time_cost , -event.money) , LANG.formatWithSymbol(LANG.L20142 , event.happy , event.health , event.morality)];
                break;
            default:
                break;
        }
    }

    //判断是否符合策划条件
    checkMatch(condition){
        condition = this.trim(condition);
        let arr = condition.split('|');
        for(let i = 0 ; i < arr.length ; i++){
            let item = arr[i];
            if(item == 'R'){
                continue;
            }else{
                let tmp = item.split('#');
                if(tmp[0] == 'sex'){
                    if((tmp[1] == 'male' && INFO[tmp[0]] == 0) || (tmp[1] == 'female' && INFO[tmp[0]] == 1)){
                        return false;
                    }
                }else{
                    if(INFO[tmp[0]] < parseInt(tmp[1])){
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    //
    trim(str){
        return str.replace(/^\s+|\s+$/gm,'');
    }
    
    //处理多个项
    getAtts(str){
        let arr = str.split("|");
        str = '';
        for(let i = 0; i < arr.length; i++){
            let tmp = arr[i].split("#");
            str += LANG.attrs[tmp[0]] +':'+ this.replaceCost(tmp[1]) + ' ';
        }
        return str;
    }

    //多项数值变化
    changAtts(str){
        if(str == undefined || typeof str == 'undefined') return;
        let arr = str.split("|");
        for(let i = 0; i < arr.length; i++){
            let tmp = arr[i].split("#");
            console.log(INFO[tmp[0]])
            INFO[tmp[0]] += parseInt(this.replaceCost(tmp[1]));
        }
    }

    replaceCost(str) {
        str = str.replace('salary' , INFO.salary);
        return str;
    }

    countdownFlag = false;
    countDown(){
        this.countdownFlag = true;
        let that = this;
        this.schedule(function ttFun(){
            INFO.backlogRestTime -= 1;
            if(INFO.backlogRestTime <= 0){
                that.unschedule(ttFun)
                that.countdownFlag = false;
            }
        },1,cc.macro.REPEAT_FOREVER)
    }

    randomNumCreate(length,arr){
        let randomOne = Math.round(Math.random()*(length-1));
        let randomTwo = Math.round(Math.random()*(length-1));
        while(randomTwo == randomOne){
            randomTwo = Math.round(Math.random()*(length-1));
        }
        let randomThree = Math.round(Math.random()*(length-1));
        while(randomThree == randomOne || randomThree == randomTwo){
            randomThree = Math.round(Math.random()*(length-1));
        }
        arr[0] = randomOne;
        arr[1] = randomTwo;
        arr[2] = randomThree;
    }

    //判断是否符合单个属性条件
    checkAttr(str){
        if(str == undefined || typeof str == 'undefined') return true;
        let arr = str.split("|");
        str = '';
        for(let i = 0; i < arr.length; i++){
            let tmp = arr[i].split("#");
            if(INFO[tmp[0]] < tmp[1]){
                return false;
            }
        }
        return true;
    }

    //结局剧情感情线的属性条件判断
    checkLoveAttr(str){
        let arr = str.split("|");
        for(let i = 0; i<arr.length; i++){
            let tmp = arr[i].split("#");
            if(tmp[0] == 'npc'){
                if(INFO.lover != parseInt(tmp[1])){
                    return false;
                }
            }else{
                if(INFO[tmp[0]] < tmp[1]){
                    return false;
                }
            }
        }
        return true;
    }

    //判断是否符合属性区间条件
    //above代表下限，below代表上限
    judgeInterval(above,below){
        if(below == "" && above == ""){
            return true;
        }else if(below == ""){
            //说明没有上限，达到下限就算满足
            if(this.checkAttr(above)){
                return true;
            }else{
                return false;
            }
        }else if(above == ""){
            //没有下限，不满足上限即可
            if(this.checkAttr(below) == false){
                return true;
            }else{
                return false;
            }
        }else{
            //有上限和下限，符合下限但是不符合上限才算在这个区间内
            if(this.checkAttr(above) == true && this.checkAttr(below) == false){
                return true;
            }else{
                return false;
            }
        }
    }

    //属性增益
    attrIncrease(num){
        let daily = API.getAPI('daily_event');
        //离开游戏期间完成的待办事项的属性增益
        let a = daily[INFO.arr_backlog[num].id-1];
        INFO.lefttime += parseInt(a.time_cost);
        INFO.ability  += parseInt(a.ability);
        INFO.exp      += parseInt(a.exp);
        INFO.social   += parseInt(a.social);
        INFO.happy    += parseInt(a.happy);
        INFO.health   += parseInt(a.health);
        INFO.morality += parseInt(a.morality);
        INFO.money    += parseInt(a.money);
    }

}
export const UTILS = Utils.getInstance();

