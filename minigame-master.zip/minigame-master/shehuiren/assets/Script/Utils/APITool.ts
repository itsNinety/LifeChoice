/*******************************************
 *  静态数据调用函数
 *  @since 2018.07.21
 *  @author zen
 * 
 *******************************************/

import { VOBase } from "./VOBase";

export default class APITool{
        private static instance : APITool;
        private static formatList : Array<Object>;

    	public constructor(){
            APITool.formatList = [];
    	}

        public static getInstance():APITool{
            if(!APITool.instance) {
                APITool.instance = new APITool();
            }
            return APITool.instance;
        }

        //添加配置文件
        public add_json(str : any) : void
        {
            var arr  = str.split("||");
            
            for(var i = 0, ln = arr.length; i < ln ; i++){
                var content = arr[i];
                if(content.length){
                    this.add_s_json(content);
                }
            }
        }

        private add_s_json(str : any) : void
        {
            var obj : any = JSON.parse(str);
            var cls : any = this.getClass(obj.name);

            if(cls){
                var list : Array<VOBase> = [];
                var idx : number = 0;
                var ln : number = obj.data.length;

                while (idx < ln){
                    list.push(VOBase.Analysis(new cls, obj.data[idx]));
                    idx++;
                }

                APITool.formatList[obj.name] = list;
            }else{
                APITool.formatList[obj.name] = obj.data;
            }
        }

        private _vo_class : any = {

        }
        
        private getClass(name : string) : any//50个静态表
        {
            return this._vo_class[name] || null;          
        }

        //获取API数据
        public getAPI(apiname:string):Array<Object>{
            return APITool.formatList[apiname];
        }

        /**
        * 获取节点数据 ！！！注意，api数据是本地存数数据，只可以读，不可以写入！！！！
        * @param apiname:静态表名，att：查询的属性名，val：查询的属性值
        **/
        public getAPINode(apiname:string, att:string, val:any, att2:string="", val2:any=""):any
        {
            var tmp:any = null;            
            var api:any = APITool.formatList[apiname];

            if (api){
                var idx:number = 0;
                var ln : number = api.length;

                while (idx < ln){          
                    tmp = api[idx];
                    idx++;  
                    if(tmp.hasOwnProperty(att) && tmp[att] == val){    
                        if(att2 != "" && (!tmp.hasOwnProperty(att2) || tmp[att2] != val2)){
                            continue;
                        }       
                        return tmp;
                    }
                }
            }else{
                console.log(apiname + "静态表丢失");
            }
            return null;
        }

        //获取同KEY的多个数据
        public getAPINodes(apiname:string, att:string, val:any, att2:string="", val2:any=""):any 
        {
            var tmp:any = null;
            var result : any[] = [];          
            var api:any = APITool.formatList[apiname];
            
            if (api){
                var idx:number = 0;
                var ln : number = api.length;

                while (idx < api.length){           
                    tmp = api[idx];
                    idx++; 
                    if(tmp.hasOwnProperty(att) && tmp[att] == val){   
                        if(att2 != "" && (!tmp.hasOwnProperty(att2) || tmp[att2] != val2)){
                            continue;
                        }                     
                        result.push(tmp);
                    }
                }
            }
            
            return result;
        } 

        //获取某个API的长度
        public getAPINodesCount(apiname):number{
            var api:any = APITool.formatList[apiname];
            if(api){
                return api.length;
            }else{
                return 0;
            }
        }
	}
export const API = APITool.getInstance();
