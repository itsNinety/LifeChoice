import { HTTP } from "./Http";

/*******************************************
 *  静态数据调用函数
 *  @since 2018.07.21
 *  @author zen
 * 
 *******************************************/

export default class Net {

    private static instance : Net;

    private _item_load_handler;
    private _complete_handler;
    private _error_handler;
    private _urls:Array<string>;
    private _url;
    private _idx;

    public static getInstance():Net{
        if(!Net.instance) {
            Net.instance = new Net();
        }
        return Net.instance;
    }


    public load(urls:Array<string> , onItemLoaded = null  , onComplete = null , onError = null ){
        this._idx = 0;
        this._urls = urls;
        this._item_load_handler = onItemLoaded;
        this._complete_handler = onComplete;
        this._error_handler = onError;
        this._load();
    }

    private _load(){
        if(this._idx >= this._urls.length){
            this._complete_handler & this._complete_handler();
            return;
        }
        this._url = this._urls[this._idx];
        HTTP.httpGets(this._url , this._loadcb.bind(this) , this._error.bind(this));
    }

    private _loadcb(res){
        this._item_load_handler(res);
        this._idx++;
        this._load();
    }

    private _error(res){
        this._error_handler(res);
        this._idx++;
        this._load();
    }
    

}
export const NET = Net.getInstance();