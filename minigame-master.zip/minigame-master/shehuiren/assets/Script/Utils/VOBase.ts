/*******************************************
 *  静态数据元
 *  @since 2018.07.21
 *  @author zen
 * 
 *******************************************/

export class VOBase {
		
    public static Analysis(param1:VOBase, param2:VOBase) : any
    {
        for(var val in param2)
        {   
            var ish : boolean = false;
            var key : string = val;

            if(param1.hasOwnProperty(key)){//两个完全一致
                ish = true;
            }else{//如果不一致
                key = val.toUpperCase();
                if(param1.hasOwnProperty(key)){//转换为大写进行匹配
                    ish = true;
                }else{
                    key = val.toLowerCase();
                    if(param1.hasOwnProperty(key)){//转换为小写进行匹配
                        ish = true;
                    }
                }//不支持大小写混杂，且二者不匹配的问题，可以使用双重for循环处理，建议此时改api。
            } 
            
            if(ish){
                param1[key] = param2[val];
            }else{
                //console.log(param1 + "没有属性>>"+val + ":"+param2[val]);
            }
        }

        return param1;
    }
}