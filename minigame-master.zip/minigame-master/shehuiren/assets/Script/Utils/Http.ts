/*******************************************
 *  基础网络请求类
 *  @since 2018.07.21
 *  @author zen
 * 
 *******************************************/

export default class Http {

    static instance : Http = null;

    static getInstance() {  
        if (Http.instance == null) {  
            Http.instance = new Http();  
        }  
        return Http.instance;  
    }

    httpGets(url, callback , failcallback){
        var xhr = cc.loader.getXMLHttpRequest();  
        xhr.onreadystatechange = function () {  
            if (xhr.readyState === 4){
                if(xhr.status >= 200 && xhr.status < 300) {
                    var respone = xhr.responseText;  
                    callback(respone);  
                }else{
                    failcallback( {'status':xhr.status, 'url':url});
                }
            }
        };  
        xhr.open("GET", url, true);  
        if (cc.sys.isNative) {  
            xhr.setRequestHeader("Accept-Encoding", "gzip,deflate");  
        }
        xhr.timeout = 5000;// 5 seconds for timeout  
  
        xhr.send();  
    }
  
    httpPost(url, params, callback){
        var xhr = cc.loader.getXMLHttpRequest();  
        xhr.onreadystatechange = function () {   
            if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {  
                var respone = xhr.responseText;  
                callback(respone);  
            }else{  
                callback(-1);
            }  
        };  
        xhr.open("POST", url, true);  
        if (cc.sys.isNative) {  
            xhr.setRequestHeader("Accept-Encoding", "gzip,deflate");  
        }
        xhr.timeout = 5000;// 5 seconds for timeout  
        xhr.send(params);  
    }
}
export const HTTP = Http.getInstance();