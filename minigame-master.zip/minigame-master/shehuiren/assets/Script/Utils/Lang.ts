
/*******************************************
 *  语言包类
 *  @since 2018.07.21
 *  @author zen
 * 
 *******************************************/

export class Lang {
    private static instance : Lang;

    //通用界面 L0
    public attrs = {"name":"姓名" ,"sex":"性别" , "age":"年龄", "money":"金钱", "hold":"持仓股票", "happy":"快乐"
                , "lover":"对象", "freetime":"空闲时间", "lefttime":"本月剩余时间", "job":"工作", "salary":"月薪", "health":"健康"
                , "morality":"道德", "ability":"能力", "social":"社交", "exp":"经验", "car":"汽车", "house":"房子"
                , "sindex":"股票指数" ,"hindex":"房产指数", "love":"爱情机遇指数", "career":"事业机遇指数"
    }
    public L0000 : string = 'cVersion:{0} aVersion: {1} \r\ncomplieData : {2}';
    public L0001 : string = '失业';
    public L0002 : string = '单身';
    public L0003 : string = '还没有买房';
    public L0004 : string = '还没有买车';
    public L0005 : string = '时间不够,{0}无法完成';
    public L0006 : string = '金钱不够,{0}无法完成';
    public L0007 : string = '随机事件发生';
    public L0008 : string = '提示';
    public L0009 : string = '开始新游戏，会覆盖之前的记录\n是否重新开始？'
    public L0010 : string = '检查版本号'
    //开始界面 L1
    public L1000: string = '你瞄准了几家公司在网上投了简历，还参加了好几场校园招聘会，虽然过程艰辛，但终于有公司向你伸出了橄榄枝，你要接受这份offer吗？';
    public L1001: string = '苹果教父乔布斯不过高中学历，微软创始比尔·盖茨大学辍学，全球最年轻创业亿万富豪马克·扎克伯格也没读完大学，我堂堂大学毕业生，天之骄子，小小创业又有何难？';
    public L1002: string = '洋洋洒洒写了几百页创业计划，但苦于拉不起团队，也筹不到资金，计划胎死腹中。还是先好好历练一番吧。';
    public L1003: string = '随着教育水平的大幅提升，现在本科生越来越多，本科学历的竞争力略显不足。通过考研来增强自己的专业能力，虽然艰辛，但或许能争取到更高的起点，你要考研试试吗？';
    public L1004: string = '不管制度如何调整，公务员永远是父母眼中的金饭碗。眼看着老家的公务员考试即将开始，父母时时刻刻在你耳边催促，你要跟万人大军抢一个职位吗？';
    public L1005: string = '公务员考试异常激烈，所有考生各显神通，你在面试中因为一分之差，非常不幸没有考上。';
    public L1006: string = '出国留学有非常多的好处，不仅能开阔眼界增长见识，还有就读名校的机会，享受更灵活的教学方式，在未来也会有更强的竞争能力和更大的发展空间，你要准备出国留学吗？';
    public L1007: string = '由于没有做好充分准备，没能成功申请到全额奖学金，家里的经济条件不足以支持你的所有开销，只好作罢。';
    public L1008: string = '恭喜你考上了研究生, 开始三年的研究生学习。';
    public L1009: string = '很抱歉, 你的研究生入学考试没有通过。';
    public L1010: string = '由于研究生期间在本专业学习上投入的精力过少，你留级一年才完成所有学业,初始时间减少48个月。';
    public L1011: string = '初始时间减少36个月。'
    public L1012: string = '哦，是你捡到我了啊？'
    public L1013: string = '等下，别摔我，我不是变态'
    public L1014: string = '我是手机精'
    public L1015: string = '话说如果人生可以重来的话....'
    public L1016: string = '哦，我只是在自言自语'
    public L1017: string = '重启程序已经开始了'
    public L1018: string = '---人生同步至22岁---'
    public L1019: string = '你是帅哥呢还是美女呢'
    public L1020: string = '---性别同步完成---\n22岁差不多是大学毕业踏上社会吧\n就这样了，又不是不能玩\n毕业后你准备…'
    //主界面 L2
    public L2000 : string  = '{0}小时';
    public L2001 : string  = '{0}岁';
    public L2002 : string  = '剩余{0}个月'
    public L2003 : string  = '{0}小时    {1}元';
    public L2004:  string  = '{0}小时    赚了：{1}元'
    public L20031 : string = '开始看专业书籍';
    public L20032 : string = '能力{0}    经验{1}    快乐{2}';
    public L20041 : string = '开始看其他书籍'
    public L20042 : string = '能力{0}    经验{1}    快乐{2}'
    public L20051 : string = '和同事一起派对';
    public L20052 : string = '经验{0}    社交{1}    快乐{2}\n健康{3}    道德{4}';
    public L20061 : string = '参加朋友聚会';
    public L20062 : string = '经验{0}    社交{1}    快乐{2}';
    public L20071 : string = '和好友一起逛街吃饭';
    public L20072 : string = '经验{0}    快乐{1}';
    public L20081 : string = '决定去出门旅游一趟';
    public L20082 : string = '能力{0}    经验{1}    社交{2}\n快乐{3}';
    public L20091 : string = '业余时间参加学习培训';
    public L20092 : string = '能力{0}    经验{1}    快乐{2}\n健康{3}';
    public L20101 : string = '安心当肥宅在家休息睡觉';
    public L20102 : string = '快乐{0}    健康{1}';
    public L20111 : string = '努力工作加班兼职';
    public L20112 : string = '能力{0}    经验{1}    快乐{2}\n健康{3}';
    public L20121 : string = '上网休闲';
    public L20122 : string = '经验{0}    社交{1}    快乐{2}\n健康{3}';
    public L20131 : string = '参加体育健身';
    public L20132 : string = '能力{0}    快乐{1}    健康{2}';
    public L20141 : string = '回家看望父母';
    public L20142 : string = '快乐{0}    健康{1}    道德{2}';
    public L2015 : string  = '本月已经进行了其他操作消耗了空闲时间，无法调整';
    public L2016 : string  = '初入社会小菜鸟，对未来充满希望，浑身都是干劲，游戏内做事从不拖延，立即完成。';
    public L2017 : string  = '职场老鸟，经常加班导致内分泌失调，回家就葛优瘫，deadline才是第一生产力，游戏内每10小时都会拖延1分钟。';
    public L2018 : string  = '正在执行，请稍等';
    public L2019 : string  = '本月空闲时间不足，是否调整待办计划释放空闲时间';
    public L2020 : string  = '有其他事件正在进行中，是否添加到待办计划中自动完成？\n(待办计划不会触发剧情等特殊事件）';
    public L2021 : string  = '已添加至“待办事项”';
    public L2022 : string  = '有其他事项正在进行中，请等待倒计时结束后继续操作。邀请任意好友解锁代办功能，自动完成事件，立即邀请？';
    public L2023 : string  = '当前存在待办事项未结束\n请等待结束后点击下个月'
    
    //股票界面 L3
    public L3000 : string = '钱包：{0}';
    public L3001 : string = '本月股票指数：{0}';
    //彩票界面 L4
    public L4000 : string = '{0}等奖, {1}元';
    public L4001 : string = '钱包：{0}';
    public L4002: string  = '每月只能买一次彩票!';
    //考研界面 L5
    public L5000: string = '精力值已经为0，不能再减少';
    public L5001: string = '已无多余精力可以分配';
    public L5002: string = '你的';
    public L5003: string = '经验+{0},';
    public L5004: string = '能力+{0},';
    public L5005: string = '金钱+{0},';
    public L5006: string = '获得一份工作:{0}{1},';
    public L5007: string = '交际+{0},';
    public L5008: string = '事业指数+{0},';
    public L5009: string = '获得一辆{0},';
    public L5010: string = '获得一套{0},';
    public L5011: string = '道德+{0},';
    public L5012: string = '健康+{0},';
    public L5013: string = '快乐+{0},';
    public L5014: string = '爱情指数+{0},';
    public L5015: string = '剩余月份+{0},';
    public L5016: string = '股票持仓+{0}'
    //人才市场 L6
    public L6000: string = '要求：能力{0} 经验{1}';
    public L6001: string = '中介费：{0}';
    public L6002: string = '{0}/月';
    public L6003: string = '换一批({0})';
    public L6004: string = '钱包： {0}';
    public L6005: string = '经验：{0} 能力：{1}';
    public L6006: string = '已经是当前职位，请另选他职';
    public L6007: string = '你的能力，经验均未达到要求，未能应聘成功';
    public L6008: string = '你的能力没达到要求，未能应聘成功';
    public L6009: string = '你的经验没达到要求，未能应聘成功';
    public L6010: string = '你的钱不足以支付中介费，不能应聘';
    public L6011: string = '你的金钱-{0}\n你的每月薪水变为{1}';
    public L6012: string = '没有时间去参加面试了\n下个月再来吧。';
    public L6013: string = '能力+{0}，经验+{1},快乐+{2},交际+{3}'  //接L6011
    //车行 L7
    public L7000: string = '维护：';
    public L7001: string = '/月'
    public L7002: string = '￥';
    public L7003: string = '换一批({0})';
    public L7004: string = '钱包';
    public L7005: string = '确定以{0}的价格出售本车吗？';
    public L7006: string = '您已出售了一辆{0},你的金钱增加{1}';
    public L7007: string = '您已成功购买\n消费了{0}元';
    public L7008: string = '你的钱不足以购买此辆车';
    public L7009: string = '请先出售车, 才能购买';
    public L7010: string = '本月交易次数已用完\n下个月再来吧。';
    public L7011: string = '邀请三个及以上好友\n即可点击刷新按钮';
    public L7012: string = '能力+{0},经验+{1},快乐+{2}';  //接L7007
    //房产 L8
    public L8000: string = '本月房价指数：{0}%';
    public L8001: string = '换一批({0})';
    public L8002: string = '钱包： {0}';
    public L8003: string = '确定以{0}的价格出售该房吗？';
    public L8004: string = '您已出售了一套{0},你的金钱增加{1}';
    public L8005: string = '您已成功购买\n消费了{0}元';
    public L8006: string = '你的钱不足以购买该套房';
    public L8007: string = '请先出售房, 才能购买';
    public L8008: string = '能力+{0},经验+{1},快乐+{2}';            //接L8005
    public L8009: string = '本月可刷新次数已用完';
    public L8010: string = '邀请三个及以上好友，每月即可增加一次免费刷新次数\n立即邀请？'
    //联系人 L9
    //对话 L10
    //待办事项 L11
    public L11000:string = '金钱{0},能力+{1},经验+{2},快乐{3}';                 //专业书籍
    public L11001:string = '金钱{0},能力+{1},经验+{2},快乐+{3}';                //其它书籍
    public L11002:string = '金钱{0},经验+{1},社交+{2},快乐+{3}，健康{4},道德{5}';    //同事派对
    public L11003:string = '金钱{0},经验+{1},社交+{2},快乐+{3}';                //朋友聚会
    public L11004:string = '金钱{0},经验+{1},快乐+{2}';                       //逛街吃饭
    public L11005:string = '金钱{0},能力+{1},经验+{2},+社交{3},快乐+{4},健康+{5}';  //出门旅游
    public L11006:string = '金钱{0},能力+{1},经验+{2}，快乐{3},健康{4}';           //学习培训
    public L11007:string = '快乐+{0},健康+{1}';                             //在家休息
    public L11008:string = '金钱{0},能力+{1},经验+{2},快乐{3},健康{4}';           //加班兼职
    public L11009:string = '金钱{0},经验+{1},社交{2},快乐+{3},健康{4}';           //上网休闲
    public L11010:string = '金钱{0},能力+{1},快乐+{2},健康+{3}';                //体育锻炼
    public L11011:string = '金钱{0},快乐+{1},健康+{2},道德+{3}';                //看望父母
    public L11012:string = '剩余空闲时间: ';
    public L11013:string = '小时';
    public L11014:string = '剩余';
    public L11015:string = '小时,现实消耗';
    public L11016:string = '分钟'

    //成绩单界面 L12
    public L12000:string = '已保存至相册\n快去分享吧'
    public L12001:string = '还没有买车'
    public L12002:string = '还没有买房'
    public L12003:string = '还没有对象'

    //邀请与分享
    public shareUrl : string = 'https://cdnh5.nibaguai.com/wxapp/BlackWhitePingPong/{0}.png';
    public shareCopywriting = [
        '葬爱家族重出江湖，诚招杀马特族长',
        '小猪佩奇身上纹，掌声送给社会人',
        '中年危机的8个症状，看看你中了几个？'
    ]


    public static getInstance():Lang{
        if(!Lang.instance) {
            Lang.instance = new Lang();
        }
        return Lang.instance;
    }
    

    //格式化字符串 Lang.format("{0}，你好，你喜欢吃{1}吗？", "小明" ,"棒棒糖");
    public format(str : string , ... args: any[]):string{
        if (args.length == 0)
            return null;
        for (var i = 0; i < args.length; i++) {
            var re = new RegExp('\\{' + i + '\\}', 'gm');
            str = str.replace(re, args[i]);
        }
        return str;
    }
    
    public formatWithSymbol(str : string , ... args: any[]):string{
        if (args.length == 0)
            return null;
        for (var i = 0; i < args.length; i++) {
            var re = new RegExp('\\{' + i + '\\}', 'gm');
            let s = args[i];
            let n = parseInt(s);
            if(n > 0) s = '+'+n;
            str = str.replace(re, s);
        }
        return str;
    }
    
}
export const LANG = Lang.getInstance();