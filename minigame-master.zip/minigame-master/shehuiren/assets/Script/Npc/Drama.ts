import { API } from "../Utils/APITool";
import Dialog from "../Comps/Dialog";
import Phone from "../Comps/Phone";
import { UTILS } from "../Utils/Utils";
import { INFO } from "../Data/Info";
import { CONTACTS } from "./Contacts";

/**
 * 剧情播放控制
 */
export default class Drama extends cc.Component {

    
    private static instance : Drama;

    private _current_jqid = 0 ;
    
    public static getInstance():Drama{
        if(!Drama.instance) {
            Drama.instance = new Drama();
        }
        return Drama.instance;
    }

    private jq_atts = '';
    public showDramaFrom(start_jqid){
        let d = API.getAPINode('juqing' , 'id' , start_jqid);
        this._current_jqid = start_jqid;
        if(d){
            if(d.type == 1){
                Phone.getInstance().close();
                let arr = d.content.split('_');
                if(arr.length == 2){
                    this.jq_atts = arr[1]
                }
                Dialog.getInstance().showDialog(d.name , arr[0], d.scene, d.avatar , this.continuecb.bind(this))
            }else if(d.type == 2){
                //添加微信信息
                //写入微信消息小红点提示;
                INFO.npcs[parseInt(d.npc)].addWXMessage(d.id);
                INFO.addRedPot(14);
                
            }else if(d.type == 3){
                //电话消息
                let arr = d.content.split('_');
                if(arr.length == 2){
                    this.jq_atts = arr[1]
                }
                Phone.getInstance().show(d.name,  arr[0] ,d.avatar  ,this.continuecb.bind(this))

            }

            if(d.finish.indexOf('wx')!=-1){
                let narr= d.finish.split('#');
                CONTACTS.addNewPeople(parseInt(narr[1]));
            }
        }
    }


    private continuecb(){
        //先处理扣费
        if(this.jq_atts != ''){
            UTILS.changAtts(this.jq_atts);
            this.jq_atts  = '';
        }
        //
        let d = API.getAPINode('juqing' , 'id' , this._current_jqid);
        
        if(d.finish == 'tbc'){
            Dialog.getInstance().close();
            Phone.getInstance().close();
            return;
        }
        if(d.finish.indexOf('npc') != -1){
            //获得异性朋友
            let str = d.finish;
            let cp = str.split('#');
            INFO.lover = parseInt(cp[1]);
            Dialog.getInstance().close();
            return;
        }
        if(d.question != 0){
            let que = API.getAPINode('juqing_question' , 'id' , d.question)
            if(que){
                let that = this;
                let ar1 = que.ans1.split('_');
                let ar2 = que.ans2.split('_');
                Dialog.getInstance().showQuestion(que.desc , que.scene , que.avatar ,ar1[0] ,ar2[0] , function(){
                    UTILS.changAtts(ar1[1]);
                    that._current_jqid = que.next1;
                    that.showDramaFrom(that._current_jqid);
                },function(){
                    UTILS.changAtts(ar2[1]);
                    that._current_jqid = que.next2;
                    that.showDramaFrom(that._current_jqid);
                });
            }else{
                console.log('不存在的问题id' , d.question);
            }
            return;
        }
        this.showDramaFrom(++this._current_jqid);
        
    }
}

export const DRAMA = Drama.getInstance();