import Npc from "./Npc";
import { INFO } from "../Data/Info";


/*******************************************
 *  联系人和聊天信息记录
 *  @since 2018.09.08
 *  @author zen
 * 
 *******************************************/

export default class Contacts{

    private static instance : Contacts;

    public contact_list : Array<Npc> = [];

    public static getInstance():Contacts{
        if(!Contacts.instance) {
            Contacts.instance = new Contacts();
        }
        return Contacts.instance;
    }

    //添加新联系人
    public addNewPeople(npc_id){
        let npc : Npc;
        if(INFO.npcs[npc_id]!=null){
            npc = INFO.npcs[npc_id]
        }else{
            npc = new Npc;
            npc.id = npc_id;
            npc.order = 0;
            INFO.npcs[npc_id] = npc;
        }
        this.contact_list.push(npc);
    }

    public getList(){
        let ret = [];
        for(let i = 0 ; i < this.contact_list.length ; i++){
            ret.push(this.contact_list[i].id);
        }
        return ret;
    }

    public initList(list){
        for(let i = 0 ; i < list.length ;i++){
            this.addNewPeople(list[i]);
        }
    }

}
export const CONTACTS = Contacts.getInstance();
