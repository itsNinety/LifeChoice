import { API } from "../Utils/APITool";
import { INFO } from "../Data/Info";

/*******************************************
 *  NPC信息
 *  @since 2018.09.5
 *  @author zen
 * 
 *******************************************/

export default class Npc {
    //NPC的id
    public id : number = 0;
    //剧情推进的id
    public order : number = 0;
    //关系
    public relation : number = 0;
    //新消息数量
    public new_msg : number = 0;
    //历史消息
    public msgs  = []; 

    private _info = null;

    public get info(){
        if(this._info == null){
            this._info = API.getAPINode('npc' , 'id', this.id);
        }
        return this._info;
    }


    //检查是否触发剧情
    public checkNextRequire(did){
        console.log('我是npc',this.id,'检查是否触发我的剧情')
        let jq = API.getAPINode('juqing_start', 'npc' , this.id , 'order' , this.order)
        if(!jq){
            return  0;
        }
        let require = jq.require;
        let arr= require.split('|');
        for(let  i = 0 ; i < arr.length; i++){
            let _req = arr[i].split('#');
            if(_req[0] == 'daily'){
                if(did != _req[1]){
                    return 0;
                }
            }else{
                console.log('判断' , _req[0] , '当前'+INFO[_req[0]] , '需要'+_req[1])
                if(parseInt(INFO[_req[0]]) < parseInt(_req[1])){
                    console.log('不能满足条件');
                    return 0
                }
            }
        }
        console.log('触发剧情' ,this.order, jq.next ,jq.order);
        return jq.next;
    }

    public checkNextRequireAtt(att){
        let jq = API.getAPINode('juqing_start', 'npc' , this.id , 'order' , this.order)
        if(!jq){
            return  0;
        }
        let require = jq.require;
        if(require.indexOf('|') == -1){
            let _req = require.split('#');
            if(parseInt(INFO[_req[0]]) >= parseInt(_req[1])){
                return jq.next;
            }
        }
        return 0
    }


    //添加微信内容
    public addWXMessage(msg){
        if(this.msgs.indexOf(msg) == -1){
            this.msgs.push(msg);
            this.new_msg++;
        }
    }
    
}
