import { INFO } from "./Info";
import { API } from "../Utils/APITool";
import { NET } from "../Utils/Net";

/*******************************************
 *  游戏配置-单例
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

export default class Config{
    public coreVer : string = 'v0.0.1';//代码版本
    public assetVer : string = 'v0.0.7';//素材版本

    public separator : string = '####';//

    public verurl : string = 'https://cdnh5.nibaguai.com/wxgame/shr/json/v.json?'+Math.random();
    private baseurl : string    = 'https://cdnh5.nibaguai.com/wxgame/shr/json/';
    public  eventurl : string   = 'https://cdnh5.nibaguai.com/wxgame/shr/pics/events/{0}.jpg';
    public  houseurl : string   = 'https://cdnh5.nibaguai.com/wxgame/shr/pics/house/{0}.jpg';
    public  carurl : string     = 'https://cdnh5.nibaguai.com/wxgame/shr/pics/car/{0}.jpg';
    public  channelurl : string = 'https://cdnh5.nibaguai.com/wxgame/shr/pics/channel/{0}.jpg';
    public  bgurl : string      = 'https://cdnh5.nibaguai.com/wxgame/shr/pics/npc/bg/{0}.jpg';
    public  avatarurl : string  = 'https://cdnh5.nibaguai.com/wxgame/shr/pics/npc/avatar/{0}.png';
    public  head2url : string   = 'http://cdn.h5.nibaguai.com/wxgame/shr/pics/npc/head2/{0}.jpg'
    public  headurl : string    = 'http://cdn.h5.nibaguai.com/wxgame/shr/pics/npc/head/{0}.png'
    private sex  :string        = 'male/';

    public icons  = [
        {'id':1,'icon':'1','name':'看专业书籍','click':'event_1'},
        {'id':2,'icon':'2','name':'看其他书','click':'event_2'},
        {'id':3,'icon':'3','name':'加班兼职','click':'event_9'},
        {'id':4,'icon':'4','name':'学习培训','click':'event_7'},
        {'id':5,'icon':'5','name':'度假旅游','click':'event_6'},
        {'id':6,'icon':'6','name':'休闲娱乐','click':'event_10'},
        {'id':7,'icon':'7','name':'参加派对','click':'event_3'},
        {'id':8,'icon':'8','name':'逛街购物','click':'event_5'},
        {'id':9,'icon':'9','name':'睡觉休息','click':'event_8'},
        {'id':10,'icon':'10','name':'看望父母','click':'event_12'},
        {'id':11,'icon':'11','name':'朋友聚会','click':'event_4'},
        {'id':12,'icon':'12','name':'运动健身','click':'event_11'},
        {'id':13,'icon':'21','name':'资产管理','click':'pop'},
        {'id':14,'icon':'13','name':'联系人','click':'jump_ContactsScene'},
        {'id':15,'icon':'14','name':'待办计划','click':'jump_BacklogScene'},
        //{'id':16,'icon':'15','name':'排行榜','click':'jump_RankingScene'},
        
        
        {'id':17,'icon':'16','name':'股票','click':'jump_StockScene'},
        {'id':18,'icon':'17','name':'应聘','click':'jump_LabourMarketScene'},
        {'id':19,'icon':'18','name':'房产','click':'jump_HouseDealerScene'},
        {'id':20,'icon':'19','name':'买车','click':'jump_CarDealerScene'},
        {'id':21,'icon':'20','name':'买彩票','click':'jump_LotteryScene'}
    ]

    //读研礼包
    public postGift = [
        {'id':1, 'icon':'1.png','name':'事业礼包','click':'career_pop'},
        {'id':2, 'icon':'2.png','name':'生活礼包','click':'life_pop'},
        {'id':3, 'icon':'3.png','name':'个性礼包','click':'personality_pop'},
    ]

    public lotteryBonus = [
        {'id':1, 'name':'一','value':'50000000'},
        {'id':2, 'name':'二','value':'5000000'},
        {'id':3, 'name':'三','value':'500000'},
        {'id':4, 'name':'四','value':'50000'},
        {'id':5, 'name':'五','value':'5000'},
        {'id':6, 'name':'六','value':'500'},
    ]

    public backlog = [
            {'id':1,'icon':'1.png','name':'看专业书籍','fakeid':1},
            {'id':2,'icon':'2.png','name':'看其他书','fakeid':2},
            {'id':3,'icon':'7.png','name':'参加派对','fakeid':7},
            {'id':4,'icon':'11.png','name':'朋友聚会','fakeid':11},
            {'id':5,'icon':'8.png','name':'逛街购物','fakeid':8},
            {'id':6,'icon':'5.png','name':'度假旅游','fakeid':5},
            {'id':7,'icon':'4.png','name':'学习培训','fakeid':4},
            {'id':8,'icon':'9.png','name':'睡觉休息','fakeid':9},
            {'id':9,'icon':'3.png','name':'加班兼职','fakeid':3},
            {'id':10,'icon':'6.png','name':'休闲娱乐','fakeid':6},
            {'id':11,'icon':'12.png','name':'运动健身','fakeid':12},
            {'id':12,'icon':'10.png','name':'看望父母','fakeid':10}
    ]

    private _attr = null;

    private static instance : Config;

    public static getInstance():Config{
        if(!Config.instance) {
            Config.instance = new Config();
        }
        return Config.instance;
    }

    public get attr(){
        this._attr = [
            {"id":1 , "name":"健康","eng": "health", "num": INFO.health},
            {"id":2 , "name":"道德","eng": "morality", "num": INFO.morality},
            {"id":3 , "name":"快乐","eng": "happy", "num": INFO.happy},
            {"id":4 , "name":"能力","eng": "ability", "num": INFO.ability},
            {"id":5 , "name":"交际","eng": "social", "num": INFO.social},
            {"id":6 , "name":"经验","eng": "exp", "num": INFO.exp}
        ]
        return this._attr;
    }

    public getDataUrl(){
        return [
            /*
                this.baseurl + 'house.json?'+ this.assetVer,
                this.baseurl + 'car.json?'+ this.assetVer,
                this.baseurl + 'job.json?'+ this.assetVer,
                this.baseurl + 'basic_num.json?'+this.assetVer,
                this.baseurl + 'graduate.json?'+this.assetVer,
                this.baseurl + 'pg_gift.json?'+this.assetVer,
                this.baseurl + 'random_event.json?'+this.assetVer,
                this.baseurl + 'opportunity.json?'+this.assetVer,
                this.baseurl + 'npc.json?' + this.assetVer,
            */
                this.baseurl + 'zipjson?' + this.assetVer,
        ]
    }

    //返回和性别相关的数据
    private getSexDataUrl(){
        if(INFO.sex == 0){
            this.sex = 'female/'
        }
        return [
            /*
            this.baseurl + this.sex + 'daily_event.json?' + this.assetVer,
            this.baseurl + this.sex + 'juqing.json?'+this.assetVer,
            this.baseurl + this.sex + 'juqing_question.json?'+this.assetVer,
            this.baseurl + this.sex + 'juqing_start.json?'+this.assetVer,
            this.baseurl + this.sex + 'game_end.json?'+this.assetVer,
            */
            this.baseurl + this.sex + 'zipjson?'+this.assetVer,

        ]
    }

    //加载性别相关数据
    private _total_load  = 0;
    private _current_load = 0;
    private _load_sex_finished_cb;
    public getSexData( fcb){
        this._load_sex_finished_cb  = fcb;
        let urls = this.getSexDataUrl();
        this._total_load = urls.length;
        NET.load(urls , this.dataLoaded.bind(this) , this.allLoaded.bind(this)  , this.loadError.bind(this) );
    }

    private dataLoaded(res){
        //逐条添加基础数据
        let arr = res.split(CONFIG.separator);
        for(let i = 0 ; i < arr.length;i++){
            if(arr[i].length > 1){
                API.add_json(arr[i]);
            }
        }
        //进度
        this._current_load++;
    }

    private allLoaded(){
        //使用方法
        this._load_sex_finished_cb();
    }
    private loadError(res){

    }

}
export const CONFIG = Config.getInstance();