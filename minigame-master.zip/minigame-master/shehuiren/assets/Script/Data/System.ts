import { API } from "../Utils/APITool";
import Alert from "../Comps/Alert";
import { UTILS } from "../Utils/Utils";
import { INFO } from "./Info";
import { LANG } from "../Utils/Lang";
import { CONFIG } from "./Config";
import Comfire from "../Comps/Comfire";
import MainScene from "../Scene/MainScene";
import { SDATA } from "./StockData";
import { HDATA } from "./HouseData";
import { DRAMA } from "../Npc/Drama";
import ComfireShare from "../Comps/ComfireShare";
import ComfireOppo from "../Comps/ComfireOppo";
import Age from "../Comps/Age";

/*******************************************
 *  游戏系统逻辑-单例
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

export default class System {

    private static instance : System;

    public mainscene : MainScene;

    public static getInstance():System{
        if(!System.instance) {
            System.instance = new System();
        }
        return System.instance;
    }

    month = 0;
    //进入下个月
    public nextMonth(){
        //判断结束
        if(INFO.happy <= 0 || INFO.morality <= 0 || INFO.health <= 0 || INFO.month <= 0){
            cc.director.loadScene('FinishScene');
        }
        //发放工资
        INFO.money         += INFO.salary;
        INFO.month         -= 1;
        INFO.lefttime       = INFO.freetime;
        INFO.fakeLeftTime   = INFO.lefttime;
        INFO.fakeLeftMoney  = INFO.money;
        //环境变化
        //36月后状态变为拖延症(若邀请好友少于5)
        if(++this.month >= 36 && INFO.friends_Invited < 5){
            INFO.status = 1;
        }
        else if(INFO.friends_Invited >= 5){
            INFO.status = 0;
        }
        //已做过日常事件清零
        for(let i = 0; i < 12; i++){
            this.alreadyDone[i] = 0;
        }  
        this.updateCarHouseJob();
        
        if(INFO.month%12 == 0){
            INFO.age++;
            Age.getInstance().show(INFO.age, this);
        }
        else if(INFO.month>=0){//触发一个随机事件
            let evt = this.getRandomEvent();
            Comfire.getInstance().show(LANG.L0007 , evt.desc , LANG.format(CONFIG.eventurl , evt.pic) , this.onEventYes.bind(this) , this.onEventNo.bind(this) , evt);
        }

    }

    //下个月的事件结束后，执行的函数，顺序在nextMonth之后
    public nextMonthEnd(){
        //股市每月变化
        SYSTEM.updateStock();
        //记录下当前数据
        INFO.saveDataToLocal();
    }

    public onEventYes(res){
        this.dealCondition(res.yes);
    }

    public onEventNo(res){
        this.dealCondition(res.no)
    }

    private dealCondition(res){
        //处理确认
        let arr = res.split(',');
        let words;
        let rewards;
        let attr;
        if(arr.length > 1){//存在多种可能，开始筛选
            let rarr = [];//打算用来做随机的数组;
            for(let i = 0; i < arr.length ; i++){
                let item = arr[i];
                let tmp = item.split('_');
                let obj = {'w':tmp[0] , 'c':tmp[1], 'r':tmp[2]};
                if(obj.c == 'R'){
                    rarr.push(obj);
                }else{
                    //判断是否符合入选条件
                    if(UTILS.checkMatch(obj.c)){
                        rarr.push(obj)
                    }
                    //
                }

                let ret = rarr[Math.floor(Math.random()*rarr.length)];
                words = ret.w;
                rewards = ret.r;
            }
            //
        }else{//只有一种可能性
            let sel = res.split("_");
            words = sel[0];
            rewards =sel[2];
        }
        //格式化
        attr = UTILS.getAtts(rewards);

        //处理数值变化
        let aarr = rewards.split("|");
        for(let i = 0; i < aarr.length; i++){
            let tmp = aarr[i].split("#");
            let arg = tmp[1];
            //console.log('变化前' , tmp[0] , INFO[tmp[0]]);
            if(arg.indexOf('%')!= -1){
                //按照百分比变化
                if(tmp[0] == 'hindex'){
                    HDATA.random_event_change = 1+(parseInt(arg.replace('%',''))/100+1);
                }else if(tmp[0] =='sindex'){
                    //随机事件对股票指数影响
                    SDATA.event_change = (parseInt(arg.replace('%',''))/100);
                }else{
                    INFO[tmp[0]] *=  (parseInt(arg.replace('%',''))/100+1);
                }
            }else{
                INFO[tmp[0]]+= parseInt(UTILS.replaceCost(arg));
            }
            //console.log('变化后' , tmp[0] , INFO[tmp[0]]);
        }
        this.showComfireAlert(words, attr);
    }

    private showComfireAlert(w, a){
        Alert.getInstance().show(w , function(){
            Comfire.getInstance().close();
            SYSTEM.nextMonthEnd();
            SYSTEM.mainscene.freshView();
        }, a, false);
    }

    //获取一个随机事件
    public getRandomEvent(){
        let len   = API.getAPINodesCount('random_event');
        let r     = Math.ceil(len * Math.random());
        let event = API.getAPINode('random_event' , 'id' , r);
        if(UTILS.checkMatch(event.e_require)){
            return event;
        }
        return this.getRandomEvent();
    }

    //待办事项、车行、房产、人才市场相关信息的每月更新
    public updateCarHouseJob(){
        //待办事项数组清空以及索引等更新
        INFO.arr_backlog         = [];
        INFO.currentBacklogIndex = -1;
        INFO.backlogRestTime     = 1;
        //车辆、房产、人才市场本月可操作次数更新, 彩票and时间条
        INFO.purchaseCar   = 1;
        INFO.purchaseHouse = 1;
        INFO.changeJob     = 1;
        INFO.lotTimes      = 1;
        INFO._slider_flag  = 1;
        //车辆、房产、人才市场本月可刷新次数更新
        if(INFO.friends_Invited >= 3){
            INFO.carRefreshTime   = 1;
            INFO.houseRefreshTime = 1;
            INFO.jobRefreshTime   = 1;
        }else{
            INFO.carRefreshTime   = 0;
            INFO.houseRefreshTime = 0;
            INFO.jobRefreshTime   = 0;
        }
        //每月随机显示的车辆更新
        let cars = API.getAPI('car')
        UTILS.randomNumCreate(cars.length,INFO.monthCarRandom);
        //每月随机显示的车辆更新
        let house = API.getAPI('house')
        UTILS.randomNumCreate(house.length,INFO.monthHouseRandom);
        //每月随机显示的人才市场更新
        let jobs = API.getAPI('job')
        UTILS.randomNumCreate(jobs.length,INFO.monthJobRandom);
        
        //房价的长线指数更新
        this.updateHindexLongChange();
        //房价指数的随机事件设为1，注：该设置要写在随机事件触发之前
        HDATA.random_event_change = 1;
        SDATA.event_change        = 0;  //股票指数的随机事件影响设为0
        //检测是否有车有房并作出相应属性变化
        this.checkCarChange();
        this.checkHouseChange();
    }


    //本月已做过的日常事件, 用于判断10%触发好友分享事件, 0~11对应1~12
    alreadyDone = [0,0,0,0,0,0,0,0,0,0,0,0];
    //点击日常行为事件
    public dailyEvent(id , cb){
        let daily = API.getAPINode('daily_event' , 'id' , id);
        //先判断是否是拖延症
        if(INFO.status == 1){//拖延症状态下
            if(INFO.currentFirstEventId == -1 && (INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length)){ 
                if(INFO.fakeLeftTime + parseInt(daily.time_cost) < 0){
                    Alert.getInstance().show(LANG.format(LANG.L0005 , daily.name));
                    return;
                }else if(INFO.fakeLeftMoney + parseInt(daily.money) < 0){
                    Alert.getInstance().show(LANG.format(LANG.L0006 , daily.name));
                    return;
                }else{
                    console.log("虚假时间",daily.time_cost)
                    INFO.fakeLeftMoney += parseInt(daily.money); //扣除虚假金钱
                    INFO.fakeLeftTime += parseInt(daily.time_cost); //扣除虚假时间
                    INFO.currentFirstEventId = id;
                    INFO.realFirstEventId = id;
                    // INFO.backlogRestTime = -API.getAPI('daily_event')[id -1].time_cost/10 *60;
                    INFO.backlogRestTime = -parseInt(daily.time_cost)/10 *60;
                    UTILS.countDown();
                }
            }else{
                if(INFO.friends_Invited >= 1){
                    //说明待办事项已经开启
                    let daily = API.getAPINode('daily_event' , 'id' , id);
                    if(INFO.fakeLeftMoney + parseInt(daily.money) < 0){
                        Alert.getInstance().show(LANG.format(LANG.L0006 , daily.name));
                        return;
                    }else if(INFO.fakeLeftTime + parseInt(daily.time_cost) < 0){
                        Alert.getInstance().show2(LANG.L2019, function(){
                            cc.director.loadScene('BacklogScene');
                        });
                        return;
                    }else{
                        Alert.getInstance().show2(LANG.L2020, function(){
                            INFO.saveDataToLocal();//测试用
                            INFO.arr_backlog.push(CONFIG.backlog[id-1]);
                            if(INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length ){
                                INFO.currentBacklogIndex = INFO.arr_backlog.length -1;
                            }
                            console.log("虚假时间+",daily.time_cost)
                            INFO.fakeLeftMoney += parseInt(daily.money); //扣除虚假金钱
                            INFO.fakeLeftTime += parseInt(daily.time_cost); //扣除虚假时间
                            Alert.getInstance().show(LANG.L2021)
                        });
                    }
                }else{
                    //说明待办事项还未开启
                    Alert.getInstance().show2(LANG.L2022, function(){
                        cc.director.loadScene('InviteScene');
                    })
                }
            }
        }
        else if(INFO.status == 0){//干劲满满状态  
            this.dialyNormal(id, daily, cb);
        }
    }

    //干劲满满状态下，进行日常事件
    public dialyNormal(id, daily, cb){
        let that = this;
        //判断是否满足条件，若否则返回
        if(INFO.lefttime + parseInt(daily.time_cost) < 0){
            Alert.getInstance().show(LANG.format(LANG.L0005 , daily.name));
            return;
        }
        if(INFO.money + parseInt(daily.money) < 0){
            Alert.getInstance().show(LANG.format(LANG.L0006 , daily.name));
            return;
        }
        //执行到此，表示该日常事件可以做，且已经算作有效做过一次了//累加已做过的日常事件
        INFO.oppoTimes[id-1]++;
        //10%触发好友分享事件，代替日常事件
        if(this.alreadyDone[id-1] == 0 && Math.floor(Math.random()*100) < 10){
            this.alreadyDone[id-1] = 1;
            let a = UTILS.getDailyWords(daily.id);
            //a[0] += daily.cooperation;//加上分享字段
            ComfireShare.getInstance().show(
                daily.name , 
                a , 
                LANG.format(CONFIG.eventurl , daily.pic) ,
                function(){//分享
                    if(cb!=null){
                        cb()
                    }
                    ComfireShare.getInstance().close();
                    that.oppoEvent(id, cb);//判断是否触发机遇事件
                }, 
                function(){//不分享
                    //处理数值
                    INFO.lefttime += parseInt(daily.time_cost);
                    INFO.ability  += parseInt(daily.ability);
                    INFO.exp      += parseInt(daily.exp);
                    INFO.social   += parseInt(daily.social);
                    INFO.happy    += parseInt(daily.happy);
                    INFO.health   += parseInt(daily.health);
                    INFO.morality += parseInt(daily.morality);
                    INFO.money    += parseInt(daily.money);
                    if(cb!=null){
                        cb()
                    }
                    ComfireShare.getInstance().close();
                    that.oppoEvent(id, cb);//判断是否触发机遇事件
                }, daily);
        }
        else{//正常进行日常事件
            this.alreadyDone[id-1] = 1;
            //先处理数值
            INFO.lefttime += parseInt(daily.time_cost);
            INFO.ability  += parseInt(daily.ability);
            INFO.exp      += parseInt(daily.exp);
            INFO.social   += parseInt(daily.social);
            INFO.happy    += parseInt(daily.happy);
            INFO.health   += parseInt(daily.health);
            INFO.morality += parseInt(daily.morality);
            INFO.money    += parseInt(daily.money);
            console.log(INFO.lefttime , INFO.ability ,INFO.exp,INFO.social , INFO.happy, INFO.morality , INFO.money)
            Comfire.getInstance().showDaily(
                daily.name , 
                UTILS.getDailyWords(daily.id) , 
                LANG.format(CONFIG.eventurl , daily.pic) ,
                function(){
                    if(cb!=null){
                        cb()
                    }
                    Comfire.getInstance().close();
                    that.oppoEvent(id, cb);//判断是否触发机遇事件
                    let jq = that.checkJuqingByDaily(daily.id);
                    if(jq){
                        DRAMA.showDramaFrom(jq);
                    }
                }, 
                null);
        }
    }

    public oppoEvent(id, cb){
        //判断是否触发机遇事件
        let oppo = API.getAPINode('opportunity' , 'id' , id);
        if(INFO.oppoTimes[id-1] >= oppo.frequency){//
            INFO.oppoTimes[id-1] = 0;
            ComfireOppo.getInstance().show(
                oppo, 
                function(){//c1
                    if(cb!=null){
                        cb()
                    }
                    ComfireOppo.getInstance().close();
                    UTILS.changAtts(oppo.choose1.split('_')[1]);
                    Alert.getInstance().show(null, function(){
                        Alert.getInstance().hide();
                    }, UTILS.getAtts(oppo.choose1.split('_')[1]))
                }, 
                function(){//c2
                    if(cb!=null){
                        cb()
                    }
                    ComfireOppo.getInstance().close();
                    UTILS.changAtts(oppo.choose2.split('_')[1]);
                    Alert.getInstance().show(null, function(){
                        Alert.getInstance().hide();
                    }, UTILS.getAtts(oppo.choose2.split('_')[1]))
                }, 
                function(){//c3
                    if(cb!=null){
                        cb()
                    }
                    ComfireOppo.getInstance().close();
                    UTILS.changAtts(oppo.choose3.split('_')[1]);
                    Alert.getInstance().show(null, function(){
                        Alert.getInstance().hide();
                    }, UTILS.getAtts(oppo.choose3.split('_')[1]))
                }, 
                function(){//c4
                    if(cb!=null){
                        cb()
                    }
                    ComfireOppo.getInstance().close();
                    UTILS.changAtts(oppo.choose4.split('_')[1]);
                    Alert.getInstance().show(null, function(){
                        Alert.getInstance().hide();
                    }, UTILS.getAtts(oppo.choose4.split('_')[1]))
                }, 
                null);
        }
    }

/*******************************************
 *  买彩票, public L4000 : string = '{0}等奖, {1}元'
 *  friends_Invited: number = 0;//为已经邀请的好友数量。1,3,5,10触发条件
 *  注：应从一等奖至六等奖依次判断，前者可屏蔽后者.
 *  邀请好友概率变化：
 *  邀请一个好友，四等奖概率千分之一提升到千分之五
 *  邀请三个好友，三等奖概率万分之一提升到千分之二
 *  邀请五个好友，二等奖概率十万分之一提升到千分之一
 *  邀请十个好友，一等奖概率百万分之一提升到万文之一
 *  @since 2018.08.24
 *  @author lyc
 *******************************************/
    public buyLottery(){  
        INFO.money -= 100;//确认买彩票，金币减100
        INFO.lotTimes -= 1;//每月购彩票次数减一
        let random = Math.floor(Math.random()*1000000);//一百万以内的随机数
        if(INFO.friends_Invited >= 10 && random < 100 || random < 1){
            INFO.money += 50000000;
            return this.getLottery(0);
        }
        if(INFO.friends_Invited >= 5 && random < 1000 || random < 10){
            INFO.money += 5000000;
            return this.getLottery(1);   
        }
        if(INFO.friends_Invited >= 3 && random < 2000 || random < 100){
            INFO.money += 500000;
            return this.getLottery(2);
        }
        if(INFO.friends_Invited >= 1 && random < 5000 || random < 1000){
            INFO.money += 50000;
            return this.getLottery(3);
        }
        if(random < 10000){
            INFO.money += 5000;
            return this.getLottery(4);
        }
        if(random < 100000){
            INFO.money += 500;
            return this.getLottery(5);
        }
        return '没有中奖';
    }
    //返回结果string
    public getLottery(num){
        let lotBonus = CONFIG.lotteryBonus;
        console.log(LANG.format(LANG.L4000, lotBonus[num].name, lotBonus[num].value));
        return LANG.format(LANG.L4000, lotBonus[num].name, lotBonus[num].value);
    }

/*******************************************
 *  股票界面需要展示的数据:
 *  wallet: 钱包, 即INFO.money
 *  money: 实际持有的股票金额, 即INFO.stock_money
 *  last: 上月收益, 更新INFO.stock_money时可以算出并返回
 *  earnings: 持有收益, INFO.stock_money - INFO.stock_cost持有总额与投资总额的差
 *  rate: 涨跌幅度, (SDATA.curr_sindex - INFO.stock_index) / SDATA.curr_sindex
 *  stockIndex: 本月股票指数=初始指数*
 *     （固定长线变化2%+随机长线变化-0.5%~0.5%+短期变化+事件变化）
 *      短期变化每年年初时触发，持续12个月（-5%~3%）
 *  本年度的股票指数(至多12条数据, 用来绘制股票涨跌图)
 *  @since 2018.08.25
 *  @author lyc
 *******************************************/
    //股市每月变化, called in MainScene.nextMonth()
    public updateStock(){
        INFO.stock_index = SDATA.curr_sindex;//更新上月股票指数
        let random = Math.floor(Math.random()*11-5)/1000;//随机长线变化-0.5%~0.5%
        SDATA.month_change = Math.floor(Math.random()*9-5)/100;//短期变化-5%~3%
        if((INFO.month % 12) ==  0){
            SDATA.year_sindex[0] = SDATA.year_sindex[11];
            SDATA.year_sindex.splice(1,11);//清空数组 
        }
        if(12 - (INFO.month % 12) <= 11){
            let r = 1 + (0.02 + random + SDATA.month_change + SDATA.event_change);
            SDATA.curr_sindex *= r;
            SDATA.year_sindex[12 - (INFO.month % 12)] = Math.round(SDATA.curr_sindex);
            // console.log('random = ', random);
            // console.log('event_change = ', SDATA.event_change);
            // console.log('month_change = ', SDATA.month_change);
            // console.log('r = ', r);
        }
        INFO.last_earnings = (SDATA.curr_sindex/INFO.stock_index - 1)*INFO.stock_money;//上月收益
        //若持有股票，会有涨跌
        INFO.stock_money += INFO.last_earnings;
        // console.log('上月收益(curr_sindex/temp-1)*stock_money = (', 
        //             Math.round(SDATA.curr_sindex), '/', Math.round(INFO.stock_index), '-1)*', 
        //             Math.round(INFO.stock_money),' = ', Math.round(INFO.last_earnings));
    }
    public getStockData() {
        //获取股票显示的数据(四舍五入取整)
        var row = {};
        row.wallet =  Math.round(INFO.money);
        row.money =  Math.round(INFO.stock_money);
        row.last_earnings =  Math.round(INFO.last_earnings);
        row.earnings = Math.round(INFO.stock_money - INFO.stock_cost);
        if(INFO.stock_index <= 0){
            row.rate = 0;
        }
        else{
            let r = SDATA.curr_sindex/INFO.stock_index - 1;
            row.rate =Math.round(r*1000)/1000;
        }
        row.sindex = Math.round(SDATA.curr_sindex);
        row.year_sindex = SDATA.year_sindex;
        return row;
    }
    //股票操作手续费0.5%
    serviceCharge: number = 0.005;
    //买入股票, 影响钱包、持有总额、花费、持有收益
    public buyStock(num){
        //首月买入，记录为上月的股票指数
        if(INFO.stock_money <= 0){
            INFO.stock_index = SDATA.curr_sindex;
        }
        //余额充足可购买股票，收取0.5%手续费
        if(num <= INFO.money){
            INFO.money -= num;
            INFO.stock_money += num * (1-this.serviceCharge);
            INFO.stock_cost += num;
            //
            var row = {};
            row.wallet = Math.round(INFO.money);
            row.money = Math.round(INFO.stock_money);
            row.earnings = Math.round(INFO.stock_money - INFO.stock_cost);
            return row;
        }
        else{
            console.log('余额不足');
            return 0;
        }
    }
    curr_stoket_index = 0;//当前股票指数
    //卖出股票
    public sellStock(num){
        if(num <= INFO.stock_money){
            INFO.stock_money -= num;
            INFO.money += num * (1-this.serviceCharge);
            INFO.stock_cost -= num * (1-this.serviceCharge);//可为负
            //
            var row = {};
            row.wallet = Math.round(INFO.money);
            row.money = Math.round(INFO.stock_money);
            row.earnings = Math.round(INFO.stock_money - INFO.stock_cost);
            return row;
        }
        else return 0;
    }

    //如果有房的话，每月的属性变化
    public checkHouseChange(){
        let houses = API.getAPI('house');
        if(INFO.house == -1){
            //没有房,每月属性无变化
        }else{
            //有房,每月有花费，每月快乐值增加
            console.log("有房，money-"+houses[INFO.house-1].month_cost+"快乐+"+houses[INFO.house-1].month_happy);
            INFO.happy += houses[INFO.house-1].month_happy;
            INFO.money -= houses[INFO.house-1].month_cost;
        }
    }

    //如果有车的话，每月的属性变化
    public checkCarChange(){
        let cars = API.getAPI('car');
        if(INFO.car == -1){
            //没有车,每月属性无变化
        }else{
            //有车,每月有花费，每月交际值增加
            console.log("有车，money-"+cars[INFO.car-1].month_cost+"交际+"+ cars[INFO.car-1].month_social);
            INFO.social += cars[INFO.car-1].month_social;
            INFO.money -= cars[INFO.car-1].month_cost;
        }
    }

    //每月更新房价指数的长线变化
    public updateHindexLongChange(){
        //console.log('房价的长线指数已更新')
        HDATA.long_change += 0.1+Math.random()*0.07-0.02;
    }

    //通过日常事件触发剧情
    private checkJuqingByDaily(did){
        for(let i = 1 ; i < INFO.npcs.length ; i++){
            let npc = INFO.npcs[i];
            if(npc){
                let jq = npc.checkNextRequire(did);
                if(jq != 0){
                    let msg = API.getAPINode('juqing' , 'id',jq);
                    if(msg.type !=2)
                        npc.order++;
                    return jq;
                }
            }
        }
        return 0;
    }

    //通过属性变化触发剧情
    private checkJuqingByAtt(att){
        for(let i = 1 ; i < INFO.npcs.length ; i++){
            let npc = INFO.npcs[i];
            if(npc){
                let jq = npc.checkNextRequireAtt(att);
                if(jq != 0){
                    let msg = API.getAPINode('juqing' , 'id',jq);
                    if(msg.type !=2)
                        npc.order++;
                    return jq;
                }
            }
        }
        return 0;
    }

    //6大主要属性值发生变化的时候触发
    public mainAttsChanged(att , oldv , newv){
        //判断纯属性变化引起的剧情触发
        let jq = this.checkJuqingByAtt(att);
        if(jq){
            DRAMA.showDramaFrom(jq);
        }
    }
}
export const SYSTEM = System.getInstance();

