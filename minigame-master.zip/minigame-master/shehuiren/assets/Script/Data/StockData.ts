
/*******************************************
 *  股票界面有关数据
 *  @since 2018.08.27
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class StockData {
    private static instance : StockData;

    //初始股票指数1000~1500
    public sindex = Math.floor(Math.random()*501) + 1000;
    //短期变化（每月更新）
    public month_change = Math.floor(Math.random()*9-5)/100;
    //当前月股票指数
    public curr_sindex = this.sindex;
    //年度股票指数数组
    public year_sindex = [this.sindex];
    //随机事件对股票指数的影响
    public event_change = 0;



    public static getInstance():StockData{
        if(!StockData.instance) {
            StockData.instance = new StockData();
        }
        return StockData.instance;
    }

}
export const SDATA = StockData.getInstance();