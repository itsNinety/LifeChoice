
/*******************************************
 *  房产界面有关数据
 *  @since 2018.08.27
 *  @author qll
 * 房产实际买卖价格=房产基础价格*房价指数
 * 基础房价指数=60%~80%随机
 * 房价指数=（基础房价指数+长线变化+每月随机值）*随机事件变化（默认1）
 * 长线变化=固定长线变化10%+浮动值（-2%~5%）
 * 每月随机值=-20%~14%
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class HouseData {

    private static instance : HouseData;
    
    //基础房价指数=60%~80%随机
    public hindex = (Math.random()*0.2 + 0.6);
    //长线变化,每月该值都会增加
    public long_change = 0;
    //每月随机值
    public month_random_change = Math.random()*0.34 -0.2;
    //随机事件变化
    public random_event_change = 1;
    //当前月房价指数
    public curr_hindex = (this.hindex + this.long_change + this.month_random_change)*this.random_event_change;
    
    public getCurr_hindex(){
        console.log("基础房价指数",this.hindex)
        console.log("长线变化",this.long_change)
        console.log("每月随机值",this.month_random_change)
        console.log("随机事件影响",this.random_event_change)
        return (this.hindex + this.long_change + this.month_random_change)*this.random_event_change;
    }

    public static getInstance():HouseData{
        if(!HouseData.instance) {
            HouseData.instance = new HouseData();
        }
        return HouseData.instance;
    }

    
}

export const HDATA = HouseData.getInstance();
