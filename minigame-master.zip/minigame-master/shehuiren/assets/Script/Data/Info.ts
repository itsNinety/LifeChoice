import { API } from "../Utils/APITool";
import Npc from "../Npc/Npc";
import { SYSTEM } from "./System";
import { CONTACTS } from "../Npc/Contacts";
import { HDATA } from "./HouseData";
import { UTILS } from "../Utils/Utils";

/*******************************************
 *  用户信息-单例
 *  @since 2018.08.22
 *  @author zen
 * 
 *******************************************/

export default class Info {

    private static instance : Info;
    //open_id
    public open_id : string;
    //user_id
    public user_id;
    //得分
    public score : number = 0;
    //历史最高分
    public top_score : number = 0;

    // public url_login = 'https://dzp.hdyouxi.com/gong_wx/index.php/Home/Index/login_program';
    // public url_upload = 'https://dzp.hdyouxi.com/gong_wx/index.php/Home/General/save_score';
    public url_login    = 'https://nh.hdyouxi.com/zhuanpan_dev/index.php/Home/Index/social_login';
    public url_upload   = 'https://nh.hdyouxi.com/zhuanpan_dev/index.php/Home/General/social_upload';
    public url_invite   = 'https://nh.hdyouxi.com/zhuanpan_dev/index.php/Home/General/get_invite';
    public url_getTop   = 'https://nh.hdyouxi.com/zhuanpan_dev/index.php/Home/General/get_social_top';
    public url_getScore = 'https://nh.hdyouxi.com/zhuanpan_dev/index.php/Home/General/get_score';

    //头像
    public headimg_url : string = '韩梅梅';
    //名字
    public name : string = '番茄暴打西红柿';
    //性别
    public sex : number = 0;    //0女 1男
    //年龄
    public age : number = 22;   
    //金钱
    public money : number = 2000;
    //股票持仓
    public hold : number = 0;
    //对象
    public lover : number = -1; //actor id
    //默认空闲时间
    public freetime : number = 230; //
    //当月剩余时间
    public lefttime : number = 230; //当月剩余时间<= 空闲时间,且 空闲时间调整之后，下个月才会生效
    //工作
    public job  : number = 1; //job id
    //工作类型，基层员工
    public job_type : number = 1;
    //工资，月薪
    public salary : number = 2000;
    
    //汽车
    public car : number = -1 ;//car id
    //房产
    public house : number = -1; //房产id
    //精神状态， 0 干劲满满，1 拖延症爆发
    public status : number = 0 ;
    //
    public npcs = [];

    //魅力
    public charm: number = 100;
    //事业指数, 上限值是20
    public career: number = 0;
    //爱情指数, 上限值是20
    public love: number = 0;
    //折扣, 最后计算分数与之相乘
    public discount: number = 1;
    //游戏结束剩余的月份
    public month: number = 96;

    //本次登入时间
    public logIn: number = 0;

    //上次登出时间
    public logOut: number = 0;

    /***********
     * 本月剩余可以进行房产交易的次数
     * 默认为1，一个月只交易一次
     * 房产每个月只能买或卖一次，已经有房产时必须本月出售，下月购买
     ***********/
    public purchaseHouse: number = 1;

    /***********
     * 本月剩余可以进行车辆交易的次数
     * 默认为1，一个月只交易一次
     * 车辆每个月只能买和卖各一次，可以本月出售后本月购买
     ***********/
    public purchaseCar: number = 1;

    /***********
     * 本月剩余可以更换工作的次数
     * 默认为1，一个月只能成功求职一次
     ***********/
    public changeJob: number = 1;

    /***********
     * 本月剩余买彩票的次数
     * 默认为1，一个月只买一次
     ***********/
    public lotTimes: number = 1;

    //避免退出场景重进后可以调节时间条，和重置首次日常事件造成的影响
    public _slider_flag = 1;
    public tsp = 0.3;//时间条当前位置

    //本月剩余的，车行手动可刷新次数(月初系统刷新一次，邀请好友以后每月还可以手动刷新一次)
    public carRefreshTime: number   = 0;
    public houseRefreshTime: number = 0;
    public jobRefreshTime: number   = 0;
  
    //当月随机显示的车房人才市场的信息
    public monthCarRandom   = [-1,-1,-1];
    public monthHouseRandom = [-1,-1,-1];
    public monthJobRandom   = [-1,-1,-1];
    /***********
     * 记录性格背景选择的结果
     * 数组共4项，分别是
     * 0家庭背景、1性格趋向、2大学专业、3工作方向
     * 值0123分别代表四个选项
     * *********/
    public arr_selected = [];

    /***********
     * 记录读研阶段的精力分配结果
     * 数组长度为6，分别为
     * 学习、实践、兴趣、恋爱、娱乐、锻炼
     * *********/
    public arr_postFieldEnergy = []; 
    //是不是一个研究生
    public isPostgraduate: boolean = false;
     /***********
     * 记录待办事件
     * *********/
    public arr_backlog = [];

    //当前正在执行的待办时间在待办数组中的索引
    public currentBacklogIndex: number = -1;
    public currentFirstEventId: number = -1;
    public realFirstEventId: number = -1;
    public needShowFirst: boolean = false;

    //当前待办事项的剩余时间(拖延症状态下) 单位为秒
    public backlogRestTime: number = 1;

    //虚假剩余时间，待办事件加入但未执行时 并未真正扣除时间，判断是否可以加入待办事项时，用到此值
    fakeLeftTime: number = this.lefttime;

    //虚假剩余金钱，待办事件加入但未执行时 并未真正扣除金钱，判断是否可以加入待办事项时，用到此值
    fakeLeftMoney: number = this.money;

    //已经邀请的好友数量
    public friends_Invited: number = 0;

    /***********
     * stock_cost: 投资股票总额
     * 买入操作时加上花费的cost
     * 为负数表示全部回本且已有收益
     * *********/
    public stock_cost: number = 0;
    //实际持有的股票金额
    public stock_money: number = 0;
    //上月的股票指数
    public stock_index: number = 0;
    //上月收益
    public last_earnings: number = 0;

    //日常事件做过的次数，判断触发机遇事件
    public oppoTimes = [0,0,0,0,0,0,0,0,0,0,0,0];

    public chat = 0;//当前聊天对象
    private _red_pots = [];//需要红点的APP图标
    public static getInstance():Info{
        if(!Info.instance) {
            Info.instance = new Info();
            
            Info.instance.logIn = new Date().getTime()
        }
        return Info.instance;
    }

    //从本地存储中初始化数据
    public initDataFromLocal(){
        //基本信息读取
        let save =  cc.sys.localStorage.getItem('saveData');
        save = JSON.parse(save);
        for (let key in save) {
            INFO[key] = save[key];
        }

        //NPC关系读取
        let npcs = cc.sys.localStorage.getItem('saveNpc');
        npcs = JSON.parse(npcs);
        console.log(npcs);
        npcs.forEach(npc => {
            let n = new Npc;
            n.order = npc.o;
            n.relation = npc.r;
            n.id = npc.i;
            n.msgs = npc.m;
            n.new_msg = npc.n;
            this.npcs[parseInt(npc.i)] = n;
        });
        //console.log(this.npcs)
        //读取联系人
        let conts = cc.sys.localStorage.getItem('saveConts');
        conts = JSON.parse(conts);
        CONTACTS.initList(conts.list);
        
        //读取HDATA
        let HIndex = cc.sys.localStorage.getItem('saveHLongIndex');
        HIndex = JSON.parse(HIndex);
        for(let key in HIndex){
            HDATA[key] = HIndex[key];
        }

        //读取countDownFlag
        let CountDown = cc.sys.localStorage.getItem('savecountDownFlag');
        CountDown = JSON.parse(CountDown);
        for(let key in CountDown){
            UTILS[key] = CountDown[key];
        }
    }

    //把当前数据存储到本地
    public saveDataToLocal(){
        let save = {
            open_id            : this.open_id,
            user_id            : this.user_id,
            score              : this.score,
            name               : this.name,
            headimg_url        : this.headimg_url,
            sex                : this.sex,
            health             : this.health,
            money              : this.money,
            ability            : this.ability,
            exp                : this.exp,
            happy              : this.happy,
            morality           : this.morality,
            social             : this.social,
            career             : this.career,
            love               : this.love,
            discount           : this.discount,
            month              : this.month,
            purchaseHouse      : this.purchaseHouse,
            purchaseCar        : this.purchaseCar,
            changeJob          : this.changeJob,
            stock_cost         : this.stock_cost,
            stock_money        : this.stock_money,
            stock_index        : this.stock_index,
            last_earnings      : this.last_earnings,
            oppoTimes          : this.oppoTimes,
            status             : this.status,
            freetime           : this.freetime,
            lefttime           : this.lefttime,
            car                : this.car,
            house              : this.house,
            job                : this.job,
            job_type           : this.job_type,
            logOut             : new Date().getTime(),
            currentBacklogIndex: this.currentBacklogIndex,
            currentFirstEventId: this.currentFirstEventId,
            realFirstEventId   : this.realFirstEventId,
            needShowFirst      : this.needShowFirst,
            backlogRestTime    : this.backlogRestTime,
            arr_backlog        : this.arr_backlog,
            fakeLeftMoney      : this.fakeLeftMoney,
            fakeLeftTime       : this.fakeLeftTime,
            houseRefreshTime   : this.houseRefreshTime,
            carRefreshTime     : this.carRefreshTime,
            jobRefreshTime     : this.jobRefreshTime,
            isPostgraduate     : this.isPostgraduate,
            friends_Invited    : this.friends_Invited,
        };
        cc.sys.localStorage.setItem('saveData', JSON.stringify(save));

        let npcobj = [];
        for(let i = 0 ; i < this.npcs.length;i ++){
            let npc = this.npcs[i];
            if(npc){
                npcobj.push({'i':npc.id , 'o':npc.order , 'r':npc.relation ,'m' : npc.msgs , 'n':npc.new_msg })
            }
        }
        cc.sys.localStorage.setItem('saveNpc', JSON.stringify(npcobj));

        let conts ={"list": CONTACTS.getList()};
        cc.sys.localStorage.setItem('saveConts', JSON.stringify(conts));

        let HLongIndex = {
            hindex: HDATA.hindex,
            long_change: HDATA.long_change,
            month_random_change: HDATA.month_random_change,
        };
        cc.sys.localStorage.setItem('saveHLongIndex', JSON.stringify(HLongIndex));

        let countDown = {
            countDownFlag: UTILS.countdownFlag,
        }
        cc.sys.localStorage.setItem('savecountDownFlag', JSON.stringify(countDown));
    }

    //重新初始化数据
    public initNewData(){
        this.initNpc();
    }

    //清空本地存储数据
    public clearLocalData(){
        cc.sys.localStorage.clear();
    }

    //拖延症状况下继续游戏时的初始化
    public initDelayBacklog(){
        if(INFO.status == 1){
            let outTime = (INFO.logIn - INFO.logOut)/1000; //离开游戏的时间,单位为秒
            // if(INFO.currentFirstEventId == -1){
            //     //不需要处理第一个事件
            // }else{
            //     //第一个事件还没结束就退出了
            // }
            if(INFO.currentBacklogIndex == -1 || INFO.currentBacklogIndex == INFO.arr_backlog.length){
                //无待办事项或者在上次登出时已经全部执行完
                cc.director.loadScene('MainScene');
            }else{
                //上次退出时有待办事项正在执行
                console.log("上次退出时有待办事项正在执行，",INFO.currentBacklogIndex)              
                if(outTime < INFO.backlogRestTime){
                    INFO.backlogRestTime -= Math.floor(outTime);
                    //console.log(INFO.arr_backlog.length)
                }else{
                    if(INFO.currentFirstEventId == -1){
                        //不需要处理第一个事件
                        UTILS.attrIncrease(INFO.currentBacklogIndex);//属性增益
                        var leftOutTime = Math.floor(outTime - INFO.backlogRestTime);
                        INFO.currentBacklogIndex++;
                    }else{
                        //先把第一个事件去掉，去掉它的剩余时间,属性增益到游戏首页再更改
                        var leftOutTime = Math.floor(outTime - INFO.backlogRestTime);
                        INFO.needShowFirst = true;
                        INFO.currentFirstEventId = -1;
                    }
                    let initCurrentIndex = INFO.currentBacklogIndex;
                    let daily = API.getAPI('daily_event');
                    for(let i = initCurrentIndex; i< INFO.arr_backlog.length; i++){
                        if(leftOutTime + daily[INFO.arr_backlog[i].id -1].time_cost/10*60 >= 0){
                            UTILS.attrIncrease(i);//属性增益
                            INFO.currentBacklogIndex++;
                            leftOutTime += daily[INFO.arr_backlog[i].id -1].time_cost/10*60;
                        }else{
                            //执行到该currentBacklogIndex
                            INFO.currentBacklogIndex = i;
                            INFO.backlogRestTime = -Math.floor(leftOutTime+daily[INFO.arr_backlog[i].id -1].time_cost/10*60);
                            break;
                        }
                        if(i == INFO.arr_backlog.length-1){
                            //在离开游戏的这段时间已经全部执行完
                            INFO.currentBacklogIndex = INFO.arr_backlog.length;
                            INFO.backlogRestTime = 1;
                            break;
                        }
                    }
                    
                } 
            }
        }
    } 
    

    showInfo(){
        console.log('open_id: ', INFO.open_id);
        console.log('user_id: ', INFO.user_id);
        console.log('score: ', INFO.score);
        console.log('top_score = ', INFO.top_score);
        console.log('name: ', INFO.name);
        console.log('headimg_url: ', INFO.headimg_url);
        console.log('性别sex: ', INFO.sex);
        console.log('健康health: ', INFO.health);
        console.log('金钱money: ', INFO.money);
        console.log('能力ability: ', INFO.ability);
        console.log('经验exp: ', INFO.exp);
        console.log('快乐happy: ', INFO.happy);
        console.log('道德morality: ', INFO.morality);
        if(INFO.sex == 1){
            console.log('交际social: ', INFO.social);
        }
        else if(INFO.sex == 0){
            console.log('魅力charm: ', INFO.charm);
        }
        console.log('事业指数career: ', INFO.career);
        console.log('爱情指数love: ', INFO.love);
        console.log('折扣discount: ', INFO.discount);
        console.log('剩余的月数month: ', INFO.month);
    }


    private initNpc(){
        //npc关系
        let start = API.getAPI('juqing_start');
        let npcid = 0;
        for(let i = 0 ; i < start.length ; i++){
            let m = start[i];
            npcid = parseInt(m.npc);
            console.log('npcs' , npcid)
            if(!this.npcs[npcid]){
                let n = new Npc();
                n.order = 1;
                n.relation = 0;
                n.id = npcid;
                this.npcs[npcid] = n;
            }
        }
    }

    //健康
    private _health : number = 200;
    public set health(v){
        let old = this._health;
        this._health = v;
        SYSTEM.mainAttsChanged('health' , old , v);
    }
    public get health(){
        return this._health;
    }
    //道德
    private _morality : number = 200;
    public set morality(v){
        let old = this._morality;
        this._morality = v;
        SYSTEM.mainAttsChanged('morality' , old , v);
    }
    public get morality(){
        return this._morality;
    }
    //快乐 
    private _happy : number = 200;
    public set happy(v){
        let old = this._happy;
        this._happy = v;
        SYSTEM.mainAttsChanged('happy' , old , v);
    }
    public get happy(){
        return this._happy;
    }
    //能力
    private _ability : number = 100;
    public set ability(v){
        let old = this._ability;
        this._ability = v;
        SYSTEM.mainAttsChanged('ability' , old , v);
    }
    public get ability(){
        return this._ability;
    }
    //交际
    private _social : number = 100;
    public set social(v){
        let old = this._social;
        this._social = v;
        SYSTEM.mainAttsChanged('social' , old , v);
    }
    public get social(){
        return this._social;
    }
    //经验
    private _exp : number = 100;
    public set exp(v){
        let old = this._exp;
        this._exp = v;
        SYSTEM.mainAttsChanged('exp' , old , v);
    }
    public get exp(){
        return this._exp;
    }

    
    //获取红点信息
    public isRedPots(id){
        if(this._red_pots.indexOf(id) == -1){
            return false;
        }else{
            return true;
        }
    }
    //指定的图标亮红点
    public addRedPot(id){
        if(this._red_pots.indexOf(id) == -1){
            this._red_pots.push(id);
        }
    }   
    
    //移除红点
    public removeRedPot(id){
        for(let i = this._red_pots.length-1 ; i >= 0;i--){
            if(this._red_pots[i] == id){
                this._red_pots.splice(i ,1);
            }
        }
    }
}
export const INFO = Info.getInstance();