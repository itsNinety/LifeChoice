
/*******************************************
 *  friend类
 *  @since 2018.08.29
 *  @author lyc
 * 
 *******************************************/

export default class Friend {
    user_id : number = 0;
    open_id = null;
    score: number = 0;
    nick_name : string = 'xMan';
    headimg_url: string = '';
    gender : boolean = true;
    info: string = '钱包：2000000\n年龄：28\n职位上市公司老总\n伴侣：医生张小龙\n车：保时捷\n房：城中别墅';

    constructor(open_id, score, nick_name, headimg_url, gender, info){
        this.open_id = open_id;
        this.score = score;
        this.nick_name = nick_name;
        this.headimg_url = headimg_url;
        this.gender = gender;
        this.info = info;
    }

    showInfo(){
        // console.log('user_id = ' , this.user_id);
        console.log('open_id = ' + this.open_id);
        console.log('score = ' + this.score);
        console.log('nick_name = ' + this.nick_name);
        console.log('headimg_url = ' + this.headimg_url);
        console.log('gender = ' + this.gender);
        console.log('info = ' + this.info);
    }

}
