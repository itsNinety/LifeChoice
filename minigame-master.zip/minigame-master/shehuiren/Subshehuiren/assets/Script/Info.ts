import Friend from "./Friend";

/*******************************************
 *  用户信息类
 *  @since 2018.08.29
 *  @author lyc
 * 
 *******************************************/

declare const CC_WECHATGAME
export default class Info {
    user_id : number = 0;
    open_id = null;
    score : number = 0;
    nick_name : string = '不愿透露nick的杨先生'
    headimg_url: string = '';
    gender : number = 0;
    Ranking: Friend[] = [];
    info: string = '钱包：2000000\n年龄：28\n职位上市公司老总\n伴侣：医生张小龙\n车：保时捷\n房：城中别墅';
    static instance : Info = null;

    static getInstance() {  
        if (Info.instance == null) {  
            Info.instance = new Info();  
        }  
        return Info.instance;  
    }

    showInfo(){
        console.log('score = ' + this.score);
        console.log('open_id = ' + this.open_id);
        console.log('nick_name = ' + this.nick_name);
        console.log('headimg_url = ' + this.headimg_url);
        console.log('gender = ' + this.gender);
        console.log('info = ' , this.info);
    }

}
       
export const INFO = Info.getInstance();