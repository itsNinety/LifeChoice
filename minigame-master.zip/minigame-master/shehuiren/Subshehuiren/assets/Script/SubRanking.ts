import { INFO } from "./Info";
import Friend from "./Friend";
import Item from "./Item";

/*******************************************
 *  子域绘制界面
 *  @since 2018.08.29
 *  @author lyc
 * 
 *******************************************/

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {
    //排行榜and弹窗
    @property(cc.Prefab)
    item_fab :cc.Prefab = null;
    @property(cc.Node)
    list:cc.Node = null;
    @property(cc.Sprite)
    popup: cc.Sprite = null;
    @property(cc.Sprite)
    boy: cc.Sprite = null;
    @property(cc.Label)
    detailsNick : cc.Label = null;
    @property(cc.Label)
    info : cc.Label = null;

    start () {
        let that = this;
        //监听主域发送的消息
        wx.onMessage(function(data) {
            console.log("wx.onMessage:", data);
            switch (data.message) {
                case 'rank':{
                    that.getUser().then(function(value){
                        console.log('after getUser().');
                        let item = cc.instantiate(that.item_fab);
                        item.getComponent(Item).initView(-1 , INFO.headimg_url , 
                            INFO.nick_name , INFO.score);
                        that.node.addChild(item);
                        item.setPosition(-240, -300);
                        that.getFriend().then(function(value){
                            console.log('after getFriend().');
                            that.show(INFO.Ranking);
                        });
                        //that.testFriend();
                    });
                }
                break;
                case 'group':{
                    that.getGroup().then(function(value){
                        //console.log('after getGroup().');
                        that.show(INFO.Ranking);
                    });
                }
                break;
                case 'close':that.closeAlert();
                break;
                //
                default:{
                    if(data.message.id != -1){
                        if(data.message.id == -10){
                            that.showAlert(INFO);
                        }
                        else if(INFO.Ranking[data.message.id] != null){
                            that.showAlert(INFO.Ranking[data.message.id]);
                        }
                    }
                    else{
                        that.list.y += data.message.d; 
                    }
                }
            }
        });
    }

    //测试显示friend
    testFriend(){
        let s = '钱包：2000000\n年龄：28\n职位上市公司老总\n伴侣：医生张小龙\n车：保时捷\n房：城中别墅';
        for(let i = 0; i < 10; i++){
            let n = 4000-i*1000*(Math.random()-0.5);
            INFO.Ranking[i] = new Friend(i, Math.round(n), i+'nick太长了可还行', '', false, s);
        }
        this.show(INFO.Ranking.sort(this.sort));   
    }

    sort(a , b){
        return b.score - a.score;
    }

    show(list){
        this.list.removeAllChildren();
        for(let i = 0 ; i < list.length ; i++){
            if(list[i] != null){
                console.log(list[i].nick_name, ' score = ', list[i].score);
                let item = cc.instantiate(this.item_fab);
                item.getComponent(Item).initView(i , list[i].headimg_url , 
                    list[i].nick_name , list[i].score);
                this.list.addChild(item);
                item.setPosition(0, -24-i*108);
            }
        }

    }

    showAlert(item){
        console.log('showAlert()');
        this.popup.node.active = true;
        if(item.gender == 0){
            this.boy.node.active = false;
        }
        if(item.nick_name.length > 7){
            let str = item.nick_name.substring(0, 7);
            this.detailsNick.string = str + "...";
        }
        else{
            this.detailsNick.string = item.nick_name;
        }
        this.info.string = item.info;
        this.popup.node.active = true;
    }
    
    closeAlert(){
        this.boy.node.active = true;
        this.popup.node.active = false;
    }

    getUser(){
        return new Promise((resolve,reject)=>{
            let that = this;
            wx.getUserCloudStorage({
                keyList: ['nick_name','headimg_url','a'],
                success: res => {
                    console.log("wx.getUserCloudStorage success: ", res);
                    let info = JSON.parse(res.KVDataList[0].value);
                    //console.log('info = ', info);
                    INFO.score = info.score;
                    INFO.open_id = info.open_id;
                    INFO.nick_name = info.nick_name;
                    INFO.headimg_url = info.headimg_url;
                    INFO.gender = info.gender;
                    INFO.info = that.getDetails(info);
                    //INFO.showInfo();
                    resolve();
                },
                fail: res => {
                    console.log("wx.getUserCloudStorage fail", res);
                },
            });    
        })
    }

    getFriend(){
        return new Promise((resolve,reject)=>{
            let that = this;
            //取出所有好友数据
            wx.getFriendCloudStorage({
                keyList: ['nick_name','headimg_url','a'],
                success: res => {
                    console.log("wx.getFriendCloudStorage success: ", res);
                    //解析好友数据
                    for(let i = 0; i < INFO.Ranking.length; i++){
                        INFO.Ranking.pop();
                    }
                    const dataLen = res.data.length;
                    //console.log('dataLen = ', dataLen);
                    for(let i = 0; i < dataLen; i++){
                        let info = JSON.parse(res.data[i].KVDataList[0].value);
                        let a = res.data[i];
                        INFO.Ranking[i] = new Friend(a.openid, info.score, a.nickname, a.avatarUrl, info.gender, that.getDetails(info));
                    }
                    INFO.Ranking.sort(that.sort);
                    resolve();
                },
                fail: res => {
                    console.log("wx.getFriendCloudStorage fail", res);
                },
            });      
        })
    }

    getGroup(){
        return new Promise((resolve,reject)=>{
        let that = this;
        //取出群同玩成员数据
		wx.getGroupCloudStorage({
			keyList: ['nick_name','headimg_url','a'],
			success: res => {
                console.log("wx.getGroupCloudStorage success", res);
                //解析好友数据
                for(let i = 0; i < INFO.Ranking.length; i++){
                    INFO.Ranking.pop();
                }
                const dataLen = res.data.length;
                for(let i = 0; i < dataLen; i++){
                    let info = JSON.parse(res.data[i].KVDataList[0].value);
                    let a = res.data[i];
                    INFO.Ranking[i] = new Friend(a.openid, info.score, a.nickname, a.avatarUrl, info.gender, that.getDetails(info));
                }
                INFO.Ranking.sort(that.sort);
                resolve();
			},
			fail: res => {
				console.log("wx.getGroupCloudStorage fail", res);
			},
		});
        })
    }
        
    getDetails(info){
        let json;
        if(info.info != null && info.info != '' && info.info != undefined){
            json = info.info;
            //console.log('json = ', json);
            let detailsInfo = "钱包: " + json.wallet
            + "\n年龄: " + json.age
            + "\n职位: " + json.position.substr(0, json.position.length-4)
            + "\n         " + json.position.substr(json.position.length-4, json.position.length-1)
            + "\n伴侣: " + json.lover
            + "\n车:    " + json.car
            + "\n房:    " + json.house;
            //console.log('detailsInfo = ', detailsInfo);
            return detailsInfo;
        }
        else return '';
    }
}
